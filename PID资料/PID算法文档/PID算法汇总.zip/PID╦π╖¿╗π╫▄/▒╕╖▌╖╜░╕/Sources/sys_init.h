/********************************************************
Code Warrior 4.7
Target : MC9S12XS128
Crystal: 16.000Mhz
busclock:16.000MHz
pllclock:32.000MHz
*/
extern void Init_Dev(void);
