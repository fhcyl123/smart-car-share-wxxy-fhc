/*
*******************************************************************************************
*                                        �������ᳵ�� ���ܳ�����
*                                              
*                                               �����
*                                      
*                                   Team member ��ï �����ڣ� ����   
* 
*                                        (c) Copyright 2009     
*
* File    : function.c
* By      : Chen Yang
* Email   : sunshinechenyang@qq.com                         
* time    : 2009.7.7
* Version : V1.10  
*******************************************************************************************
*/

/*
*******************************************************************************************
*                                           ͷ�ļ�
*******************************************************************************************
*/
 
#include <hidef.h>
#include <mc9s12xs128.h> 
#include "function.h"

/*
*******************************************************************************************
*                                        ȫ�ֱ�������
*******************************************************************************************
*/
  struct time_flag 
  {
    unsigned long int time ;
    unsigned char flag;
  } ;
  
 struct time_flag_link  
  {
      struct time_flag current_flag;
      struct time_flag_link *next;
  }  *current_link;
    
  unsigned int  position_judgement; //��ǰλ�ã��м� ��� �ұ� 
  unsigned char position_change=4 ; //��·�仯��־��4Ϊֱ��  
  struct time_flag mid,left,right,left_right; 
  
//-------------------------path_state-----------------------  
  word led ; 
  unsigned int  led_en=0;     
  unsigned int  angle_data;         
           int  car_positn; //��ǰ����     
           int  pre_positn; 
  unsigned int black_sensor_number;   
           int positn_temp[10]; 
  unsigned int led_change;
  struct time_flag  start_line ;            
//-----------------------speed variable---------------------  
  unsigned char dir_flag;     
  unsigned char brake_flag=0; 
  unsigned long int brake_time;          
  int  car_driver;             
  unsigned int  pulse_count;             
  long int  ideal_speed;            
  unsigned long int  times;                 
           long int  speed_error;           
           long int  pre_error;             // PID   ideal_speed- pulse_count 
           long int  pre_d_error;           // PID   d_error-pre_d_error 
           int error,d_error,dd_error;  
           int  pk;                    // PID 
               
//---------------------triangle-------------------------
 
  unsigned  int pre_black_sensor_number;
  unsigned  int black_sensor_number_start;
  unsigned  int black_sensor_number_finish;
  
//---------------------start_line variable-------------- 

  unsigned char start_line_acc=0;       
  unsigned int line_count=2;  //Ȧ��
  struct time_flag  finish;
  unsigned  int line_time=15; 
  
  
/*                
-----------------------------------------------------------------------------------------
  
* �����μ��
                          
-----------------------------------------------------------------------------------------
*/
unsigned char store_table[10],triangle_en;

struct time_flag  normal_path,start_cross,tri_up ,tri_down ,led_up_three,triangle_brank;

struct time_flag triangle_start,triangle_finish;


struct time_flag source ;
/*
*******************************************************************************************
*                                        ȫ�ֳ�������
*******************************************************************************************
*/

enum road {normal,start_c_tri,tri_add,tri_reduce,deal};  
enum road current_road; 
//enum e_speed{enum_narrow,enum_tri_brank,enum_straight,enum_bend,enum_straight_bend, }

unsigned char seg_table[]=//{          0x3F,0x06,0x5B,0x4F,0x66, //0~4
//                                     0x6D,0x7D,0x07,0x7F,0x6F};//5~9  ������
                            {0xC0,0xF9,0xA4,0xB0,0x99, //0~4  ������
                              0x92,0x82,0xF8,0x80,0x90, //5~9
                              0x88,0x83,0xC6,0xA1,0x86,0x8E}; //A~F */
                       
struct time_flag seg;    
   
                  
unsigned int angle_table3[23]={//19:10 9.11  

     /*-11*/970,   /*-10*/990,   /*-9*/1000,   /*-8*/1011,   /*-7*/1022,   /*-6*/1047,
     /*-5*/1058,   /*-4*/1069,   /*-3*/1080,  /*-2*/1098,  /*-1*/1104,  /*0*/1110,
     /*1*/1117,    /*2*/1124,    /*3*/1147,   /*4*/1159,   /*5*/1171,   /*6*/1183,   
     /*7*/1211,    /*8*/1225,    /*9*/1239,   /*10*/1253,  /*11*/1275  } ; 
     
unsigned int angle_table4[23]={//19:00 9.11  

     /*-11*/970,   /*-10*/990,   /*-9*/1000,   /*-8*/1011,   /*-7*/1036,   /*-6*/1047,
     /*-5*/1058,   /*-4*/1069,   /*-3*/1092,  /*-2*/1098,  /*-1*/1104,  /*0*/1110,
     /*1*/1117,    /*2*/1124,    /*3*/1131,   /*4*/1159,   /*5*/1171,   /*6*/1183,   
     /*7*/1195,    /*8*/1225,    /*9*/1239,   /*10*/1253,  /*11*/1275  } ; 


unsigned int angle_table2[23]={//  

     /*-11*/970,   /*-10*/990,   /*-9*/995,   /*-8*/1000,   /*-7*/1005,   /*-6*/1040,
     /*-5*/1065,   /*-4*/1090,   /*-3*/1095,  /*-2*/1100,  /*-1*/1105,  /*0*/1110,
     /*1*/1117,    /*2*/1124,    /*3*/1156,   /*4*/1164,   /*5*/1178,   /*6*/1198,   
     /*7*/1234,    /*8*/1241,    /*9*/1248,   /*10*/1255,  /*11*/1275  } ; 


unsigned int angle_table1[23]={//  

     /*-11*/970,   /*-10*/990,   /*-9*/1000,   /*-8*/1011,   /*-7*/1023,   /*-6*/1047,
     /*-5*/1058,   /*-4*/1069,   /*-3*/1080,  /*-2*/1096,  /*-1*/1103,  /*0*/1110,
     /*1*/1118,    /*2*/1126,    /*3*/1147,   /*4*/1159,   /*5*/1171,   /*6*/1183,   
     /*7*/1211,    /*8*/1225,    /*9*/1239,   /*10*/1253,  /*11*/1275  } ;     
 
 /*#define kp 10//2000                  
 #define ki 4//1                         
 #define kd 1//10 */ 
 float kp=0.2,ki,kd;                    
 #define Angle_Center 1090            
 #define lose_limit1 100             
 #define lose_limit2 300 
 float pi; 
/*                
-----------------------------------------------------------------------------------------
  
*  5.29 �ٶȲ������
                          
-----------------------------------------------------------------------------------------
*/
unsigned int speed_straight_bend,speed_bend,speed_straight;
unsigned int speed_narrow,speed_tri_brank;  
//---------------------------------------------------------------------------------------
void sys_init()
{   
    if(PTH_PTH6) triangle_en=1;  //���������
    else  triangle_en=0;
    
    if(PTH_PTH5)  triangle_start.flag=1; //����������������
    else  triangle_start.flag=0;  //����������������
    
    if(PTH_PTH4) line_count=10;  //�����������
    else line_count=2;
    
        
    speed_tri_brank=150;   
     
    switch(PTH&0x07) 
    { 
     case 0x01:
          speed_straight_bend=80;  
          speed_bend=200;
          speed_straight=500; 
          speed_tri_brank=150;
          break;
          
      case 0x02:
          speed_straight_bend=80;
          speed_bend=250;
          speed_straight=500; 
          speed_tri_brank=150;
          break;
             
      case 0x03:
          speed_straight_bend=80;
          speed_bend=300;
          speed_straight=500; 
          speed_tri_brank=150;
          break;
          
      case 0x04:
          speed_straight_bend=80;
          speed_bend=350;
          speed_straight=500; 
          speed_tri_brank=150;
          break;
          
      case 0x05:
          speed_straight_bend=80;
          speed_bend=400;
          speed_straight=500; 
          speed_tri_brank=200;
          break;  
          
      case 0x06:
          speed_straight_bend=80;
          speed_bend=350;
          speed_straight=500; 
          speed_tri_brank=200;
          break; 
      case 0x07:
          speed_straight_bend=80;
          speed_bend=400;
          speed_straight=500; 
          speed_tri_brank=200;
          break; 
    }
 /*   switch(PTH&0x03) 
    {       
      case 0x00:  speed_straight=350;  break;   
      case 0x01:  speed_straight=400;  break;   
      case 0x02:  speed_straight=450;  break;   
      case 0x03:  speed_straight=500;  break;                
    }
    switch((PTH&0x0c)>>2) 
    {       
      case 0x00:  speed_straight_bend=100;  break;   
      case 0x01:  speed_straight_bend=130;  break;   
      case 0x02:  speed_straight_bend=160;  break;   
      case 0x03:  speed_straight_bend=200;  break;    
    }
    switch((PTH&0x03)>>4) 
    {       
      case 0x00:  speed_bend=200;  break;   
      case 0x01:  speed_bend=250;  break;   
      case 0x02:  speed_bend=300;  break;   
      case 0x03:  speed_bend=350;  break;    
    } */  
}
/*
******************************************************************************************
*                                          ·����Ϣ���  
* 
* Description: �˰汾���ʹ���ڲ�AD
*             
* Arguments  :
*
* Note(s)    : 
*                                   
******************************************************************************************
*/
void path_state() 
{
  unsigned char  i;   
  //---------------------------------------------------------------
  /*if(led_en) 
  {   
      led_en=0;
      led=0;
      for(i=0;i<12;i++) 
      {
        if(ReadATD(i)>ATD0DR12L) 
        {
          led|=1<<i;   
        }
      } */       
      black_sensor_number=0;   led_change=0;
      for (i=0;i<12;i++) 
      {  
         if(led&(1<<i))  black_sensor_number++; 
         if(i<11)
         if(((led&(1<<i))>>i)^((led&(1<<(i+1)))>>(i+1)))  led_change++;     
      }
  //}
  //---------------------------------------------------------------  
  if((black_sensor_number<=3)&&(led_change<=2))   
  {
    car_position();   //���λ��
    normal_state();  
  }  
  else 
  {
    abnormal_state(); //��������ߡ������Ρ�ʮ��·�ڱ��
  } 
 pre_black_sensor_number=black_sensor_number ;
  if((pulse_count>=100)&&(pulse_count<300)) line_time=40-(pulse_count-100)/8; 
  else if(pulse_count>=450) line_time=2; 
  else if(pulse_count>=400) line_time=5;
  else if((pulse_count>300)&&(pulse_count<400)) line_time=15-(pulse_count-300)/10;  
  else if((pulse_count>50)&&(pulse_count<100)) line_time=80-(pulse_count-50)*5/4;
  else if(pulse_count>30) line_time=80; 
  else  line_time=100; 
}

/*
========================================================================================

* normal���

=======================================================================================
*/

void normal_state() 
{
    start_cross.time=0;//Э��������
    start_cross.flag=0; 
    if(normal_path.time<10000) normal_path.time++;    //normal_path  
    if(normal_path.time==50) 
    {
      normal_path.flag=1;         
      current_road=normal;
      store();  reset_other();   
    }
    if((normal_path.time==100)&&led_up_three.time) 
    {
      led_up_three.flag=0; //Э�������߼��
      led_up_three.time=0;  
      store_table[1]=deal; //ʮ��·���˲�
    } 
    
/*  if(normal_path.time==150) 
    {      
      triangle_brank.flag=0; //�����Ρ�ɲ��-����
      triangle_brank.time=0;
    }*/
    
    if(normal_path.time==200) 
    {
      normal_path.time=150; //����else if�ڴ���ִֻ��һ��
      led_up_three.flag=0; //Э�������߼��
      led_up_three.time=0; 
      reset_other();       //��ʱ��ֱ����������״̬����
    } 
}


/*
========================================================================================

* �����Σ������ߣ�ʮ��·�ڣ��ж�

========================================================================================
*/

void path_judge() 
{
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^-������-^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^  
 if(  
     (
      (store_table[0]==normal)
      &&
      (
        ((store_table[1]==tri_reduce)||(store_table[1]==tri_add)||(store_table[2]==tri_reduce)||(store_table[2]==tri_add))
        ||
        (
            (store_table[1]==start_c_tri)
            &&
            (
              (store_table[2]==tri_reduce)||(store_table[2]==tri_add)||(store_table[3]==tri_reduce)||(store_table[3]==tri_add)
            ) 
         )
      )//�ظ�״̬
     )
     &&
     (led_up_three.flag) 
 )    
    {
        triangle_brank.flag=1; triangle_start.flag=!triangle_start.flag; 
        store_table[1]=deal; store_table[2]=deal; store_table[3]=deal;
    }

//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^-������-^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^   
 else if(
     (store_table[0]==normal)&&(store_table[1]==start_c_tri)&&(store_table[2]==normal)
     && 
     (led_up_three.time==0)
     &&
     ((car_positn>-10)&&(car_positn<10)) //��ֹ�ܳ��������ţ���car_position()�ڿ�����Э��
  )
  {  
      check_start(); 
      store_table[1]=deal;
  }
}

/*
========================================================================================

* �����߼��

=======================================================================================
*/
void check_start(void)  
 { 

   start_line_acc++ ; 
   
   if(start_line_acc==line_count)  
   { 
       finish.flag=1; 
   }       
} 
/*
========================================================================================

* ����״̬����

=======================================================================================
*/
void reset_other() 
{
    switch(current_road) 
    {
      case  normal : 
            {
               tri_up.time=0;
               tri_up.flag=0;
               tri_down.time=0;
               tri_down.flag=0; 
            }
            break;
      case  start_c_tri :
            {
               normal_path.time=0;
               normal_path.flag=0;
               tri_up.time=0;
               tri_up.flag=0;
               tri_down.time=0;
               tri_down.flag=0;                              
            }
            break;
      case  tri_add :
            {
               normal_path.time=0;
               normal_path.flag=0;
               //start_cross.time=0;
               //start_cross.flag=0;
               
               tri_down.time=0;
               tri_down.flag=0;            
            }
            break;
      case  tri_reduce :
            {
               normal_path.time=0;
               normal_path.flag=0;
               //start_cross.time=0;
               //start_cross.flag=0;
               tri_up.time=0;
               tri_up.flag=0;                    
            }
            break;
    }
}
/*
========================================================================================

* abnormal���

=======================================================================================
*/
void abnormal_state() 
{
    if(led_change>=4) start_cross_tri();   
    if((black_sensor_number>3)&&(led_change<3))   triangle(); 
}
/*
========================================================================================

* ������,ʮ��·�ڼ��    

=======================================================================================
*/

void start_cross_tri(void)  
 { 
   tri_up.time=0;
   tri_up.flag=0;
   tri_down.time=0;
   tri_down.flag=0;    
   if(start_cross.time<500)  start_cross.time++;  //�������������0  
   if((start_cross.time>=line_time)&&(start_cross.time!=1000)) 
   {
    start_cross.time=1000;//����if�ڴ���ִֻ��һ��
    start_cross.flag=1 ;  
    current_road=start_c_tri ;
    store();  reset_other();
   }
} 

/*
========================================================================================

* �����μ��

=======================================================================================
*/

void triangle() 
{
   //******************��⵽���ߵĴ�����������������********************
    if(led_up_three.time<800)  led_up_three.time++ ;      //normal������ 
    if((led_up_three.time>=(line_time*3))&&(led_up_three.time!=1000))  
    {
        led_up_three.time=1000; //����else if�ڴ���ִֻ��һ��
        led_up_three.flag=1;        
    }
   //*********************��⵽���ߵĴ�������������*********************
   if(pre_black_sensor_number<black_sensor_number)
   {
      start_cross.time=0;
      start_cross.flag=0;
      tri_down.time=0;
      tri_down.flag=0;     
      if(tri_up.time<100)  tri_up.time++ ;      //�������������0  
      if((tri_up.time>=4)&&(led_up_three.flag))  
      {
        tri_up.time=1000; //����else if�ڴ���ִֻ��һ��
        tri_up.flag=1;  current_road=tri_add ;   
        store();  reset_other(); 
      }
   }   
   //*********************��⵽���ߵĴ����������½�*********************
   if(pre_black_sensor_number>black_sensor_number)
   { 
      start_cross.time=0;
      start_cross.flag=0;
      tri_up.time=0;
      tri_up.flag=0;
      if(tri_down.time<100)   tri_down.time++;  //�������������0  
      if((tri_down.time>=6)&&(led_up_three.flag))  
      {
        tri_down.time=1000; //����else if�ڴ���ִֻ��һ��
        tri_down.flag=1;   current_road=tri_reduce; 
        store();  reset_other(); 
      }
   }      
}

/*
========================================================================================

* ״̬�洢

=======================================================================================
*/
void store(void) 
{
    int i;
    if(store_table[0]!=current_road) 
    {
        for(i=4;i>0;i--) 
        {
            store_table[i]=store_table[i-1];
        }
        store_table[0] = current_road;
    }
}


/*
**********************************************************************************************
*                                          ·���ı��ж�  
* 
* Description: �˰汾����·ΪAD            
*
* Time    :   2009.6.26
*          
* Note(s) :(1)  ʡ��֮��Ľ�     
*          (2)  �ж�S�����S���Ҳ�������һ�֣��������϶�������жϷ�����ȫ����ʵ�ֶ�S�����
*               ��һ��������жϣ���ô��β���ʵ������������ж��أ����ǵ�·�εĿ����������ͨ
*               �������һ��·�β���ֱ�����������������S�䣩����ô���ڳ���ĳ����м���һ����
*               �ɺ���������һ��ʱ���������ɼ�·����Ϣ���������ƫ����������߼�С����û��ά��
*               ��״̬����������Ǿ�˵����һ·����״Ϊ��������ղž�������������ڵ����������
*               S���������ڹ��ɺ���ִ�еĹ����У�ƫ����һֱΪ���������Ϊ�������²�������ô
*               ˵����ǰ��·����״Ϊֱ����(----�ӱ�����)
*
* Version : V1.50             
********************************************************************************************
*/

void path_change() 
{
  //  int i; unsigned char position_store[10]; 
    if((car_positn>=-3)&&(car_positn<=3))
    {                 
       if(mid.time<10000)  //��ⶨ
       {
         mid.time++;     
       }
       
       if(mid.time==10)   //��������     (&����������ٶ��趨)
       {
         left_right.time=0; 
       }
              
       if(mid.time==100)  
       {
         mid.flag=1;       
         left_right.flag=0;
       }
                      
    } 
    else //if((car_positn>3)||(car_positn<-3)) 
    {
       if(left_right.time<10000)  
       {
        left_right.time++;        
       }
       
       if(left_right.time==3)    //�������� 
       {
        mid.time=0; 
       }  
            
       if(left_right.time>=(line_time*10))  
       {
        left_right.flag=1;          
        mid.flag=0; 
       }  
    } 


    if((left_right.time>=3)&&mid.flag)     //֮ǰ50��״̬mid��־λΪ1,��ǰλ����left_right
    {
       position_change=1; //ֱ��������ж�    &ֱ���ڶ��������ų��������м�״̬��
    } 
  
    else if((mid.time>=(line_time*10))&&left_right.flag)    //֮ǰ10��״̬--left_right��־λΪ1,��ǰλ��mid
    {
       position_change=2; //�����ֱ����S���ж�  ---����ڶ���
    } 
//------------------------------------------------------------------------------------------------    
    else if((mid.time<5)&&left_right.flag)    //֮ǰ100��״̬--left_right��־λΪ1,��ǰλ��mid
    {
       position_change=3; //������������ж�
    }   
    
    else if((left_right.time<3)&&mid.flag)      //֮ǰ5000��״ֱ̬����־λΪ1,��ǰλ�����м�
    {
       position_change=4; //ֱ�����������ж�
    }
     
}

/*
========================================================================================

* ����Ƕ�

========================-===============================================================
*/ 
void angle()  
{       
  angle_data = angle_table1[car_positn+11] ; 
  
/*  float left_rud=1270,mid_rud=1090,right_rud=960; 
  float Pdelta[7]={1,2,1,0,1,2,1};
  float Ddelta[7]={0.5,1,0.5,0,0.5,1,0.5};
  float  RUDKP[3];//50;
  float  RUDKD[3];//5;
  static int  RErrLast=0;
  static int  RErrCurr=0;
  static int  RErrPreLast=0;
  static int  Ruddelta=0;
  int temp1,temp2;
  float Kp,Kd;
  RUDKP[0]=(mid_rud-right_rud)/14; //car_positn<0
  RUDKP[1]=0; //car_positn==0 
  RUDKP[2]=(left_rud-mid_rud)/14;  //car_positn>0
  
  if(car_positn<=-8) temp1=-3;    
  if(car_positn<-4||car_positn>-8) temp1=-2;  
  else if(car_positn>=-4||car_positn<0) temp1=-1;  
  else if(car_positn==0) temp1=0; 
  else if(car_positn>0||car_positn<=4) temp1=1;  
  else if(car_positn>4||car_positn<8) temp1=2;  
  else if(car_positn>=8) temp1=3;  

  if(car_positn<0) temp2=-1;
  else if(car_positn==0)  temp2=0;
  else temp2=1;
  
  RErrLast=RErrCurr;  
  RErrCurr=car_positn;  
  
  Kp=Pdelta[temp1+3]*(float)RUDKP[temp2+1];  
  Kd=Ddelta[temp1+3]*(float)RUDKD[temp2+1];  
  Ruddelta=(int)(Kp*RErrCurr)+(int)(Kd*(RErrCurr-RErrLast));
  angle_data=1090-Ruddelta;
    
  if(RudPWM<960)  angle_data=960;  
  if(RudPWM>1270) angle_data=1270;
*/
} 
/*
========================================================================================

* ���������

========================-===============================================================
*/ 
void speed(void)
{    
     float p; 
     static int drive_count;                             
     brake_flag=0;
     
     if(triangle_start.flag&&triangle_en)
     {
          if(position_change==1)
          {    
              ideal_speed=speed_straight_bend;//ֱ������
          }
          else if((position_change==2)||(position_change==3)) ideal_speed=speed_bend ;
          //�����ֱ��������ڶ�����S���� ���ٶȱ��֣�׼ȷ�жϱ�־
   
          //else if(position_change==3) ideal_speed=speed_bend ;
          //������ٶȱ���                                                                 
     
          else /*if(position_change==4)*/ ideal_speed=speed_straight;//ֱ������
          ideal_speed/=2; 
     }
     
     else   
     { 
          if(position_change==1)
          {    
              ideal_speed=speed_straight_bend;//ֱ������
          }
          else if((position_change==2)||(position_change==3)) ideal_speed=speed_bend ;
          //�����ֱ��������ڶ�����S���� ���ٶȱ��֣�׼ȷ�жϱ�־
   
          //else if(position_change==3) ideal_speed=speed_bend ;
          //������ٶȱ���                                                                 
     
          else /*if(position_change==4)*/ ideal_speed=speed_straight;//ֱ������ 
     }
          
     //if(start_line_acc==1) ideal_speed=speed_narrow; 
     if((store_table[0]==tri_reduce)||(store_table[0]==tri_add)) ideal_speed=speed_tri_brank; //��⵽�����Σ�ɲ��
                                                                   
/*  if(ideal_speed>3000) p=2;     //500*p=1000   
    else if(ideal_speed>2500) p=2.5;     // 400*p=1000
    else  if(ideal_speed>2000)    p=3.3; // 300*p=1000
    else  if(ideal_speed>=1500)   p=5;   // 200*p=1000
    else     p=10;   //    100*p=1000 if(ideal_speed>=1500)  */
  //p= 6000/(float)(ideal_speed);     //ideal_speed/5*p=1000
  //-----------------------------------------------------------
       error=ideal_speed-pulse_count;    //200          //-200
       d_error = error - pre_error;      //100=200-100  //-100     
       dd_error = d_error - pre_d_error; //50=100-50    //-50
       pre_error = error;                //200=200      //-200
       pre_d_error = d_error ;           //100=100      //-100
  //-----------------------------------------------------------
  speed_error=ideal_speed-pulse_count;
      //ideal_speed=2000 p=1.3  speed_error=600
      //ideal_speed=1000 p=1.5  speed_error=500   
      
      if(speed_error>(0.015*(double)(ideal_speed-200)+30))  car_driver=drive_count;
      else if(speed_error>(-1*(0.015*(double)(ideal_speed-200)+30))) 
      {
        drive_count=0;
        kp=8.6;//-((double)(ideal_speed-200))*0.02;//0.015;
       // kp=kp*0.8; 
        pid(); 
      }
      else 
      {
        car_driver=1000; 
        brake_flag=1;
      }
     drive_count+=20;
     if(car_driver>1000) car_driver=1000;
/*  if(speed_error>0) 
  {
    car_driver=(int)(speed_error*p);
    if(car_driver>1000) car_driver=1000; 
    //else if(car_driver<0) car_driver=0; 
  }
  else 
  {
    car_driver=(int)(speed_error*p); 
    brake_flag=1;
    if(car_driver<-1000) car_driver=1000;  
  }*/
    
}
//--------------pid----------------------------- 
void pid(void)   //���
{ 
       car_driver+=kp*d_error + ki*error + kd*dd_error;  //kp 2000//2000   ki 5//1 kd 10//10    //������(speed_error>-500) 
       
       //====================================================================
       //pk+=kp*d_error + ki*error + kd*(error+pre_d_error-2*pre_error);       
       //==================================================================== 
       if(car_driver>=1000)  
       {
         car_driver=1000; 
         brake_flag=0;
       }
       
       else if(car_driver<=-1000) 
       {
         car_driver=1000; 
         brake_flag=1;
       } 

} 
  
/*
========================================================================================

* PWM���

========================-===============================================================
*/ 
void driver() 
{
   //DisableInterrupts;
   static int pre_car_driver,pre_angle_data; 
   if(pre_angle_data!=angle_data) 
   {   
      PWME_PWME1 = 0;PWMDTY01 = angle_data; PWME_PWME1 = 1; 
   }
   //EnableInterrupts;
   if(finish.flag) 
   {
      if(finish.time<2000)finish.time++;
      if((finish.time>20)&&(finish.time<1000)) stop();      //ͣ�� 
   }
   else  if(pre_car_driver!=car_driver) 
   {//

     if(brake_flag)  
     {  
        PWME_PWME3 = 0; PWMDTY23 =0; PWME_PWME3 = 1;  
        PWME_PWME7 = 0; PWMDTY67 =car_driver; PWME_PWME7 = 1;
     } 

     else
     {     
        if(dir_flag==1)  
        {
          PWME_PWME3 = 0; PWMDTY23 =car_driver;  PWME_PWME3 = 1;  
          PWME_PWME7 = 0; PWMDTY67 =0; PWME_PWME7 = 1;
        }    //��������   
           
        else if(dir_flag==2)  //times<lose_limit  //����ܵ����ٶȽ���
        {
          PWME_PWME3 = 0; PWMDTY23 =car_driver; PWME_PWME3 = 1;  
          PWME_PWME7 = 0; PWMDTY67 =0; PWME_PWME7 = 1;       
        } 
        else //if(dir_flag==3) 
        {    
          //PWME_PWME3 = 0; PWMDTY23 =900; PWME_PWME3 = 1;  
          //PWME_PWME7 = 0; PWMDTY67 =0;   PWME_PWME7 = 1;
          if(ideal_speed>pulse_count)
          {  
            car_driver=car_driver*8/10;           
            PWME_PWME3 = 0; PWMDTY23 = car_driver;  PWME_PWME3 = 1;  
            PWME_PWME7 = 0; PWMDTY67 = 0; PWME_PWME7 = 1;
          } 
          else
          { 
            car_driver=car_driver*7/10;            
            PWME_PWME3 = 0; PWMDTY23 = car_driver;  PWME_PWME3 = 1;  
            PWME_PWME7 = 0; PWMDTY67 = 0; PWME_PWME7 = 1;
          } 
        } 
 /*       else     
        {
            PWME_PWME3 = 0; PWMDTY23 =700;  PWME_PWME3 = 1;  
            PWME_PWME7 = 0; PWMDTY67 =0; PWME_PWME7 = 1;         
        }  
*/                             //���ɻ��� //dir_flag==0    
     }     
   }//
   pre_car_driver = car_driver; 
   pre_angle_data = angle_data;
}

/*
========================================================================================

*  �������㷨-tiny memory�㷨

*  ʯ��ׯ����ѧԺ

========================-===============================================================
*/ 
void car_position(void)  
{ 
   int i,k; 
   unsigned char  led_state ;
   
   pre_positn=car_positn ;
   k=pre_positn;
    
    if(black_sensor_number>0) led_state=1; //led��⵽ 
    else led_state=0;
      
     if(led_state)       
    { 
      dir_flag=1;  
      
      switch(led) 
      {
        case 0x0001 : k=-11 ; break;
        case 0x0003 : k=-10 ; break;  
        case 0x0002 : 
        case 0x0007 : k=-9 ; break;
        case 0x0006 : k=-8 ; break; 
        case 0x0004 :      
        case 0x000e : k=-7 ; break;
        case 0x000c : k=-6 ; break;
        case 0x001c :
        case 0x0008 : k=-5 ; break;
        case 0x0018 : k=-4 ; break;  
        case 0x0010 :  
        case 0x0038 : k=-3 ; break;
        case 0x0030 : k=-2 ; break;
        case 0x0020 :
        case 0x0070 : k=-1 ; break;
        case 0x0060 : k=0 ; break; 
        case 0x0040 :      
        case 0x00e0 : k=1 ; break;
        case 0x00c0 : k=2 ; break; 
        case 0x01c0 :
        case 0x0080 : k=3 ; break;
        case 0x0180 : k=4 ; break; 
        case 0x0100 :
        case 0x0380 : k=5 ; break;
        case 0x0300 : k=6 ; break;
        case 0x0200 :
        case 0x0700 : k=7 ; break;
        case 0x0600 : k=8 ; break; 
        case 0x0400 :  
        case 0x0e00 : k=9 ; break;
        case 0x0c00 : k=10 ; break;
        case 0x0800 : k=11 ; break;   
      }     
      //---------------�˲��������β��˲�--------------    
      if(
           ( 
            (((pre_positn<=-9)&&(k>9))||((pre_positn>=9)&&(k<-9)))
            && 
            (triangle_brank.flag==0)
           ) 
           // ||
           //(((pre_positn-k)<-5)||((pre_positn-k)>5))         
         )   
      {
        led_state=0;
        k=pre_positn;
      }
      else times=0;

    }    
    if(!led_state)                             
    { 
       if(times<lose_limit1)  
       {
        dir_flag=2 ;   times++;  
       }
       
        if((times>=lose_limit1)&&(times<lose_limit2))  
       {
        dir_flag=3 ;   times++;  
       }
       else  dir_flag=0;   
    } 
    car_positn=k;   
} 

//------------------------------------------------
void stop() 
{
    if(pulse_count>100) 
    { 
      PWME_PWME3 = 0;PWMDTY23 = 0;PWME_PWME3 = 1;  
      PWME_PWME7 = 0;PWMDTY67 = 600;PWME_PWME7 = 1; 
    } 
    else
    {
      PWME_PWME3 = 0;PWMDTY23 = 0;PWME_PWME3 = 1;  
      PWME_PWME7 = 0;PWMDTY67 = 0;PWME_PWME7 = 1;
    } 
} 
//------------------------------------------------ 
void Dly_ms(int ms)		
{
	 int ii,jj;
   if (ms<1) ms=1;
   for(ii=0;ii<ms;ii++)
     for(jj=0;jj<2770;jj++) ;   //32MHz--1ms        
}


/*
========================================================================================

*  ʵʱ�жϷ�����   

*  ����

=======================================================================================
*/
void interrupt 7 RTI(void){

  CRGFLG_RTIF = 1;
  PORTK_PK0=~PORTK_PK0;
  pulse_count = PACNT;  
  
  PACNT = 0;//�����ۼ���A�Ĵ�������

} 
/*
========================================================================================

*  ect_ISR�ж�    

*  ����

=======================================================================================
*/  
/*#pragma CODE_SEG NON_BANKED 
void interrupt 9 ect_ISR(void) 
{    
     static int i;
     PORTK_PK0=~PORTK_PK0; 
     if(i==1) 
     {
        pulse_count = PACNT ;
        i=0; 
        PACNT=0x0000;
        
     }
     i++; 
     TCNT = 0xffff/10000;
     TFLG1=0xff;      
}          
#pragma CODE_SEG DEFUALT  */
/*
========================================================================================

*  AD�ж� 

*  ��������״̬

=======================================================================================
*/
unsigned long int ReadATD(byte ch)
{
  unsigned long int ad=0;  
  switch(ch)
  {
    default:
    case 0:  ad= ATD0DR0L; break;
    case 1:  ad= ATD0DR1L; break;
    case 2:  ad= ATD0DR2L; break;
    case 3:  ad= ATD0DR3L; break;
    case 4:  ad= ATD0DR4L; break;
    case 5:  ad= ATD0DR5L; break;
    case 6:  ad= ATD0DR6L; break;
    case 7:  ad= ATD0DR7L; break;
    case 8:  ad= ATD0DR8L; break;
    case 9:  ad= ATD0DR9L; break;
    case 10: ad= ATD0DR10L; break;
    case 11: ad= ATD0DR11L; break;
  }
  return ad;
}
void interrupt 22 Int_AD0(void)
{
  unsigned char i;
  DisableInterrupts; 
  PORTK_PK3=~PORTK_PK3;
  
  led=0;
  for(i=0;i<12;i++) 
  {
    if(ReadATD(i)>ATD0DR12L) 
    {
      led|=1<<i;   
    }
  } 
 
  EnableInterrupts;
}
/*
========================================================================================

* �ٶ���ʾ

========================-===============================================================
*/ 
void display() 
{           
            switch(seg.flag)
            { 
              case 0 :
                    PORTE_PE5=1;                 
                    PORTE_PE6=0;  
                    PORTE_PE2=0;                 
                    PORTE_PE3=0; 
                    PORTA=seg_table[pulse_count/1000];
                    break;
              case 1 :
                    PORTE_PE5=0;                 
                    PORTE_PE6=1;  
                    PORTE_PE2=0;                 
                    PORTE_PE3=0; 
                    PORTA=seg_table[pulse_count%1000/100];
                    break;
              case 2 :
                    PORTE_PE5=0;                 
                    PORTE_PE6=0;  
                    PORTE_PE2=1;                 
                    PORTE_PE3=0; 
                    PORTA=seg_table[pulse_count%100/10];
                    break;
              case 3 :
                    PORTE_PE5=0;                 
                    PORTE_PE6=0;  
                    PORTE_PE2=0;                 
                    PORTE_PE3=1; 
                    PORTA=seg_table[pulse_count%10]; 
                    break; 
            } 
            seg.time++;
            if(seg.time>1)
             {
              seg.flag++;
              seg.time=0; 
             }
            if(seg.flag==4) seg.flag=0;
}
/*
========================================================================================

* ����ģʽ

========================-===============================================================
*/
void display_check()
{
  static unsigned char flag=1,led1;
  PWME_PWME1 = 0;PWMDTY01 = angle_data; PWME_PWME1 = 1; 
  if(flag==1) 
  {  
      PORTB=~(unsigned char)(led&0xff) ; 
      flag=2;
  }
  if(flag==2) 
  {
    led1=(unsigned char)(led>>8) ;
    flag=3 ;
  }
  switch(seg.flag)
  { 
       case 0 :
              PORTE_PE5=1;                 
              PORTE_PE6=0;  
              PORTE_PE2=0;                 
              PORTE_PE3=0;  
              PORTA=~((led1&0x01)<<7);
              break;
       case 1 :
              PORTE_PE5=0;                 
              PORTE_PE6=1;  
              PORTE_PE2=0;                 
              PORTE_PE3=0; 
              PORTA=~((led1&0x02)<<6);
              break;
       case 2 :
              PORTE_PE5=0;                 
              PORTE_PE6=0;  
              PORTE_PE2=1;                 
              PORTE_PE3=0; 
              PORTA=~((led1&0x04)<<5);
              break;
       case 3 :
              PORTE_PE5=0;                 
              PORTE_PE6=0;  
              PORTE_PE2=0;                 
              PORTE_PE3=1; 
              PORTA=~((led1&0x08)<<4);
              break; 
   } 
    seg.time++;
    if(seg.time>1)
    {
        seg.flag++;
        seg.time=0; 
    }
   if(seg.flag==4)
   {
    seg.flag=0;
    flag=1;
   }
}
