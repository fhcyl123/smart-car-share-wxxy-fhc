#ifndef _function_h_
#define _function_h_
//========================================================
 
extern void sys_init(); 
extern void path_state(void) ;
extern void car_position(void) ;

extern void angle(void) ;

extern void check_start(void) ;
extern void stop(void);
extern void stop1(void) ;

extern void speed(void);
extern void driver(void);
extern void Dly_ms(int ms); 
extern void display(void);
extern void display_check();
extern void pid(void);
extern void path_change(void); 
extern void path_judge(void);
extern void reset_other(void) ;
extern void abnormal_state(void) ;
extern void normal_state() ;
extern void start_cross_tri(void) ;
extern void store(void) ;
extern void triangle(void); 
extern unsigned long int ReadATD(byte ch);
#endif 





