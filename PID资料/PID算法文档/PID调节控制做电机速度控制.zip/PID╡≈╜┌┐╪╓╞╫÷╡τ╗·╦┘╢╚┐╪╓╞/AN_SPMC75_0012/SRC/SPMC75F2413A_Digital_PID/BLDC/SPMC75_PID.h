#ifndef	__SPMC75_PID_h__
#define	__SPMC75_PID_h__
//	write your header here
extern void PIDInit(void);

extern void PIDSetPoint(int setpoint);
extern int PIDGetSetpoint(void);

extern void PIDSetKp(double dKpp);
extern double PIDGetKp(void);

extern void PIDSetKi(double dKii);
extern double PIDGetKi(void);

extern void PIDSetKd(double dKdd);
extern double PIDGetKd(void);

extern int IncPIDCalc(int NextPoint);
extern unsigned int LocPIDCalc(int NextPoint);

#endif
