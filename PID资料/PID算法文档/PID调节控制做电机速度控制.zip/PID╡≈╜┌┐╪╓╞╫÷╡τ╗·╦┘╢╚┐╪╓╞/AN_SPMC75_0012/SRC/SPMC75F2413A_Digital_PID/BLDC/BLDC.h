#ifndef	__BLDC_H__
#define	__BLDC_H__
/*=============================================*/
/*=============================================*/
#include	".\Include\Spmc75_regs.h"
#include	".\Include\Spmc_typedef.h"
#include	".\Include\unspmacro.h"
#include	".\BLDC\SPMC75_PID.h"
/*=============================================*/
/*=============================================*/
#include 	".\DMC\Spmc75_dmc_uart_ext.h"
#include 	".\DMC\Spmc_dmc_api_ext.h"
/*=============================================*/
/*=============================================*/
//	write your header here
/* --------------------------------- */
#define		KP		0.105
/* --------------------------------- */
#define		KPP		2.45*KP
#define		KPI		3.50*KP
#define		KPD		1.25*KP
/* --------------------------------- */
#define		CAPBSIZE	16
#define		SHIFTDIV	4

/*	FCK/1@24M
8000	3.0KHz
7500	3.2KHz
6000	4.0KHz
5000	4.8KHz
4800	5.0KHz
4000	6.0KHz
3200	7.5KHz
3000	8.0KHz
2500	9.6KHz
2400	10.0KHz
*/
#define		CYCPWM	3000
#define		MAXPWM	2995
#define		MINPWM	50

#define		SETSPD	2000

typedef union CONTROLSM
{
	unsigned int W;
	
	struct 
	{
		unsigned int _startup		:1;
		unsigned int _slowflag		:1;
		unsigned int _stopflag		:1;
		unsigned int _charge		:1;
		
		unsigned int _workflag		:1;
		unsigned int _nowspeed		:1;
		
		
		unsigned int _flag			:1;
	}B;
} CONTROLSM;
extern CONTROLSM	sCtrlSM;
extern CONTROLSM	*sCSptr;


extern void IncPIDInit(void);
extern int IncPIDCalc(int NextPoint);

/*=============================================*/
/*��ȫ��
/*=============================================*/
#if CYCPWM < MAXPWM
	#error	^_^Please check whether set CYCPWM > MAXPWM?<-
#endif

#if MAXPWM < MINPWM
	#error	^_^Please check whether set MAXPWM > MINPWM?<-
#endif
/*=============================================*/
#endif
