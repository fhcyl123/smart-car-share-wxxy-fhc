/* ========================================================================= */
/* The information contained herein is the exclusive property of             */
/* Sunplus Technology Co. And shall not be distributed, reproduced,          */
/* or disclosed in whole in part without prior written permission.           */
/*             (C) COPYRIGHT 2001 SUNPLUS TECHNOLOGY CO.                     */
/*                    ALL RIGHTS RESERVED                                    */
/* The entire notice above must be reproduced on all authorized copies.      */
/* ========================================================================= */
/* File Name   : Spmc75_regs.h											     */	
/* Description : SPMC75 series register definition						     */
/* Processor   : SPMC75X series											     */	
/* Author      : Chih ming Huang										     */
/* Tools	   : u'nSP IDE tools v1.18.1A or later version				     */
/* Version     : 1.00 													     */	
/* Security    : Confidential Proprietary 							         */
/* E-Mail      : MaxHuang@sunplus.com.tw								     */
/* ========================================================================= */
#ifndef	__SPMC75_REGS_H
#define	__SPMC75_REGS_H

#include "Spmc_typedef.h"

/*****************************************************************************/
/* Define body name for this chip of SPMC75X family							 */
/*****************************************************************************/
#define SPMC75F2413A

/*****************************************************************************/
/* Register word and bit code debug mode definition, enable or not			 */
/*****************************************************************************/
//#define SPMC75_REG_DEBUG

/*****************************************************************************/
/*****************************************************************************/
/* A. CPU control register													 */
/*****************************************************************************/
/*****************************************************************************/
#define P_System_Option_ADDR			0x8000	
#define P_Wait_Enter_ADDR				0x700C
#define P_Stdby_Enter_ADDR				0x700E
#define P_Reset_Status_ADDR				0x7006
#define P_Clk_Ctrl_ADDR					0x7007
#define P_WatchDog_Ctrl_ADDR			0x700A
#define P_WatchDog_Clr_ADDR				0x700B
#define	P_Wakeup_Ctrl_ADDR				0x700F
#define P_INT_Status_ADDR				0x70A0
#define P_INT_Priority_ADDR				0x70A4
#define P_MisINT_Ctrl_ADDR				0x70A8

/*****************************************************************************/
/*****************************************************************************/
/* B. I/O Port register														 */
/*****************************************************************************/
/*****************************************************************************/
#define P_IOA_Data_ADDR					0x7060
#define P_IOA_Buffer_ADDR				0x7061
#define P_IOA_Dir_ADDR					0x7062
#define P_IOA_Attrib_ADDR				0x7063
#define P_IOA_Latch_ADDR				0x7064
#define P_IOA_SPE_ADDR					0x7080
#define	P_IOA_KCER_ADDR					0x7084

#define P_IOB_Data_ADDR					0x7068
#define P_IOB_Buffer_ADDR				0x7069
#define P_IOB_Dir_ADDR					0x706A
#define P_IOB_Attrib_ADDR				0x706B
#define P_IOB_SPE_ADDR					0x7081

#define P_IOC_Data_ADDR					0x7070
#define P_IOC_Buffer_ADDR				0x7071
#define P_IOC_Dir_ADDR					0x7072
#define P_IOC_Attrib_ADDR				0x7073
#define P_IOC_SPE_ADDR					0x7082

#define P_IOD_Data_ADDR					0x7078
#define P_IOD_Buffer_ADDR				0x7079
#define P_IOD_Dir_ADDR					0x707A
#define P_IOD_Attrib_ADDR				0x707B

/*****************************************************************************/
/*****************************************************************************/
/* C. Timer 0,Timer 1,Timer 2,Timer 3,Timer 4								 */
/*****************************************************************************/
/*****************************************************************************/
#define P_TMR0_Ctrl_ADDR			0x7400
#define P_TMR1_Ctrl_ADDR			0x7401
#define P_TMR2_Ctrl_ADDR			0x7402
#define P_TMR3_Ctrl_ADDR			0x7403
#define P_TMR4_Ctrl_ADDR			0x7404

#define P_TMR_LDOK_ADDR				0x740A

#define P_TMR0_TCNT_ADDR			0x7430
#define P_TMR1_TCNT_ADDR			0x7431
#define P_TMR2_TCNT_ADDR			0x7432
#define P_TMR3_TCNT_ADDR			0x7433
#define P_TMR4_TCNT_ADDR			0x7434

#define P_TMR0_TGRA_ADDR			0x7440
#define P_TMR0_TGRB_ADDR			0x7441
#define P_TMR0_TGRC_ADDR			0x7442

#define P_TMR1_TGRA_ADDR			0x7443
#define P_TMR1_TGRB_ADDR			0x7444
#define P_TMR1_TGRC_ADDR			0x7445

#define P_TMR2_TGRA_ADDR			0x7446
#define P_TMR2_TGRB_ADDR			0x7447

#define P_TMR3_TGRA_ADDR			0x7448
#define P_TMR3_TGRB_ADDR			0x7449
#define P_TMR3_TGRC_ADDR			0x744A
#define P_TMR3_TGRD_ADDR			0x744B

#define P_TMR4_TGRA_ADDR			0x744C
#define P_TMR4_TGRB_ADDR			0x744D
#define P_TMR4_TGRC_ADDR			0x744E
#define P_TMR4_TGRD_ADDR			0x744F

#define P_TMR0_TPR_ADDR				0x7435
#define P_TMR1_TPR_ADDR				0x7436
#define P_TMR2_TPR_ADDR				0x7437
#define P_TMR3_TPR_ADDR				0x7438
#define P_TMR4_TPR_ADDR				0x7439

#define P_TMR0_TBRA_ADDR			0x7450
#define P_TMR0_TBRB_ADDR			0x7451
#define P_TMR0_TBRC_ADDR			0x7452

#define P_TMR1_TBRA_ADDR			0x7453
#define P_TMR1_TBRB_ADDR			0x7454
#define P_TMR1_TBRC_ADDR			0x7455

#define P_TMR2_TBRA_ADDR			0x7456
#define P_TMR2_TBRB_ADDR			0x7457

#define P_TMR3_TBRA_ADDR			0x7458
#define P_TMR3_TBRB_ADDR			0x7459
#define P_TMR3_TBRC_ADDR			0x745A

#define P_TMR4_TBRA_ADDR			0x745C
#define P_TMR4_TBRB_ADDR			0x745D
#define P_TMR4_TBRC_ADDR			0x745E

#define	P_TMR0_IOCtrl_ADDR			0x7410
#define	P_TMR1_IOCtrl_ADDR			0x7411
#define	P_TMR2_IOCtrl_ADDR			0x7412
#define	P_TMR3_IOCtrl_ADDR			0x7413
#define	P_TMR4_IOCtrl_ADDR			0x7414

#define P_TMR0_INT_ADDR				0x7420
#define P_TMR1_INT_ADDR				0x7421
#define P_TMR2_INT_ADDR				0x7422
#define P_TMR3_INT_ADDR				0x7423
#define P_TMR4_INT_ADDR				0x7424

#define P_TMR0_Status_ADDR			0x7425
#define P_TMR1_Status_ADDR			0x7426
#define P_TMR2_Status_ADDR			0x7427
#define P_TMR3_Status_ADDR			0x7428
#define P_TMR4_Status_ADDR			0x7429

#define P_TMR_Start_ADDR			0x7405
#define P_TMR_Output_ADDR			0x7406

#define P_TMR3_OutputCtrl_ADDR		0x7407
#define P_TMR4_OutputCtrl_ADDR		0x7408

#define	P_POS0_DectCtrl_ADDR		0x7462
#define	P_POS1_DectCtrl_ADDR		0x7463

#define	P_POS0_DectData_ADDR		0x7464
#define	P_POS1_DectData_ADDR		0x7465

#define	P_TMR3_DeadTime_ADDR		0x7460
#define	P_TMR4_DeadTime_ADDR		0x7461

#define	P_TPWM_Write_ADDR			0x7409

#define	P_Fault1_Ctrl_ADDR			0x7466
#define	P_Fault2_Ctrl_ADDR			0x7467

#define	P_OL1_Ctrl_ADDR				0x7468
#define	P_OL2_Ctrl_ADDR				0x7469

#define	P_Fault1_Release_ADDR		0x746A
#define	P_Fault2_Release_ADDR		0x746B

/*****************************************************************************/
/*****************************************************************************/
/* D. 10-bit ADC converter register											 */
/*****************************************************************************/
/*****************************************************************************/
#define P_ADC_Setup_ADDR				0x7160
#define P_ADC_Ctrl_ADDR					0x7161
#define P_ADC_Data_ADDR					0x7162
#define P_ADC_Channel_ADDR				0x7166

/*****************************************************************************/
/*****************************************************************************/
/* E. Standard Peripheral Interface  SPI register							 */
/*****************************************************************************/
/*****************************************************************************/
#define P_SPI_Ctrl_ADDR					0x7140
#define P_SPI_TxStatus_ADDR				0x7141
#define P_SPI_TxBuf_ADDR				0x7142
#define P_SPI_RxStatus_ADDR				0x7143
#define P_SPI_RxBuf_ADDR				0x7144

/*****************************************************************************/
/*****************************************************************************/
/* F. Flash organization and control register								 */
/*****************************************************************************/
/*****************************************************************************/
#define P_Flash_RW_ADDR					0x704D	
#define P_Flash_Cmd_ADDR				0x7555

/*****************************************************************************/
/*****************************************************************************/
/* G. UART Control Register													 */
/*****************************************************************************/
/*****************************************************************************/
#define P_UART_Data_ADDR				0x7100	
#define P_UART_RXStatus_ADDR			0x7101	
#define P_UART_Ctrl_ADDR				0x7102	
#define P_UART_BaudRate_ADDR			0x7103	
#define P_UART_Status_ADDR				0x7104	

/*****************************************************************************/
/*****************************************************************************/
/* H. Compare Match Timer Register											 */				
/*****************************************************************************/
/*****************************************************************************/
#define P_CMT_Start_ADDR				0x7500
#define P_CMT_Ctrl_ADDR					0x7501
#define P_CMT0_TCNT_ADDR				0x7508
#define P_CMT1_TCNT_ADDR				0x7509
#define P_CMT0_TPR_ADDR					0x7510
#define P_CMT1_TPR_ADDR					0x7511	

/*****************************************************************************/
/*****************************************************************************/
/* I. Time Base Register													 */				
/*****************************************************************************/
/*****************************************************************************/
#define P_TMB_Reset_ADDR				0x70B8
#define P_BZO_Ctrl_ADDR					0x70B9

/*****************************************************************************/
/* Geneic register structure declaration									 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	bit0		: 1;
		UInt16	bit1		: 1;
		UInt16	bit2		: 1;
		UInt16	bit3		: 1;
		UInt16	bit4		: 1;
		UInt16	bit5		: 1;
		UInt16	bit6		: 1;
		UInt16	bit7		: 1;
		UInt16	bit8		: 1;
		UInt16	bit9		: 1;
		UInt16	bit10		: 1;
		UInt16	bit11		: 1;
		UInt16	bit12		: 1;
		UInt16	bit13		: 1;
		UInt16	bit14		: 1;
		UInt16	bit15		: 1;
	} B;
} GEN_REG_DEF;

/*****************************************************************************/
/*****************************************************************************/
/* A. CPU Control Register						 							 */
/*****************************************************************************/
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	WaitCMD		: 16;
	} B;	
} P_Wait_Enter_DEF;

typedef union
{
	UInt16	W;
	struct
	{
		UInt16	StdbyCMD	: 16;
	} B;	
} P_Stdby_Enter_DEF;

/*****************************************************************************/
/*****************************************************************************/
/* B. IO Control Register						 							 */
/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/
/* IOA Special Functions Enable Control Register (P_IOA_SPE)				 */
/* bit 8 - 0    : Reserve													 */
/* bit 9    	: TIO2AEN, P_TMR2_TGRA CCP enable							 */											 
/* bit 10    	: TIO2BEN, P_TMR2_TGRB CCP enable							 */
/* bit 11		: TCLKAEN, External clock A input pin enable				 */
/* bit 12		: TCLKBEN, External clock B input pin enable				 */
/* bit 13		: TCLKCEN, External clock C input pin enable				 */
/* bit 14		: TCLKDEN, External clock D input pin enable				 */
/* bit 15 		: Reserve													 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	Reserve1	: 9;
		UInt16	TIO2AEN		: 1;
		UInt16	TIO2BEN		: 1;		
		UInt16	TCLKAEN		: 1;
		UInt16	TCLKBEN		: 1;
		UInt16	TCLKCEN		: 1;
		UInt16	TCLKDEN		: 1;
		UInt16	Reserve2	: 1;				
	} B;	
} P_IOA_SPE_DEF;

/*****************************************************************************/
/* IOB Special Functions Enable Control Register (P_IOB_SPE)				 */
/* bit 0    	: W1NEN,  W1N phase output enable							 */
/* bit 1    	: V1NEN,  V1N phase output enable							 */
/* bit 2    	: U1NEN,  U1N phase output enable							 */
/* bit 3    	: W1EN,  W1 phase output enable							 	 */
/* bit 4    	: V1EN,  V1 phase output enable							 	 */
/* bit 5    	: U1EN,  U1 phase output enable							 	 */
/* bit 6    	: FTIN1EN, External fault protection input 1 enable			 */										 
/* bit 7    	: OL1EN, Overload protection input 1 enable					 */
/* bit 8		: TIO0CEN, P_TMR0_TGRC CCP enable				 			 */
/* bit 9		: TIO0BEN, P_TMR0_TGRB CCP enable				 			 */
/* bit 10		: TIO0AEN, P_TMR0_TGRA CCP enable				 			 */
/* bit 15 - 11	: Reserve													 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	W1NEN		: 1;
		UInt16	V1NEN		: 1;
		UInt16	U1NEN		: 1;
		UInt16	W1EN		: 1;
		UInt16	V1EN		: 1;
		UInt16	U1EN		: 1;	
		UInt16	FTIN1EN		: 1;
		UInt16	OL1EN		: 1;		
		UInt16	TIO0CEN		: 1;
		UInt16	TIO0BEN		: 1;
		UInt16	TIO0AEN		: 1;
		UInt16	Reserve		: 5;				
	} B;	
} P_IOB_SPE_DEF;

/*****************************************************************************/
/* IOC Special Functions Enable Control Register (P_IOC_SPE)				 */
/* bit 1 - 0	: Reserve													 */
/* bit 2    	: EXINT0EN,  External interrupt input 0 enable 				 */
/* bit 3    	: EXINT1EN,  External interrupt input 1 enable				 */
/* bit 4    	: Reserve													 */
/* bit 5    	: TIO1AEN,  P_TMR1_TGRA	CCP enable						 	 */
/* bit 6    	: TIO1BEN,  P_TMR1_TGRB	CCP enable						 	 */
/* bit 7    	: TIO1CEN,  P_TMR1_TGRC	CCP enable						 	 */
/* bit 8    	: OL2EN,  Overload protection input 2 enable			 	 */
/* bit 9    	: FTIN2EN,  External fault protection input 2 enable	 	 */
/* bit 10    	: U2EN, U2 phase output enable								 */										 
/* bit 11    	: V2EN, V2 phase output enable								 */		
/* bit 12    	: W2EN, W2 phase output enable								 */		
/* bit 13    	: U2NEN, U2N phase output enable							 */										 
/* bit 14    	: V2NEN, V2N phase output enable							 */		
/* bit 15    	: W2NEN, W2N phase output enable							 */		
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	Reserve1	: 2;
		UInt16	EXINT0EN	: 1;
		UInt16	EXINT1EN	: 1;
		UInt16	Reserve2	: 1;		
		UInt16	TIO1AEN		: 1;
		UInt16	TIO1BEN		: 1;
		UInt16	TIO1CEN		: 1;	
		UInt16	OL2EN		: 1;
		UInt16	FTIN2EN		: 1;		
		UInt16	U2EN		: 1;
		UInt16	V2EN		: 1;
		UInt16	W2EN		: 1;
		UInt16	U2NEN		: 1;
		UInt16	V2NEN		: 1;
		UInt16	W2NEN		: 1;					
	} B;	
} P_IOC_SPE_DEF;

/*****************************************************************************/
/* IOA  Keychange Enable Control Register (P_IOA_KCER)				 		 */
/* bit 7 - 0    : Reserve													 */
/* bit 8    	: KC8EN, PortA.8 Key change enable						 	 */											 
/* bit 9    	: KC9EN, PortA.9 Key change enable						 	 */	
/* bit 10    	: KC10EN, PortA.10 Key change enable						 */	
/* bit 11    	: KC11EN, PortA.11 Key change enable						 */	
/* bit 12    	: KC12EN, PortA.12 Key change enable						 */	
/* bit 13    	: KC13EN, PortA.13 Key change enable						 */	
/* bit 14    	: KC14EN, PortA.14 Key change enable						 */	
/* bit 15    	: KC15EN, PortA.15 Key change enable						 */	
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	Reserve1	: 8;
		UInt16	KC8EN		: 1;
		UInt16	KC9EN		: 1;
		UInt16	KC10EN		: 1;
		UInt16	KC11EN		: 1;
		UInt16	KC12EN		: 1;
		UInt16	KC13EN		: 1;
		UInt16	KC14EN		: 1;
		UInt16	KC15EN		: 1;												
	} B;	
} P_IOA_KCER_DEF;

/*****************************************************************************/
/*****************************************************************************/
/* C. Timer0/Timer1/Timer2/Timer3/Timer4 register							 */
/*****************************************************************************/
/*****************************************************************************/
/* Timer 0 controlregister (P_TMR0_Ctrl)								     */
/* Timer 1 controlregister (P_TMR1_Ctrl)									 */
/* Timer 2 controlregister (P_TMR2_Ctrl)									 */
/* bit 2 - 0    : TMRPS, clock source A frequency selection					 */
/*				= 000, Counts on FCK /1										 */
/*				= 001, Counts on FCK /4										 */		
/*				= 010, Counts on FCK /16									 */	
/*				= 011, Counts on FCK /64									 */
/*				= 100, Counts on FCK /256									 */
/*				= 101, Counts on FCK /1024									 */
/*				= 110, Counts on TCLKA pin input 							 */
/*				= 111, Counts on TCLKB pin input 							 */
/* bit 4 - 3    : CKEGS, Clock edge select									 */											 
/*				= 00, Count at rising edge									 */	
/*				= 01, Count at falling edge									 */
/*				= 1X, Count at both edges 									 */
/* bit 7 - 5    : CCLS, Counter clear source select							 */	
/*				= 000, TCNT clearing disabled								 */
/*				= 001, TCNT cleared by TGRA capture input					 */
/*				= 010, TCNT cleared by TGRB capture input					 */
/*				= 011, TCNT cleared by TGRC capture input					 */
/*				= 100, TCNT cleared by every PDR change 6 times				 */
/*				= 101, TCNT cleared by every PDR change 3 times				 */	
/*				= 110, TCNT cleared by P_POS0/1_Data change			 		 */
/*				= 111, TCNT cleared by P_TMR1/2_TPR compare match		 	 */
/* bit 9 - 8    : CLEGS, Counter clear edge select. 						 */
/*				= 00, do not clear											 */
/*				= 01, rising edge											 */
/*				= 10, falling edge											 */		
/*				= 11, both edge												 */
/* bit 13 - 10  : MODE, select the timer operation modes					 */
/*				= 0000, Normal operation 									 */
/*				  (counter up-counting, compare match output mode)			 */
/*				= 0100, Phase counting mode 1 								 */
/*				= 0101, Phase counting mode 2 								 */
/*				= 0110, Phase counting mode 3 								 */
/*				= 0111, Phase counting mode 4 								 */	
/*				= 1x0x, Edge-aligned PWM mode (counter up-count, PWM output) */
/*				= 1x1x, Center-aligned PWM mode 					         */
/*				  (counter continuous up-/down-count, PWM output)	         */
/* bit 15 - 14  : SPCK, Capture input sample clock select					 */
/*				= 00, FCK/1													 */		
/*				= 01, FCK/2													 */		
/*				= 10, FCK/4													 */		
/*				= 11, FCK/8													 */		
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TMRPS		: 3;
		UInt16	CKEGS		: 2;
		UInt16	CCLS		: 3;
		UInt16	CLEGS		: 2;
		UInt16	MODE		: 4;
		UInt16	SPCK		: 2;
	} B;	
} P_TMR0_Ctrl_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TMRPS		: 3;
		UInt16	CKEGS		: 2;
		UInt16	CCLS		: 3;
		UInt16	CLEGS		: 2;
		UInt16	MODE		: 4;
		UInt16	SPCK		: 2;
	} B;	
} P_TMR1_Ctrl_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TMRPS		: 3;
		UInt16	CKEGS		: 2;
		UInt16	CCLS		: 3;
		UInt16	CLEGS		: 2;
		UInt16	MODE		: 4;
		UInt16	SPCK		: 2;
	} B;	
} P_TMR2_Ctrl_DEF;
/*****************************************************************************/
/* Timer 3 control register (P_TMR3_Ctrl)									 */	
/* Timer 4 control register (P_TMR4_Ctrl)									 */
/* bit 2 - 0	: TMRPS, clock source A frequency selection					 */
/*				= 000, Counts on FCK /1										 */		
/*				= 001, Counts on FCK /4										 */	
/*				= 010, Counts on FCK /16									 */
/*				= 011, Counts on FCK /64									 */
/*				= 100, Counts on FCK /256									 */
/*				= 101, Counts on FCK /1024									 */	
/*				= 110, Counts on TCLKA pin input 							 */
/*				= 111, Counts on TCLKB pin input 							 */
/* bit 4 - 3	: CKEGS, Clock edge select									 */											 
/*				= 00, Count at rising edge									 */
/*				= 01, Count at falling edge									 */	
/*				= 1X, Count at both edges 									 */
/* bit 7 - 5	: CCLS, Counter clear source select							 */	
/*				= 000, TCNT clearing disabled								 */	
/*				= 001, Reserved												 */
/*				= 010, Reserved												 */	
/*				= 011, Reserved												 */	
/*				= 011, Reserved												 */			
/*				= 100, Reserved											     */
/*				= 101, Reserved												 */	
/*				= 111, TCNT cleared by P_TMR3/4_TPR compare match			 */
/* bit 9:8		: Reserve													 */
/* bit 13 - 10	: MODE, timer mode selection								 */
/*				= 0xxx, Normal operation 									 */
/*				  (counter up-counting, compare match output mode)			 */
/*				= 1x0x, Edge-aligned PWM mode (counter up-count, PWM output) */
/*				= 1x1x, Center-aligned PWM mode 							 */
/*				  (counter continuous up-/down-count, PWM output)	  		 */
/* bit 15 - 14	: PRDINT,  TPR interrupt frequency select					 */
/*				= 00, Interrupt every period								 */
/*				= 01, Interrupt once every 2 periods						 */	
/*				= 10, Interrupt once every 4 periods						 */
/*				= 11, Interrupt once every 8 periods						 */			
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TMRPS		: 3;
		UInt16	CKEGS		: 2;
		UInt16	CCLS		: 3;
		UInt16	Reserved	: 2;
		UInt16	MODE		: 4;
		UInt16	PRDINT		: 2;
	} B;	
} P_TMR3_Ctrl_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TMRPS		: 3;
		UInt16	CKEGS		: 2;
		UInt16	CCLS		: 3;
		UInt16	Reserved	: 2;
		UInt16	MODE		: 4;
		UInt16	PRDINT		: 2;
	} B;	
} P_TMR4_Ctrl_DEF;

/*****************************************************************************/
/* Timer TMR Load Ok (P_TMR_LDOK)									 		 */	
/* bit 0		: LDOK0, P_TMR3_TGRA-C ok to load bit					 	 */
/* bit 1		: LDOK1, P_TMR4_TGRA-C ok to load bit						 */											 
/* bit 7 - 2	: TLDCHK, Timer load register check bits					 */	
/* bit 15:8		: Reserve													 */	
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	LDOK0		: 1;
		UInt16	LDOK1		: 1;
		UInt16	TLDCHK		: 6;
		UInt16	Reserved	: 8;
	} B;	
} P_TMR_LDOK_DEF;

/*****************************************************************************/
/* Timer 0/1 IO Control register (P_TMR0/1_IOCtrl)							 */
/* bit 3 - 0   : IOAMODE, Select Timer0/1 IOA Configurartion 				 */
/* bit 7 - 4   : IOBMODE, Select Timer0/1 IOB Configurartion 				 */
/* bit 11 - 8  : IOCMODE, Select Timer0/1 IOC Configurartion 				 */
/*				Compare Mode:												 */
/*				= 0000, Initial output 0, 0 output at compare match			 */
/*				= 0001, Initial output 0, 1 output at compare match			 */
/*				= 0010, Initial output 1, 0 output at compare match			 */
/*				= 0011, Initial output 1, 1 output at compare match			 */
/*				= 01xx, Output hold											 */
/*				Capture Mode												 */
/*				= 1000, Issue input capture interrupt at rising edge		 */
/*				= 1001, Issue input capture interrupt at falling edge		 */
/*				= 101x, Issue input capture interrupt at both edges			 */
/*				= 11xx, Input capture when Position Detection Register 		 */
/*				  changes (capture Timer Counter Register value 			 */
/*				  to Timer General Register) and issue interrupt 			 */
/*				  (for Timer General A Register only)						 */
/* bit 15 - 12 : Reserve												 	 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	IOAMODE		: 4;
		UInt16	IOBMODE		: 4;
		UInt16	IOCMODE		: 4;
		UInt16	Reserved	: 4;	
	} B;
} P_TMR0_IOCtrl_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	IOAMODE		: 4;
		UInt16	IOBMODE		: 4;
		UInt16	IOCMODE		: 4;
		UInt16	Reserved	: 4;	
	} B;
} P_TMR1_IOCtrl_DEF;
/*****************************************************************************/
/* Timer 2 IO Control register (P_TMR2_IOCtrl)								 */
/* bit 3 - 0  : IOAMODE, Select Timer2 IOA Configurartion 					 */
/* bit 7 - 4  : IOBMODE, Select Timer2 IOB Configurartion 					 */						
/* bit 15 - 8 : Reserved													 */
/*				Compare Mode:												 */
/*				= 0000, Initial output 0, 0 output at compare match			 */
/*				= 0001, Initial output 0, 1 output at compare match			 */
/*				= 0010, Initial output 1, 0 output at compare match			 */
/*				= 0011, Initial output 1, 1 output at compare match			 */
/*				= 01xx, Output hold											 */
/*				Capture Mode												 */
/*				= 1000, Issue input capture interrupt at rising edge		 */
/*				= 1001, Issue input capture interrupt at falling edge		 */
/*				= 101x, Issue input capture interrupt at both edges			 */
/*				= 11xx, Reserve									 			 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	IOAMODE		: 4;
		UInt16	IOBMODE		: 4;
		UInt16	Reserved	: 8;	
	} B;
} P_TMR2_IOCtrl_DEF;

/*****************************************************************************/
/* Timer 3/4 IO Control register (P_TMR3/4_IOCtrl)							 */
/* bit 3 - 0  : IOAMODE, Select Timer3/4 IOA Configurartion 				 */
/* bit 7 - 4  : IOBMODE, Select Timer3/4 IOB Configurartion 				 */
/* bit 11 - 8 : IOCMODE, Select Timer3/4 IOC Configurartion 				 */
/* 				Compare Mode,												 */
/*				= 0000, Initial output 0, 0 output at compare match			 */
/*				= 0001, Initial output 0, 1 output at compare match			 */
/*				= 0010, Initial output 1, 0 output at compare match			 */
/*				= 0011, Initial output 1, 1 output at compare match			 */
/*				= 01xx, Output hold											 */
/*				= 1xxx, Reserve								 				 */
/* bit 12 - 15: Reserved													 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	IOAMODE		: 4;
		UInt16	IOBMODE		: 4;
		UInt16	IOCMODE		: 4;
		UInt16	Reserved	: 4;	
	} B;
} P_TMR3_IOCtrl_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	IOAMODE		: 4;
		UInt16	IOBMODE		: 4;
		UInt16	IOCMODE		: 4;
		UInt16	Reserved	: 4;	
	} B;
} P_TMR4_IOCtrl_DEF;
/*****************************************************************************/
/* Timer 0/1 Interrupt Enable Register (P_TMR0/1_INT)						 */
/* bit 0  	: TGAIE, Timer General A Register interrupt enable bit			 */
/* bit 1  	: TGBIE, Timer General B Register interrupt enable bit			 */
/* bit 2  	: TGCIE, Timer General C Register interrupt enable bit			 */
/* bit 3  	: Reserve														 */
/* bit 4  	: TPRIE, Timer Period Register interrupt enable bit				 */
/* bit 5  	: TCVIE, Overflow interrupt enable bit							 */
/* bit 6  	: TCUIE, Underflow interrupt enable bit							 */
/* bit 7  	: TADSE, A/D conversion start request enable bit				 */
/* bit 8  	: PDCIE, Position detection change interrupt enable bit			 */
/* bit 9:15	: Reserve													  	 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TGAIE		: 1;
		UInt16	TGBIE		: 1;
		UInt16	TGCIE		: 1;
		UInt16	Reserved1	: 1;	
		UInt16  TPRIE		: 1;
		UInt16  TCVIE      	: 1;
		UInt16  TCUIE		: 1;
		UInt16  TADSE		: 1;
		UInt16  PDCIE		: 1; 	
		UInt16  Reserved2 	: 7; 	
	} B;
} P_TMR0_INT_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TGAIE		: 1;
		UInt16	TGBIE		: 1;
		UInt16	TGCIE		: 1;
		UInt16	Reserved1	: 1;	
		UInt16  TPRIE		: 1;
		UInt16  TCVIE      	: 1;
		UInt16  TCUIE		: 1;
		UInt16  TADSE		: 1;
		UInt16  PDCIE		: 1; 	
		UInt16  Reserved2 	: 7; 	
	} B;
} P_TMR1_INT_DEF;
/*****************************************************************************/
/* Timer 2 Interrupt Enable Register (P_TMR2_INT)							 */
/* bit 0  	  : TGAIE, Timer General A Register interrupt enable bit		 */
/* bit 1  	  : TGBIE, Timer General B Register interrupt enable bit		 */
/* bit 3 - 2  : Reserve														 */	
/* bit 4  	  : TPRIE, Timer Period Register interrupt enable bit			 */
/* bit 6 - 5  : Reserve														 */
/* bit 7  	  : TADSE, A/D conversion start request enable bit				 */
/* bit 15 - 8 : Reserve													 	 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TGAIE		: 1;
		UInt16	TGBIE		: 1;
		UInt16	Reserved1	: 2;	
		UInt16  TPRIE		: 1;
		UInt16  Reserved2  	: 2;
		UInt16  TADSE		: 1;
		UInt16  Reserved3   : 8; 	
	} B;
} P_TMR2_INT_DEF;

/*****************************************************************************/
/* Timer 3/4 Interrupt Enable Register (P_TMR3/4_INT)						 */
/* bit 2 - 0  : Reserve														 */
/* bit 3  	  : TGDIE, Timer General D Register interrupt enable bit		 */
/* bit 4  	  : TPRIE, Timer Period Register interrupt enable bit			 */
/* bit 6 - 5  : Reserve														 */
/* bit 7  	  : TADSE, A/D conversion start request enable bit				 */
/* bit 15 - 8 : Reserve														 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	Reserved1	: 3;
		UInt16	TGDIE		: 1;	
		UInt16  TPRIE		: 1;
		UInt16  Reserved2  	: 2;
		UInt16  TADSE		: 1;
		UInt16  Reserved3   : 8; 	
	} B;
} P_TMR3_INT_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	Reserved1	: 3;
		UInt16	TGDIE		: 1;	
		UInt16  TPRIE		: 1;
		UInt16  Reserved2  	: 2;
		UInt16  TADSE		: 1;
		UInt16  Reserved3   : 8; 	
	} B;
} P_TMR4_INT_DEF;
/*****************************************************************************/
/* Timer 0/1 Interrupt Status Register (P_TMR0/1_Status)					 */
/* bit 0  	: TGAIF, Timer General A Register capture/output compare flag	 */
/* bit 1  	: TGBIF, Timer General B Register capture/output compare flag	 */
/* bit 2  	: TGCIF, Timer General C Register capture/output compare flag	 */
/* bit 3  	: Reserve														 */
/* bit 4  	: TPRIF, Timer Period Register output compare flag				 */
/* bit 5  	: TCVIF, Timer Counter Overflow flag							 */
/* bit 6  	: TCUIF, Timer Counter Underflow flag							 */
/* bit 7  	: TCDF, Timer Counter Count direction flag						 */
/* bit 8  	: PDCIF, Position detection change interrupt enable bit			 */
/* bit 9:15	: Reserve														 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TGAIF		: 1;
		UInt16	TGBIF		: 1;
		UInt16	TGCIF		: 1;
		UInt16	Reserved1	: 1;	
		UInt16  TPRIF		: 1;
		UInt16  TCVIF      	: 1;
		UInt16  TCUIF		: 1;
		UInt16  TCDF		: 1;
		UInt16  PDCIF		: 1; 	
		UInt16  Reserved2   : 7; 	
	} B;
} P_TMR0_Status_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TGAIF		: 1;
		UInt16	TGBIF		: 1;
		UInt16	TGCIF		: 1;
		UInt16	Reserved1	: 1;	
		UInt16  TPRIF		: 1;
		UInt16  TCVIF      	: 1;
		UInt16  TCUIF		: 1;
		UInt16  TCDF		: 1;
		UInt16  PDCIF		: 1; 	
		UInt16  Reserved2   : 7; 	
	} B;
} P_TMR1_Status_DEF;
/*****************************************************************************/
/* Timer 2 Interrupt Status Register (P_TMR2_Status)						 */
/* bit 0  	  : TGAIF, Timer General A Register capture/output compare flag	 */
/* bit 1  	  : TGBIF, Timer General B Register capture/output compare flag  */
/* bit 3 - 2  : Reserve  													 */	
/* bit 4  	  : TPRIF, Timer Period Register output compare flag			 */
/* bit 6 - 5  : Reserve														 */	
/* bit 7  	  : TCDF, Timer Counter Count direction flag					 */
/* bit 15 - 8 : Reserve														 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TGAIF		: 1;
		UInt16	TGBIF		: 1;
		UInt16	Reserved1	: 2;	
		UInt16  TPRIF		: 1;
		UInt16  Reserved2  	: 2;
		UInt16  TCDF		: 1;
		UInt16  Reserved3   : 8; 	
	} B;
} P_TMR2_Status_DEF;

/*****************************************************************************/
/* Timer 3/4 Interrupt Status Register (P_TMR3/4_Status)					 */
/* bit 2 - 0  : Reserve														 */
/* bit 3  	  : TGDIF, Timer General D Register capture/output compare flag	 */
/* bit 4  	  : TPRIF, Timer Period Register output compare flag			 */
/* bit 6 - 5  : Reserve														 */
/* bit 7  	  : TCDF, Timer Counter Count direction flag					 */
/* bit 15 - 8 : Reserve														 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	Reserved1	: 3;
		UInt16	TGDIF		: 1;	
		UInt16  TPRIF		: 1;
		UInt16  Reserved2  	: 2;
		UInt16  TCDF		: 1;
		UInt16  Reserved3   : 8; 	
	} B;
} P_TMR3_Status_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	Reserved1	: 3;
		UInt16	TGDIF		: 1;	
		UInt16  TPRIF		: 1;
		UInt16  Reserved2  	: 2;
		UInt16  TCDF		: 1;
		UInt16  Reserved3   : 8; 	
	} B;
} P_TMR4_Status_DEF;
/*****************************************************************************/
/* Timer Start Counter Status Register (P_TMR_Start)						 */
/* bit 0  	  : TMR0ST, Timer 0 counter start setting						 */
/* bit 1  	  : TMR1ST, Timer 1 counter start setting						 */
/* bit 2  	  : TMR2ST, Timer 2 counter start setting						 */
/* bit 3  	  : TMR3ST, Timer 3 counter start setting						 */
/* bit 4  	  : TMR4ST, Timer 4 counter start setting					  	 */
/* bit 15 - 5 : Reserve														 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TMR0ST		: 1;
		UInt16	TMR1ST		: 1;
		UInt16	TMR2ST		: 1;	
		UInt16  TMR3ST		: 1;
		UInt16  TMR4ST     	: 1;
		UInt16  Reserved    : 11; 	
	} B;
} P_TMR_Start_DEF;

/*****************************************************************************/
/* Timer Output Enable Register (P_TMR_Output)								 */
/* bit 0  	  : TMR3AOE: Timer 3 IOA Output enable(TIO3A)					 */
/* bit 1  	  : TMR3BOE: Timer 3 IOB Output enable(TIO3B)					 */
/* bit 2  	  : TMR3COE: Timer 3 IOC Output enable(TIO3C)					 */
/* bit 3  	  : TMR3DOE: Timer 3 IOD Output enable(TIO3D)					 */
/* bit 4  	  : TMR3EOE: Timer 3 IOE Output enable(TIO3E)					 */
/* bit 5  	  : TMR3FOE: Timer 3 IOF Output enable(TIO3F)					 */
/* bit 7 - 6  : Reserve														 */
/* bit 8  	  : TMR4AOE: Timer 4 IOA Output enable(TIO4A)					 */
/* bit 9  	  : TMR4BOE: Timer 4 IOB Output enable(TIO4B)					 */
/* bit 10     : TMR4COE: Timer 4 IOC Output enable(TIO4C)					 */
/* bit 11     : TMR4DOE: Timer 4 IOD Output enable(TIO4D)					 */
/* bit 12  	  : TMR4EOE: Timer 4 IOE Output enable(TIO4E)					 */
/* bit 13  	  : TMR4FOE: Timer 4 IOF Output enable(TIO4F)					 */
/* bit 15 - 14: Reserve														 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TMR3AOE		: 1;
		UInt16	TMR3BOE		: 1;
		UInt16	TMR3COE		: 1;
		UInt16	TMR3DOE		: 1;
		UInt16	TMR3EOE		: 1;
		UInt16	TMR3FOE		: 1;						
		UInt16  Reserved1   : 2; 	
		UInt16	TMR4AOE		: 1;
		UInt16	TMR4BOE		: 1;
		UInt16	TMR4COE		: 1;
		UInt16	TMR4DOE		: 1;
		UInt16	TMR4EOE		: 1;
		UInt16	TMR4FOE		: 1;						
		UInt16  Reserved2   : 2;
	} B;
} P_TMR_Output_DEF;

/*****************************************************************************/
/* Timer 3/4 Output Control Register (P_TMR3/4_OutputCtrl)					 */
/* Bit 1 - 0    : UOC, U phase output contro								 */ 		
/* Bit 3 - 2    : VOC, V phase output control								 */
/* Bit 5 - 4    : WOC, W phase output control								 */
/* bit 7 - 6    : SYNC,  UVW phases output synchronization source select. 	 */
/*				= 00, No sync												 */	
/*				= 01, Synchronized to Position Detection Register change	 */	
/*				= 10, Synchronized to Timer General B Register compare match */	
/*				= 11, Synchronized to Timer General C Register compare match */
/* bit 8  		: UPWM, U phase PWM output select							 */		
/* bit 9  		: VPWM, V phase PWM output select							 */	
/* bit 10  		: WPWM, W phase PWM output select							 */
/* bit 13 - 11 	: Reserve													 */		
/* bit 14  		: POLP, Upper phase polarity select							 */	
/* bit 15  		: DUTYMODE, Duty mode select								 */		
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	UOC			: 2;
		UInt16	VOC			: 2;
		UInt16	WOC			: 2;
		UInt16	SYNC		: 2;
		UInt16	UPWM		: 1;
		UInt16	VPWM		: 1;						
		UInt16  WPWM		: 1; 	
		UInt16	Reserved	: 3;
		UInt16	POLP		: 1;
		UInt16	DUTYMODE	: 1;
	} B;
} P_TMR3_OutputCtrl_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	UOC			: 2;
		UInt16	VOC			: 2;
		UInt16	WOC			: 2;
		UInt16	SYNC		: 2;
		UInt16	UPWM		: 1;
		UInt16	VPWM		: 1;						
		UInt16  WPWM		: 1; 	
		UInt16	Reserved	: 3;
		UInt16	POLP		: 1;
		UInt16	DUTYMODE	: 1;
	} B;
} P_TMR4_OutputCtrl_DEF;
/*****************************************************************************/
/* Timer 0/1 Position Detection Control Register (P_POS0/1_DectCtrl)		 */
/* Bit 6 - 0  : SPDLY, Sampling delay										 */
/* Bit 7 	  : PDEN, Position detection enable								 */
/* Bit 11 - 8 : SPLCNT, Sampling count select								 */
/* bit 13 - 12: SPLMOD, Sampling mode select								 */
/*				= 00, Sample when PWM is on									 */		
/*				= 01, Sample regularly										 */		
/*				= 10, Sample when lower phases conducting current			 */			
/*				= 11, Reserved												 */
/* bit 15 - 14: SPLCK, Sampling clock select								 */		
/*				= 00, FCK/4													 */		
/*				= 01, FCK/8													 */	
/*				= 10, FCK/32										  		 */
/*				= 11, FCK/128												 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	SPDLY		: 7;
		UInt16	PDEN		: 1;
		UInt16	SPLCNT		: 4;
		UInt16	SPLMOD		: 2;
		UInt16	SPLCK		: 2;
	} B;
} P_POS0_DectCtrl_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	SPDLY		: 7;
		UInt16	PDEN		: 1;
		UInt16	SPLCNT		: 4;
		UInt16	SPLMOD		: 2;
		UInt16	SPLCK		: 2;
	} B;
} P_POS1_DectCtrl_DEF;
/*****************************************************************************/
/* Timer 0/1 Position Detection Data Register (P_POS0/1_DectData)			 */
/* Bit 2 - 0 	: PDR0/1													 */	
/*		PDR0[2] : Noise filtered position detection input from pin TIO/10C	 */
/*		PDR0[1] : Noise filtered position detection input from pin TIO/10B	 */
/*		PDR0[0] : Noise filtered position detection input from pin TIO/10A	 */
/* bit 15 - 3	: Reserve													 */	
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	PDR0		: 3;
		UInt16	Reserved	: 13;
	} B;
} P_POS0_DectData_DEF;

typedef union
{
	UInt16	W;
	struct
	{
		UInt16	PDR1		: 3;
		UInt16	Reserved	: 13;
	} B;
} P_POS1_DectData_DEF;

/*****************************************************************************/
/* Timer 3/4 Dead Time Control Register(P_TMR3/4_DeadTime)					 */
/* Bit 6 - 0  : DTP, Dead-time timer period									 */
/* Bit 11 - 7 : Reserve													 	 */	
/* Bit 12 	  : DTUE, Dead-time timer enable for U phases 					 */
/* Bit 13 	  : DTVE, Dead-time timer enable for V phases 					 */
/* Bit 14 	  : DTWE, Dead-time timer enable for W phases 					 */
/* Bit 15	  : Reserve														 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	DTP			: 7;
		UInt16	Reserved1	: 5;
		UInt16	DTUE		: 1;
		UInt16	DTVE		: 1;
		UInt16	DTWE		: 1;
		UInt16	Reserved2	: 1;		
	} B;
} P_TMR3_DeadTime_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	DTP			: 7;
		UInt16	Reserved1	: 5;
		UInt16	DTUE		: 1;
		UInt16	DTVE		: 1;
		UInt16	DTWE		: 1;
		UInt16	Reserved2	: 1;		
	} B;
} P_TMR4_DeadTime_DEF;
/*****************************************************************************/
/* Timer/PWM Module Write Enable Control Register(P_TPWM_Write)			 	 */
/* Bit 0 	 : TMR3WE, Timer 3 setting registers write enable select		 */
/* Bit 1 	  : TMR4WE, Timer 4 setting registers write enable select		 */
/* Bit 15 - 2 : Reserve														 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	TMR3WE		: 1;
		UInt16	TMR4WE		: 1;
		UInt16	Reserved	: 14;		
	} B;
} P_TPWM_Write_DEF;

/*****************************************************************************/
/* Fault Input 1/2 Control and Status Register(P_Fault1/2_Ctrl)				 */
/* Bit 3 - 0  : FTCNT, Fault protection sampling time						 */
/* Bit 4	  : Reserve														 */
/* Bit 5 	  : FTPINIF, Fault input 1/2 status flag						 */
/* Bit 6	  : FTPINIE, Fault input 1/2 interrupt enable				     */
/* Bit 7 	  : FTPINE,  Fault input pin 1/2 enable							 */	
/* Bit 11 - 8 : Reserve														 */	
/* Bit 12 	  : OSF,  Output short flag										 */		
/* Bit 13	  : OCLS, Output compare polarity level select					 */
/* Bit 14:	  : OCIE, Output compare interrupt enable						 */		
/* Bit 15:	  : OCE,  Output compare enable									 */	
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	FTCNT		: 4;
		UInt16	Reserved1	: 1;
		UInt16	FTPINIF		: 1;
		UInt16	FTPINIE		: 1;
		UInt16	FTPINE		: 1;
		UInt16	Reserved2	: 4;		
		UInt16	OSF			: 1;
		UInt16	OCLS		: 1;
		UInt16	OCIE		: 1;
		UInt16	OCE			: 1;	
	} B;
} P_Fault1_Ctrl_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	FTCNT		: 4;
		UInt16	Reserved1	: 1;
		UInt16	FTPINIF		: 1;
		UInt16	FTPINIE		: 1;
		UInt16	FTPINE		: 1;
		UInt16	Reserved2	: 4;		
		UInt16	OSF			: 1;
		UInt16	OCLS		: 1;
		UInt16	OCIE		: 1;
		UInt16	OCE			: 1;	
	} B;
} P_Fault2_Ctrl_DEF;
/*****************************************************************************/
/* Overload Protection 1/2 Control/Status Register (P_OL1/2_Ctrl)			 */
/* (P_TMR3/4_OLProtect)														 */
/* Bit 3 - 0  : OLCNT, Overload protection sampling time					 */
/* Bit 5 - 4  : Reserve														 */
/* Bit 6	  : OLIF,  Overload interrupt flag								 */
/* Bit 7	  : OLIE, Overload interrupt enable bit							 */	
/* Bit 8 	  : RTOL, Return from overload protection state					 */	
/* Bit 9 	  : RTPWM, Return from PWM sync enable bit						 */
/* Bit 10 	  : RTTMB, Return from P_TMR0/1_TGRB register compare match 	 */	
/*				interrupt enable bit										 */
/* Bit 11	  : OLST, Overload protection status							 */
/* Bit 12:13  : OLMD, Output disabled phases during overload protection		 */
/* Bit 14:	  : CNTSP,Stop PWM counter during overload protection select	 */	
/* Bit 15:	  : OLEN, Overload protection enable							 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	OLCNT		: 4;
		UInt16	Reserved	: 2;
		UInt16	OLIF		: 1;
		UInt16	OLIE		: 1;
		UInt16	RTOL		: 1;
		UInt16	RTPWM		: 1;
		UInt16	RTTMB		: 1;			
		UInt16	OLST		: 1;
		UInt16	OLMD		: 2;
		UInt16	CNTSP		: 1;
		UInt16	OLEN		: 1;	
	} B;
} P_OL1_Ctrl_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	OLCNT		: 4;
		UInt16	Reserved	: 2;
		UInt16	OLIF		: 1;
		UInt16	OLIE		: 1;
		UInt16	RTOL		: 1;
		UInt16	RTPWM		: 1;
		UInt16	RTTMB		: 1;			
		UInt16	OLST		: 1;
		UInt16	OLMD		: 2;
		UInt16	CNTSP		: 1;
		UInt16	OLEN		: 1;	
	} B;
} P_OL2_Ctrl_DEF;
/*****************************************************************************/
/* Fault 1/2 Flag Release Register(P_Fault1/2_Release)						 */
/* bit 0 - 15  : FTRR														 */												
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16  FTRR	: 16;		
	} B;
} P_Fault1_Release_DEF;
typedef union
{
	UInt16	W;
	struct
	{
		UInt16  FTRR	: 16;		
	} B;
} P_Fault2_Release_DEF;
/*****************************************************************************/
/*****************************************************************************/
/* L. 10-bit ADC converter register											 */
/*****************************************************************************/
/*****************************************************************************/
/* ADC Setup register (P_ADC_Setup)											 */
/* bit 6:0   	:Reserve													 */
/* bit 7	:ASPEN, Auto Sampling mode enable								 */		 
/* bit 8	:ADCEXTRG, external ADC conversion request trigger from PB8 pad	 */ 
/* bit 10:9	:ADCFS, A/D converter clock selection							 */
/*				=00: CPUCLK /8												 */
/*				=01: CPUCLK /16												 */
/*				=10: CPUCLK /32												 */	
/*				=11: CPUCLK /64												 */
/* bit 11	:Reserve														 */		 
/* bit 12	:VRXEN, AD Top voltage Source Selection							 */
/* bit 13  	:Reserve														 */ 
/* bit 14	:ADCEN,	ADC converter enable									 */		 
/* bit 15	:ADCCS,	ADC converter chip select. (ADC Power on)				 */			
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	Reserved1	: 7;
		UInt16	ASPEN		: 1;
		UInt16	ADCEXTRG	: 1;	
		UInt16	ADCFS		: 2;
		UInt16	Reserved2	: 1;
		UInt16	VRXEN		: 1;	
		UInt16	Reserved3	: 1;
		UInt16	ADCEN		: 1;				
		UInt16	ADCCS		: 1;
	} B;	
} P_ADC_Setup_DEF;

/*****************************************************************************/
/* ADC control register (P_ADC_Ctrl)										 */
/* bit 2:0	    :ADCCHS, Select ADC converter channel input					 */
/*				=000: ADC Channel 0 (PA0)									 */
/*				=001: ADC Channel 1 (PA1)									 */	
/*				=010: ADC Channel 2 (PA2)									 */
/*				=011: ADC Channel 3 (PA3)									 */	
/*				=100: ADC Channel 4 (PA4)								     */
/*				=101: ADC Channel 5 (PA5)									 */	
/*				=110: ADC Channel 6 (PA6)									 */
/*				=111: ADC Channel 7 (PA7)									 */
/* bit 5:3   	:Reserve													 */
/* bit 6   	    :ADCSTR, Manual Start ADC Conversion						 */		 
/* bit 7   	    :ADCRDY, ADC conversion ready								 */ 
/* bit 13: 8  	:Reserved												     */
/* bit 14   	:ADCIE, ADC interrupt enable								 */	
/* bit 15   	:ADCIF, ADC interrupt flag									 */			
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	ADCCHS		: 3;
		UInt16	Reserved1	: 3;
		UInt16	ADCSTR		: 1;
		UInt16	ADCRDY		: 1;
		UInt16	Reserved2	: 6;
		UInt16	ADCIE		: 1;
		UInt16	ADCIF		: 1;
	} B;	
} P_ADC_Ctrl_DEF;

/*****************************************************************************/
/* ADC Input Channels Select (P_ADC_Channel)								 */
/* bit 0   	:ADCCH0, ADC Input Channel0 Enable	  							 */												 
/* bit 1   	:ADCCH1, ADC Input Channel1 Enable								 */
/* bit 2   	:ADCCH2, ADC Input Channel2 Enable	  							 */												 
/* bit 3   	:ADCCH3, ADC Input Channel3 Enable								 */
/* bit 4   	:ADCCH4, ADC Input Channel4 Enable	  							 */												 
/* bit 5   	:ADCCH5, ADC Input Channel5 Enable								 */
/* bit 6   	:ADCCH6, ADC Input Channel6 Enable	  							 */												 
/* bit 7   	:ADCCH7, ADC Input Channel7 Enable								 */
/* bit 8:15   	:Reserve													 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	ADCCH0		: 1;
		UInt16	ADCCH1		: 1;
		UInt16	ADCCH2		: 1;
		UInt16	ADCCH3		: 1;
		UInt16	ADCCH4		: 1;
		UInt16	ADCCH5		: 1;
		UInt16	ADCCH6		: 1;
		UInt16	ADCCH7		: 1;							
		UInt16	reserved	: 8;
	} B;
} P_ADC_Channel_DEF;

/*****************************************************************************/
/* ADC Data Register (P_ADC_Data)											 */
/* bit 5 - 0  : reserved	  												 */						
/* bit 15 - 6 : ADCData, ADC conversion data								 */							
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	reserved	: 6;
		UInt16	ADCData		: 10;
	} B;
} P_ADC_Data_DEF;

/*****************************************************************************/
/*****************************************************************************/
/* H. Standard Peripheral Interface, SPI register							 */
/*****************************************************************************/
/*****************************************************************************/
/* SPI control register (P_SPI_Ctrl)										 */
/* bit 2:0	:SPIFS, Master mode clock frequency selection					 */
/* bit 3	:SPISMPS, SPI sample mode selection for master mode				 */
/* bit 4	:SPIPOL, SPI clock polarity. SPI clock polarity select			 */
/* bit 5	:SPIPHA, SPI clock phase										 */
/* bit 7:6	:Reserve													 	 */
/* bit 8	:SPIMS, SPI mode selection										 */
/* bit 10:9	:SPISPCLK, Sampling clock select bits							 */
/* bit 11	:SPIRST, Write 1 to reset										 */
/* bit 14:12:Reserve													 	 */
/* bit 15	:SPIE, SPI enable												 */	
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	SPIFS		: 3;
		UInt16	SPISMPS		: 1;
		UInt16	SPIPOL		: 1;	
		UInt16	SPIPHA		: 1;
		UInt16	Reserved1	: 2;
		UInt16	SPIMS		: 1;	
		UInt16	SPISPCLK	: 2;
		UInt16	SPIRST		: 1;				
		UInt16	Reserved2	: 3;
		UInt16	SPIE		: 1;
	} B;	
} P_SPI_Ctrl_DEF;

/*****************************************************************************/
/* SPI Tx status register (P_SPI_TxStatus)									 */
/* bit 12:0	:Reserve													 	 */
/* bit 13	:SPITXBF, SPI Transmission buffer full flag.					 */
/* bit 14	:SPITXIE, SPI Transmit interrupt enable							 */
/* bit 15	:SPITXIF, SPI Transmit interrupt flag							 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	Reserved	: 13;
		UInt16	SPITXBF		: 1;
		UInt16	SPITXIE		: 1;
		UInt16	SPITXIF		: 1;
	} B;	
} P_SPI_TxStatus_DEF;

/*****************************************************************************/
/* SPI Transmission Buffer (P_SPI_TxBuf)									 */
/* bit 7 - 0  : SPITXBUF,Write data sends to SDO pin						 */						
/* bit 15- 8	  : Reserve													 */							
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	SPITXBUF	: 8;
		UInt16	reserved	: 8;
	} B;
} P_SPI_TxBuf_DEF;




/*****************************************************************************/
/* SPI Rx status register (P_SPI_RxStatus)									 */
/* bit 9:0	:Reserve													 	 */
/* bit 10	:FERR, Buffer full and overwrite								 */
/* bit 13:11:Reserve													 	 */
/* bit 14	:SPIRXIE, SPI receive interrupt enable							 */
/* bit 15	:SPIRXIF, SPI receive interrupt flag 							 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	Reserved1	: 10;
		UInt16	FERR		: 1;
		UInt16	Reserved2	: 3;
		UInt16	SPIRXIE		: 1;
		UInt16	SPIRXIF		: 1;		
	} B;
} P_SPI_RxStatus_DEF;

/*****************************************************************************/
/* SPI Receive Buffer (P_SPI_RxBuf)											 */
/* bit 7 - 0  : SPIRXBUF,Read data from SDI pin								 */						
/* bit 15- 8	  : Reserve													 */							
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	SPIRXBUF	: 8;
		UInt16	reserved	: 8;
	} B;
} P_SPI_RxBuf_DEF;

/*****************************************************************************/
/* Reset status register (P_Reset_Status)									 */
/* bit 0	  : EXTRF, External reset pin reset flag						 */
/* bit 1	  : PORF, Power-on reset flag									 */
/* bit 2	  : WDRF,  Watchdog reset flag									 */
/* bit 3	  : LVRF, Low voltage reset flag								 */
/* bit 4	  : reserved													 */
/* bit 5	  : IARF, Illegal address reset flag					         */
/* bit 6	  : IIRF, Illegal instruction reset flag				         */
/* bit 7 - 8  : reserved											         */
/* bit 9 - 15 : FCHK, Flag clear check bits pattern							 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	EXTRF		: 1;
		UInt16	PORF		: 1;
		UInt16	WDRF		: 1;
		UInt16	LVRF		: 1;
		UInt16	reserved1	: 1;
		UInt16	IARF		: 1;
		UInt16	IIRF		: 1;
		UInt16	reserved2	: 2;	
		UInt16	FCHK		: 7;	
	} B;
} P_Reset_Status_DEF;

/*****************************************************************************/
/* System Clock control register (P_Clk_Ctrl)								 */
/* bit 13 - 0 : reserved											         */
/* bit 14	  : OSCIE, Oscillator fail interrupt enable bit			         */
/* bit 15	  : OSCSF, Oscillator status flag						         */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	reserved	: 14;	
		UInt16	OSCIE		: 1;	
		UInt16	OSCSF		: 1;
	} B;
} P_Clk_Ctrl_DEF;

/*****************************************************************************/
/* System Option Register (P_System_Option)									 */
/* bit 0	  : CLK Source, Clock Source Selection							 */
/* bit 1	  : WDG, enable watchdog function								 */
/* bit 2	  : LVR, enable low voltage reset function						 */
/* bit 3	  : LVD, enable low voltage detection function					 */
/* bit 4	  : Security, security selection bit 							 */
/* bit 5 - 15 : Verification Pattern, Writer will write 010 1010 1010(0x2AA) */
/*				to this area	 											 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	CLK				: 1;
		UInt16	WDG				: 1;
		UInt16	LVR				: 1;
		UInt16	LVD				: 1;
		UInt16	Security		: 1;
		UInt16	Verification	: 11;	
	} B;
} P_System_Option_DEF;

/*****************************************************************************/
/* WatchDog Ctrl Register (P_WatchDog_Ctrl)									 */
/* bit 0 - 2  : WDPS,  Watchdog Timer Time-out Selections					 */
/* bit 3 - 7  : WDCHK, Watchdog control register check bits					 */
/* bit 8 - 13 : reserved													 */
/* bit 14	  : WDRS, Watchdog reset select bit								 */
/* bit 15	  : WDEN, Watchdog timer enable bit								 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	WDPS			: 3;
		UInt16	WDCHK			: 5;
		UInt16	reserved		: 6;
		UInt16	WDRS			: 1;
		UInt16	WDEN			: 1;
	} B;
} P_WatchDog_Ctrl_DEF;

/*****************************************************************************/
/* The watchdog clearance port (P_WatchDog_Clr)								 */
/* bit 0 - 15  : WDTCLR,  Write 0xA005 to clear watchdog timer				 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	WDTCLR			: 16;
	} B;
} P_WatchDog_Clr_DEF;

/*****************************************************************************/
/* Wake-up Control Register (P_Wakeup_Ctrl)									 */
/* bit 0 - 3  : Reserve														 */
/* bit 4  	  : CMTWE,  Compare match timer wake-up enable bit				 */
/* bit 5      : PDC0WE, PDC channel 0 wake-up enable bit					 */
/* bit 6      : PDC1WE, PDC channel 1 wake-up enable bit					 */
/* bit 7      : TPM2WE, TPM channel 2 wake-up enable bit					 */
/* bit 8 - 10 : reserved													 */
/* bit 11	  : EXT0WE, External interrupt 0 wake-up enable bit				 */
/* bit 12	  : EXT1WE, External interrupt 1 wake-up enable bit				 */
/* bit 13	  : SPIWE, SPI wake-up enable bit    							 */
/* bit 14	  : UARTWE, UART wake-up enable bit								 */
/* bit 15	  : KEYWE, Key-change wake-up enable bit						 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	Reserve1		: 4;
		UInt16	CMTWE			: 1;		
		UInt16	PDC0WE			: 1;
		UInt16	PDC1WE			: 1;
		UInt16	TPM2WE			: 1;	
		UInt16	reserved2		: 3;
		UInt16	EXT0WE			: 1;
		UInt16	EXT1WE			: 1;
		UInt16	SPIWE			: 1;
		UInt16	UARTWE			: 1;		
		UInt16	KEYWE			: 1;	
	} B;
} P_Wakeup_Ctrl_DEF;

/*****************************************************************************/
/* UART Data Register (P_UART_Data)											 */
/* bit 0 - 7  : UARTDATA,  UART Data Read/Write Register					 */
/* bit 8	  : FE, Frame Error (Ready-only)								 */
/* bit 9	  : PE, Parity Error (Ready-only)								 */
/* bit 10	  : reserved								 					 */
/* bit 11	  : OE, Overrun Error (Ready-only)								 */
/* bit 12 - 15: reserved													 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	UARTDATA	: 8;
		UInt16	FE			: 1;
		UInt16	PE			: 1;
		UInt16	reserved1	: 1;
		UInt16	OE			: 1;
		UInt16	reserved2	: 4;
	} B;
} P_UART_Data_DEF;

/*****************************************************************************/
/* UART Reception Error Flag Register (P_UART_RXStatus)						 */
/* bit 0	  : FE, Frame Error.											 */
/* bit 1	  : PE, Parity Error.											 */
/* bit 2	  : BE, Break Error.											 */
/* bit 3	  : OE, Overrun Error.											 */
/* bit 4 - 15 : reserved													 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	FE			: 1;
		UInt16	PE			: 1;
		UInt16	reserve1	: 1;
		UInt16	OE			: 1;
		UInt16	reserved2	: 12;
	} B;
} P_UART_RXStatus_DEF;

/*****************************************************************************/
/* UART Control Register (P_UART_Ctrl)										 */
/* bit 0	  : reserved												 	 */
/* bit 1	  : PEN, Parity Enable											 */
/* bit 2	  : PSEL, Parity Selection										 */
/* bit 3	  : SBSEL, Stop Bit Size Selection								 */
/* bit 4 - 8  : reserved								 					 */
/* bit 9	  : RXCHSEL,Reception data channel selection					 */
/*					0: UART reception from RXD2							 	 */
/*					1: UART reception from RXD2								 */
/* bit 10	  : TXCHSEL,  Transmission data channel selection				 */
/*					0: UART transmission to TXD2							 */
/*					1. UART transmission to TXD1                             */						 
/* bit 11	  : Reset, Software reset										 */
/* bit 12	  : TXEN, txd pin enable									 	 */
/* bit 13	  : RXEN, rxd pin enable			 							 */
/* bit 14	  : TXIE , Transmit Interrupt Enable							 */
/* bit 15	  : RXIE , Receive Interrupt Enable								 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	reserved1	: 1;
		UInt16	PEN			: 1;
		UInt16	PSEL		: 1;
		UInt16	SBSEL		: 1;
		UInt16	reserved2	: 5;
		UInt16	RXCHSEL		: 1;
		UInt16	TXCHSEL		: 1;
		UInt16	Reset		: 1;
		UInt16	TXEN		: 1;
		UInt16	RXEN		: 1;
		UInt16	TXIE		: 1;
		UInt16	RXIE		: 1;
	} B;
} P_UART_Ctrl_DEF;

/*****************************************************************************/
/* UART Baud Rate Setup Register (P_UART_BaudRate)							 */
/* bit 0 - 15  : UARTBUD, UART Baud Rate Divisor							 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	UARTBUD			: 16;
	} B;
} P_UART_BaudRate_DEF;

/*****************************************************************************/
/* UART Status Register (P_UART_Status)										 */
/* bit 0 - 2   : reserved													 */
/* bit 3	   : BY, BUSY flag												 */
/* bit 4 - 5   : reserved													 */
/* bit 6	   : RXFF, Receive FIFO Full Flag								 */
/* bit 7 - 13  : reserved													 */
/* bit 14	   : TXIF, Transmit Interrupt Flag								 */
/* bit 15	   : RXIF, Receive Interrupt Flag								 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	reserved1	: 3;
		UInt16	BY			: 1;
		UInt16	reserved2	: 2;
		UInt16	RXBF		: 1;
		UInt16	reserved3	: 7;
		UInt16	TXIF		: 1;
		UInt16	RXIF		: 1;
	} B;
} P_UART_Status_DEF;

/*****************************************************************************/
/* Interrupt status Register (P_INT_Status)									 */
/* bit 0	   : FTIF, Fault protection interrupt status flag				 */
/* bit 1 	   : OSCSF, Oscillator status flag								 */
/* bit 2 	   : OLIF, Overload interrupt status flag		 		 		 */
/* bit 3   	   : reserved													 */
/* bit 4	   : CMTIF, Compare match timer interrupt status flag			 */
/* bit 5	   : PDC0IF, Timer/PWM module channel 0 interrupt status flag	 */
/* bit 6	   : PDC1IF, Timer/PWM module channel 1 interrupt status flag	 */
/* bit 7	   : TPM2IF, Timer/PWM module channel 2 interrupt status flag	 */
/* bit 8	   : MCP3IF, Timer/PWM module channel 3 interrupt status flag	 */
/* bit 9	   : MCP4IF, Timer/PWM module channel 4 interrupt status flag	 */
/* bit 10	   : ADCIF, A/D converter interrupt status flag					 */
/* bit 11	   : EXT0IF, External interrupt 0 status flag					 */
/* bit 12	   : EXT1IF, External interrupt 1 status flag					 */
/* bit 13	   : SPIIF, SPI interrupt status flag							 */
/* bit 14	   : UARTIF, UART interrupt status flag							 */
/* bit 15	   : KEYIF, Key-change interrupt status flag					 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	FTIF			: 1;
		UInt16	OSCSF			: 1;
		UInt16	OLIF			: 1;			
		UInt16	reserved		: 1;
		UInt16	CMTIF			: 1;
		UInt16	PDC0IF			: 1;
		UInt16	PDC1IF			: 1;
		UInt16	TPM2IF			: 1;
		UInt16	MCP3IF			: 1;
		UInt16	MCP4IF			: 1;
		UInt16	ADCIF			: 1;
		UInt16	EXT0IF			: 1;
		UInt16	EXT1IF			: 1;
		UInt16	SPIIF			: 1;
		UInt16	UARTIF			: 1;
		UInt16	KEYIF			: 1;			
	} B;
} P_INT_Status_DEF;

/*****************************************************************************/
/* IRQ and FIQ selection Register (P_INT_Priority)							 */
/* bit 0	   : FTIP, Fault protection interrupt priority select bit		 */
/* bit 1 	   : OSCIP, Oscillator fail interrupt priority select bit		 */
/* bit 2 	   : OLIP, Overload interrupt priority select bit		 		 */
/* bit 3   	   : reserved													 */
/* bit 4	   : CMTIP, CMT interrupt priority select bit					 */
/* bit 5	   : PDC0IP, PDC ch. 0 interrupt priority select bit			 */
/* bit 6	   : PDC1IP, PDC ch. 1 interrupt priority select bit			 */
/* bit 7	   : TPM2IP, TPM ch. 2 interrupt priority select bit			 */
/* bit 8	   : MCP3IP, MCP ch. 3 interrupt priority select bit			 */
/* bit 9	   : MCP4IP, MCP ch. 4 interrupt priority select bit			 */
/* bit 10	   : ADCIP, ADC interrupt priority select bit					 */
/* bit 11	   : EXTIP, External interrupt priority select bit			 	 */
/* bit 12	   : reserved													 */
/* bit 13	   : SPIIP, SPI interrupt priority select bit					 */
/* bit 14	   : UARTIP, UART interrupt priority select bit					 */
/* bit 15	   : KEYIP, Key-change interrupt priority select bit			 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	FTIP			: 1;
		UInt16	OSCIP			: 1;
		UInt16	OLIP			: 1;	
		UInt16	reserved1		: 1;
		UInt16	CMTIP			: 1;
		UInt16	PDC0IP			: 1;
		UInt16	PDC1IP			: 1;
		UInt16	TPM2IP			: 1;
		UInt16	MCP3IP			: 1;
		UInt16	MCP4IP			: 1;
		UInt16	ADCIP			: 1;
		UInt16	EXTIP			: 1;
		UInt16	reserved2		: 1;
		UInt16	SPIIP			: 1;
		UInt16	UARTIP			: 1;
		UInt16	KEYIP			: 1;			
	} B;
} P_INT_Priority_DEF;

/*****************************************************************************/
/* Miscellaneous Interrupt control register (P_MisINT_Ctrl)					 */
/* bit 0 - 10  : reserved													 */
/* bit 11	   : EXT0IE, External interrupt 0 enable bit					 */
/* bit 12	   : EXT1IE, External interrupt 1 enable bit					 */
/* bit 13	   : EXT0MS, External interrupt 0 trigger mode selection		 */
/* bit 14	   : EXT1MS, External interrupt 1 trigger mode selection		 */
/* bit 15	   : KEYIE, Key-change interrupt enable bit						 */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	reserved1		: 11;
		UInt16	EXT0IE			: 1;
		UInt16	EXT1IE			: 1;
		UInt16	EXT0MS			: 1;
		UInt16	EXT1MS			: 1;
		UInt16	KEYIE			: 1;			
	} B;
} P_MisINT_Ctrl_DEF;

/*****************************************************************************/
/* Embedded flash access control (P_Flash_RW)					 			 */
/* bit 0 	:	BK0WENB													     */
/* bit 1 	:	BK1WENB														 */		
/* bit 2 	:	BK2WENB														 */
/* bit 3 	:	BK3WENB														 */
/* bit 4 	:	BK4WENB														 */	
/* bit 5 	:	BK5WENB														 */
/* bit 6 	:	BK6WENB														 */	
/* bit 7 	:	BK7WENB														 */
/* bit 8 	:	BK8WENB														 */
/* bit 9 	:	BK9WENB														 */
/* bit 10 	:	BK10WENB													 */
/* bit 11 	:	BK11WENB													 */		
/* bit 12 	:	BK12WENB					 								 */
/* bit 13 	:	BK13WENB													 */
/* bit 14 	:	BK14WENB													 */
/* bit 15 	:	Reserve														 */	
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	BK0WENB			: 1;
		UInt16	BK1WENB			: 1;
		UInt16	BK2WENB			: 1;
		UInt16	BK3WENB			: 1;
		UInt16	BK4WENB			: 1;
		UInt16	BK5WENB			: 1;
		UInt16	BK6WENB			: 1;
		UInt16	BK7WENB			: 1;
		UInt16	BK8WENB			: 1;
		UInt16	BK9WENB			: 1;
		UInt16	BK10WENB		: 1;
		UInt16	BK11WENB		: 1;
		UInt16	BK12WENB		: 1;
		UInt16	BK13WENB		: 1;
		UInt16	BK14WENB		: 1;
		UInt16	BK15WENB		: 1;
			
	} B;
} P_Flash_RW_DEF;


/*****************************************************************************/
/* Flash control register 	(P_Flash_Cmd)					 			     */
/*****************************************************************************/
typedef union 
{
	UInt16	W;
	struct
	{
		UInt16	Reserve			: 16;
	} B;
} P_Flash_Cmd_DEF;

/*****************************************************************************/
/*****************************************************************************/
/* H. Compare Match Timer Register											 */				
/*****************************************************************************/
/*****************************************************************************/
/* Compare Match Timer Start Register (P_CMT_Start)							 */
/* bit 0		: ST0, compare match timer 0 counter start					 */
/* bit 1		: ST1, compare match timer 1 counter start					 */
/* bit 14 - 2   : reserved													 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	ST0				: 1;
		UInt16	ST1				: 1;
		UInt16	Rerserved		: 14;
	} B;
} P_CMT_Start_DEF;

/*****************************************************************************/
/* Comapre Match Timer Control/Status Register (P_CMT_Ctrl)					 */
/* bit 15		: CM1IF, CMT1 compare match flag 1							 */
/* bit 14		: CM1IE, CMT1 compare match interrupt enable				 */
/* bit 13 - 11  : reserved													 */
/* bit 10 - 8	: CKB, CMT1 clock select bits								 */
/*				= 000, Fck / 1												 */
/*				= 001, Fck / 2												 */
/*				= 010, Fck / 4												 */
/*				= 011, Fck / 8												 */
/*				= 100, Fck / 16												 */
/*				= 101, Fck / 64												 */
/*				= 110, Fck / 256											 */
/*				= 111, Fck / 1024											 */
/* bit 7		: CM0IF, CMT0 compare match flag 0							 */
/* bit 6		: CM0IE, CMT0 compare match interrupt enable				 */
/* bit 5 - 3    : reserved													 */
/* bit 2 - 0	: CKA, CMT0 clock select bits								 */
/*				= 000, Fck / 1												 */
/*				= 001, Fck / 2												 */
/*				= 010, Fck / 4												 */
/*				= 011, Fck / 8												 */
/*				= 100, Fck / 16												 */
/*				= 101, Fck / 64												 */
/*				= 110, Fck / 256											 */
/*				= 111, Fck / 1024											 */
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	CKA			: 3;
		UInt16	Reserved1	: 3;
		UInt16	CM0IE		: 1;
		UInt16	CM0IF		: 1;
		UInt16	CKB			: 3;
		UInt16	Reserved2	: 3;
		UInt16	CM1IE		: 1;
		UInt16	CM1IF		: 1;
	} B;
} P_CMT_Ctrl_DEF;

/*****************************************************************************/
/*****************************************************************************/
/* I. Time Base Register													 */				
/*****************************************************************************/
/*****************************************************************************/
/* Buzzer Output Control Register (P_BZO_Ctrl)								 */
/* bit 15		: BZOEN, buzzer output enable select bit					 */
/* bit 14 - 2   : reserved													 */
/* bit 1 - 0    : BZOCK, buzzer output frequency select bits				 */
/*				= 00, Fck / 16384											 */	 	
/*				= 01, Fck / 8192											 */	 	
/*				= 10, Fck / 4096											 */	 	
/*				= 11, Fck / 2084											 */	 	
/*****************************************************************************/
typedef union
{
	UInt16	W;
	struct
	{
		UInt16	BZOCK		: 2;
		UInt16	Reserved	: 13;
		UInt16	BZOEN		: 1;
	} B;
} P_BZO_Ctrl_DEF;


/*****************************************************************************/
/* SPMC75 family register structure macro definition                		 */
/*****************************************************************************/
#ifndef SPMC75_REG_DEBUG
//
/* A. CPU control register */
#define P_System_Option			((volatile P_System_Option_DEF *)(P_System_Option_ADDR))
#define P_Wait_Enter			((volatile P_Wait_Enter_DEF *)(P_Wait_Enter_ADDR))
#define P_Stdby_Enter			((volatile P_Stdby_Enter_DEF *)(P_Stdby_Enter_ADDR))
#define P_Reset_Status			((volatile P_Reset_Status_DEF *)(P_Reset_Status_ADDR))
#define P_Clk_Ctrl				((volatile P_Clk_Ctrl_DEF *)(P_Clk_Ctrl_ADDR))
#define P_WatchDog_Ctrl			((volatile P_WatchDog_Ctrl_DEF *)(P_WatchDog_Ctrl_ADDR))
#define P_WatchDog_Clr			((volatile P_WatchDog_Clr_DEF *)(P_WatchDog_Clr_ADDR))
#define P_Wakeup_Ctrl			((volatile P_Wakeup_Ctrl_DEF *)(P_Wakeup_Ctrl_ADDR))
#define P_INT_Status			((volatile P_INT_Status_DEF *)(P_INT_Status_ADDR))
#define P_INT_Priority			((volatile P_INT_Priority_DEF *)(P_INT_Priority_ADDR))
#define P_MisINT_Ctrl			((volatile P_MisINT_Ctrl_DEF *)(P_MisINT_Ctrl_ADDR))

/* B. I/O Ports */
/* B1. PortA register*/
#define P_IOA_Data				((volatile GEN_REG_DEF *)(P_IOA_Data_ADDR))
#define P_IOA_Buffer			((volatile GEN_REG_DEF *)(P_IOA_Buffer_ADDR))
#define P_IOA_Dir				((volatile GEN_REG_DEF *)(P_IOA_Dir_ADDR))
#define P_IOA_Attrib			((volatile GEN_REG_DEF *)(P_IOA_Attrib_ADDR))
#define P_IOA_Latch				((volatile GEN_REG_DEF *)(P_IOA_Latch_ADDR))
#define P_IOA_SPE				((volatile P_IOA_SPE_DEF *)(P_IOA_SPE_ADDR))
#define P_IOA_KCER				((volatile P_IOA_KCER_DEF *)(P_IOA_KCER_ADDR))

/* B2. PortB register*/
#define P_IOB_Data				((volatile GEN_REG_DEF *)(P_IOB_Data_ADDR))
#define P_IOB_Buffer			((volatile GEN_REG_DEF *)(P_IOB_Buffer_ADDR))
#define P_IOB_Dir				((volatile GEN_REG_DEF *)(P_IOB_Dir_ADDR))
#define P_IOB_Attrib			((volatile GEN_REG_DEF *)(P_IOB_Attrib_ADDR))
#define P_IOB_SPE				((volatile P_IOB_SPE_DEF *)(P_IOB_SPE_ADDR))

/* B3. PortC register*/
#define P_IOC_Data				((volatile GEN_REG_DEF *)(P_IOC_Data_ADDR))
#define P_IOC_Buffer			((volatile GEN_REG_DEF *)(P_IOC_Buffer_ADDR))
#define P_IOC_Dir				((volatile GEN_REG_DEF *)(P_IOC_Dir_ADDR))
#define P_IOC_Attrib			((volatile GEN_REG_DEF *)(P_IOC_Attrib_ADDR))
#define P_IOC_SPE				((volatile P_IOC_SPE_DEF *)(P_IOC_SPE_ADDR))

/* B4. PortD register*/
#define P_IOD_Data				((volatile GEN_REG_DEF *)(P_IOD_Data_ADDR))
#define P_IOD_Buffer			((volatile GEN_REG_DEF *)(P_IOD_Buffer_ADDR))
#define P_IOD_Dir				((volatile GEN_REG_DEF *)(P_IOD_Dir_ADDR))
#define P_IOD_Attrib			((volatile GEN_REG_DEF *)(P_IOD_Attrib_ADDR))

/* C. Temer  */
/* C1. Timer0 register */
#define P_TMR0_Ctrl				((volatile P_TMR0_Ctrl_DEF *)(P_TMR0_Ctrl_ADDR))
#define	P_TMR0_TCNT				((volatile GEN_REG_DEF *)(P_TMR0_TCNT_ADDR))
#define	P_TMR0_TGRA				((volatile GEN_REG_DEF *)(P_TMR0_TGRA_ADDR))
#define	P_TMR0_TGRB				((volatile GEN_REG_DEF *)(P_TMR0_TGRB_ADDR))
#define	P_TMR0_TGRC				((volatile GEN_REG_DEF *)(P_TMR0_TGRC_ADDR))
#define P_TMR0_TPR				((volatile GEN_REG_DEF *)(P_TMR0_TPR_ADDR))
#define P_TMR0_TBRA				((volatile GEN_REG_DEF *)(P_TMR0_TBRA_ADDR))
#define P_TMR0_TBRB				((volatile GEN_REG_DEF *)(P_TMR0_TBRB_ADDR))
#define P_TMR0_TBRC				((volatile GEN_REG_DEF *)(P_TMR0_TBRC_ADDR))
#define P_TMR0_IOCtrl			((volatile P_TMR0_IOCtrl_DEF *)(P_TMR0_IOCtrl_ADDR))
#define P_TMR0_INT				((volatile P_TMR0_INT_DEF *)(P_TMR0_INT_ADDR))
#define P_TMR0_Status			((volatile P_TMR0_Status_DEF *)(P_TMR0_Status_ADDR))

/* C2. Timer1 register */
#define P_TMR1_Ctrl				((volatile P_TMR1_Ctrl_DEF *)(P_TMR1_Ctrl_ADDR))
#define	P_TMR1_TCNT				((volatile GEN_REG_DEF *)(P_TMR1_TCNT_ADDR))
#define	P_TMR1_TGRA				((volatile GEN_REG_DEF *)(P_TMR1_TGRA_ADDR))
#define	P_TMR1_TGRB				((volatile GEN_REG_DEF *)(P_TMR1_TGRB_ADDR))
#define	P_TMR1_TGRC				((volatile GEN_REG_DEF *)(P_TMR1_TGRC_ADDR))
#define P_TMR1_TPR				((volatile GEN_REG_DEF *)(P_TMR1_TPR_ADDR))
#define P_TMR1_TBRA				((volatile GEN_REG_DEF *)(P_TMR1_TBRA_ADDR))
#define P_TMR1_TBRB				((volatile GEN_REG_DEF *)(P_TMR1_TBRB_ADDR))
#define P_TMR1_TBRC				((volatile GEN_REG_DEF *)(P_TMR1_TBRC_ADDR))
#define P_TMR1_IOCtrl			((volatile P_TMR1_IOCtrl_DEF *)(P_TMR1_IOCtrl_ADDR))
#define P_TMR1_INT				((volatile P_TMR1_INT_DEF *)(P_TMR1_INT_ADDR))
#define P_TMR1_Status			((volatile P_TMR1_Status_DEF *)(P_TMR1_Status_ADDR))

/* C3. Timer2 register */
#define P_TMR2_Ctrl				((volatile P_TMR2_Ctrl_DEF *)(P_TMR2_Ctrl_ADDR))
#define	P_TMR2_TCNT				((volatile GEN_REG_DEF *)(P_TMR2_TCNT_ADDR))
#define	P_TMR2_TGRA				((volatile GEN_REG_DEF *)(P_TMR2_TGRA_ADDR))
#define	P_TMR2_TGRB				((volatile GEN_REG_DEF *)(P_TMR2_TGRB_ADDR))
#define P_TMR2_TPR				((volatile GEN_REG_DEF *)(P_TMR2_TPR_ADDR))
#define P_TMR2_TBRA				((volatile GEN_REG_DEF *)(P_TMR2_TBRA_ADDR))
#define P_TMR2_TBRB				((volatile GEN_REG_DEF *)(P_TMR2_TBRB_ADDR))
#define P_TMR2_IOCtrl			((volatile P_TMR2_IOCtrl_DEF *)(P_TMR2_IOCtrl_ADDR))
#define P_TMR2_INT				((volatile P_TMR2_INT_DEF *)(P_TMR2_INT_ADDR))
#define P_TMR2_Status			((volatile P_TMR2_Status_DEF *)(P_TMR2_Status_ADDR))

/* C4. Timer3 register */
#define P_TMR3_Ctrl				((volatile P_TMR3_Ctrl_DEF *)(P_TMR3_Ctrl_ADDR))
#define P_TMR3_TCNT				((volatile GEN_REG_DEF *)(P_TMR3_TCNT_ADDR))
#define P_TMR3_TGRA				((volatile GEN_REG_DEF *)(P_TMR3_TGRA_ADDR))
#define P_TMR3_TGRB				((volatile GEN_REG_DEF *)(P_TMR3_TGRB_ADDR))
#define P_TMR3_TGRC				((volatile GEN_REG_DEF *)(P_TMR3_TGRC_ADDR))
#define P_TMR3_TGRD				((volatile GEN_REG_DEF *)(P_TMR3_TGRD_ADDR))
#define P_TMR3_TPR				((volatile GEN_REG_DEF *)(P_TMR3_TPR_ADDR))
#define P_TMR3_TBRA				((volatile GEN_REG_DEF *)(P_TMR3_TBRA_ADDR))
#define P_TMR3_TBRB				((volatile GEN_REG_DEF *)(P_TMR3_TBRB_ADDR))
#define P_TMR3_TBRC				((volatile GEN_REG_DEF *)(P_TMR3_TBRC_ADDR))

#define P_TMR3_IOCtrl			((volatile P_TMR3_IOCtrl_DEF *)(P_TMR3_IOCtrl_ADDR))
#define P_TMR3_INT				((volatile P_TMR3_INT_DEF *)(P_TMR3_INT_ADDR))
#define P_TMR3_Status			((volatile P_TMR3_Status_DEF *)(P_TMR3_Status_ADDR))
#define P_TMR3_OutputCtrl		((volatile P_TMR3_OutputCtrl_DEF *)(P_TMR3_OutputCtrl_ADDR))
#define P_TMR3_DeadTime			((volatile P_TMR3_DeadTime_DEF *)(P_TMR3_DeadTime_ADDR))
#define P_Fault1_Ctrl			((volatile P_Fault1_Ctrl_DEF *)(P_Fault1_Ctrl_ADDR))
#define P_OL1_Ctrl				((volatile P_OL1_Ctrl_DEF *)(P_OL1_Ctrl_ADDR))

/* C5. Timer4 register */
#define P_TMR4_Ctrl				((volatile P_TMR4_Ctrl_DEF *)(P_TMR4_Ctrl_ADDR))
#define P_TMR4_TCNT				((volatile GEN_REG_DEF *)(P_TMR4_TCNT_ADDR))
#define P_TMR4_TGRA				((volatile GEN_REG_DEF *)(P_TMR4_TGRA_ADDR))
#define P_TMR4_TGRB				((volatile GEN_REG_DEF *)(P_TMR4_TGRB_ADDR))
#define P_TMR4_TGRC				((volatile GEN_REG_DEF *)(P_TMR4_TGRC_ADDR))
#define P_TMR4_TGRD				((volatile GEN_REG_DEF *)(P_TMR4_TGRD_ADDR))
#define P_TMR4_TPR				((volatile GEN_REG_DEF *)(P_TMR4_TPR_ADDR))
#define P_TMR4_TBRA				((volatile GEN_REG_DEF *)(P_TMR4_TBRA_ADDR))
#define P_TMR4_TBRB				((volatile GEN_REG_DEF *)(P_TMR4_TBRB_ADDR))
#define P_TMR4_TBRC				((volatile GEN_REG_DEF *)(P_TMR4_TBRC_ADDR))

#define P_TMR4_IOCtrl			((volatile P_TMR4_IOCtrl_DEF *)(P_TMR4_IOCtrl_ADDR))
#define P_TMR4_INT				((volatile P_TMR4_INT_DEF *)(P_TMR4_INT_ADDR))
#define P_TMR4_Status			((volatile P_TMR4_Status_DEF *)(P_TMR4_Status_ADDR))
#define P_TMR4_OutputCtrl		((volatile P_TMR4_OutputCtrl_DEF *)(P_TMR4_OutputCtrl_ADDR))
#define P_TMR4_DeadTime			((volatile P_TMR4_DeadTime_DEF *)(P_TMR4_DeadTime_ADDR))
#define P_Fault2_Ctrl			((volatile P_Fault2_Ctrl_DEF *)(P_Fault2_Ctrl_ADDR))
#define P_OL2_Ctrl				((volatile P_OL2_Ctrl_DEF *)(P_OL2_Ctrl_ADDR))

/* C6. Timer register */
#define P_TMR_LDOK				((volatile P_TMR_LDOK_DEF *)(P_TMR_LDOK_ADDR))

#define P_TMR_Start				((volatile P_TMR_Start_DEF *)(P_TMR_Start_ADDR))
#define P_TMR_Output			((volatile P_TMR_Output_DEF *)(P_TMR_Output_ADDR))
#define P_TPWM_Write			((volatile P_TPWM_Write_DEF *)(P_TPWM_Write_ADDR))

#define P_POS0_DectCtrl			((volatile P_POS0_DectCtrl_DEF *)(P_POS0_DectCtrl_ADDR))
#define P_POS1_DectCtrl			((volatile P_POS1_DectCtrl_DEF *)(P_POS1_DectCtrl_ADDR))

#define P_POS0_DectData			((volatile P_POS0_DectData_DEF *)(P_POS0_DectData_ADDR))
#define P_POS1_DectData			((volatile P_POS1_DectData_DEF *)(P_POS1_DectData_ADDR))

#define P_Fault1_Release		((volatile P_Fault1_Release_DEF *)(P_Fault1_Release_ADDR))
#define P_Fault2_Release		((volatile P_Fault2_Release_DEF *)(P_Fault2_Release_ADDR))

/* D. ADC register */
#define P_ADC_Setup				((volatile P_ADC_Setup_DEF *)(P_ADC_Setup_ADDR))
#define P_ADC_Ctrl				((volatile P_ADC_Ctrl_DEF *)(P_ADC_Ctrl_ADDR))
#define P_ADC_Data				((volatile P_ADC_Data_DEF *)(P_ADC_Data_ADDR))
#define P_ADC_Channel			((volatile P_ADC_Channel_DEF *)(P_ADC_Channel_ADDR))

/* E. SPI register */
#define P_SPI_Ctrl				((volatile P_SPI_Ctrl_DEF *)(P_SPI_Ctrl_ADDR))
#define P_SPI_TxStatus			((volatile P_SPI_TxStatus_DEF *)(P_SPI_TxStatus_ADDR))
#define P_SPI_TxBuf				((volatile P_SPI_TxBuf_DEF *)(P_SPI_TxBuf_ADDR))
#define P_SPI_RxStatus			((volatile P_SPI_RxStatus_DEF *)(P_SPI_RxStatus_ADDR))
#define P_SPI_RxBuf				((volatile P_SPI_RxBuf_DEF *)(P_SPI_RxBuf_ADDR))

/* F. Flash organization and control register */
#define P_Flash_RW				((volatile P_Flash_RW_DEF *)(P_Flash_RW_ADDR))
#define P_Flash_Cmd				((volatile P_Flash_Cmd_DEF *)(P_Flash_Cmd_ADDR))

/* G. UART control register */
#define P_UART_Data				((volatile P_UART_Data_DEF *)(P_UART_Data_ADDR))
#define P_UART_RXStatus			((volatile P_UART_RXStatus_DEF *)(P_UART_RXStatus_ADDR))
#define P_UART_Ctrl				((volatile P_UART_Ctrl_DEF *)(P_UART_Ctrl_ADDR))
#define P_UART_BaudRate			((volatile P_UART_BaudRate_DEF *)(P_UART_BaudRate_ADDR))
#define P_UART_Status			((volatile P_UART_Status_DEF *)(P_UART_Status_ADDR))

/* H. Compare Match Timer register */
#define P_CMT_Start				((volatile P_CMT_Start_DEF *)(P_CMT_Start_ADDR))
#define P_CMT_Ctrl				((volatile P_CMT_Ctrl_DEF *)(P_CMT_Ctrl_ADDR))
#define P_CMT0_TCNT				((volatile GEN_REG_DEF *)(P_CMT0_TCNT_ADDR))
#define P_CMT1_TCNT				((volatile GEN_REG_DEF *)(P_CMT1_TCNT_ADDR))
#define P_CMT0_TPR				((volatile GEN_REG_DEF *)(P_CMT0_TPR_ADDR))
#define P_CMT1_TPR				((volatile GEN_REG_DEF *)(P_CMT1_TPR_ADDR))

/* I. Time Base register */
#define P_TMB_Reset				((volatile GEN_REG_DEF *)(P_TMB_Reset_ADDR))
#define P_BZO_Ctrl				((volatile P_BZO_Ctrl_DEF *)(P_BZO_Ctrl_ADDR))

//
#else
	/* A. CPU control register */
	extern P_System_Option_DEF		*P_System_Option;
	extern P_Wait_Enter_DEF			*P_Wait_Enter;	
	extern P_Stdby_Enter_DEF		*P_Stdby_Enter;
	extern P_Reset_Status_DEF		*P_Reset_Status;	
	extern P_Clk_Ctrl_DEF			*P_Clk_Ctrl;	
	extern P_WatchDog_Ctrl_DEF		*P_WatchDog_Ctrl; 
	extern P_WatchDog_Clr_DEF		*P_WatchDog_Clr;	
	extern P_Wakeup_Ctrl_DEF		*P_Wakeup_Ctrl;
	extern P_INT_Status_DEF			*P_INT_Status;
	extern P_INT_Priority_DEF		*P_INT_Priority;
	extern P_MisINT_Ctrl_DEF		*P_MisINT_Ctrl;

	/* B. I/O Ports */
	/* B1. PortA register*/
	extern GEN_REG_DEF				*P_IOA_Data;
	extern GEN_REG_DEF				*P_IOA_Buffer;
	extern GEN_REG_DEF				*P_IOA_Dir;
	extern GEN_REG_DEF				*P_IOA_Attrib;
	extern GEN_REG_DEF				*P_IOA_Latch;
	extern P_IOA_SPE_DEF			*P_IOA_SPE;
	extern P_IOA_KCER_DEF			*P_IOA_KCER;			
	
	/* B2. PortB register*/
	extern GEN_REG_DEF				*P_IOB_Data;
	extern GEN_REG_DEF				*P_IOB_Buffer;
	extern GEN_REG_DEF				*P_IOB_Dir;
	extern GEN_REG_DEF				*P_IOB_Attrib;
	extern P_IOB_SPE_DEF			*P_IOB_SPE;

	/* B3. PortC register*/
	extern GEN_REG_DEF				*P_IOC_Data;
	extern GEN_REG_DEF				*P_IOC_Buffer;
	extern GEN_REG_DEF				*P_IOC_Dir;
	extern GEN_REG_DEF				*P_IOC_Attrib;
	extern P_IOC_SPE_DEF			*P_IOC_SPE;

	/* B4. PortD register*/
	extern GEN_REG_DEF				*P_IOD_Data;
	extern GEN_REG_DEF				*P_IOD_Buffer;
	extern GEN_REG_DEF				*P_IOD_Dir;
	extern GEN_REG_DEF				*P_IOD_Attrib;

	/* C. Temer  */
	/* C1. Timer0 register */
	extern P_TMR0_Ctrl_DEF			*P_TMR0_Ctrl;
	extern GEN_REG_DEF				*P_TMR0_TCNT;
	extern GEN_REG_DEF				*P_TMR0_TGRA;
	extern GEN_REG_DEF				*P_TMR0_TGRB;
	extern GEN_REG_DEF				*P_TMR0_TGRC;
	extern GEN_REG_DEF				*P_TMR0_TPR;
	extern GEN_REG_DEF				*P_TMR0_TBRA;
	extern GEN_REG_DEF				*P_TMR0_TBRB;
	extern GEN_REG_DEF				*P_TMR0_TBRC;
	extern P_TMR0_IOCtrl_DEF		*P_TMR0_IOCtrl;
	extern P_TMR0_INT_DEF			*P_TMR0_INT;
	extern P_TMR0_Status_DEF		*P_TMR0_Status;				

	/* C2. Timer1 register */
	extern P_TMR1_Ctrl_DEF			*P_TMR1_Ctrl;
	extern GEN_REG_DEF				*P_TMR1_TCNT;
	extern GEN_REG_DEF				*P_TMR1_TGRA;
	extern GEN_REG_DEF				*P_TMR1_TGRB;
	extern GEN_REG_DEF				*P_TMR1_TGRC;
	extern GEN_REG_DEF				*P_TMR1_TPR;
	extern GEN_REG_DEF				*P_TMR1_TBRA;
	extern GEN_REG_DEF				*P_TMR1_TBRB;
	extern GEN_REG_DEF				*P_TMR1_TBRC;
	extern P_TMR1_IOCtrl_DEF		*P_TMR1_IOCtrl;
	extern P_TMR1_INT_DEF			*P_TMR1_INT;
	extern P_TMR1_Status_DEF		*P_TMR1_Status;				

	/* C3. Timer2 register */
	extern P_TMR2_Ctrl_DEF			*P_TMR2_Ctrl;
	extern GEN_REG_DEF				*P_TMR2_TCNT;
	extern GEN_REG_DEF				*P_TMR2_TGRA;
	extern GEN_REG_DEF				*P_TMR2_TGRB;
	extern GEN_REG_DEF				*P_TMR2_TPR;
	extern GEN_REG_DEF				*P_TMR2_TBRA;
	extern GEN_REG_DEF				*P_TMR2_TBRB;
	extern P_TMR2_IOCtrl_DEF		*P_TMR2_IOCtrl;
	extern P_TMR2_INT_DEF			*P_TMR2_INT;
	extern P_TMR2_Status_DEF		*P_TMR2_Status;				

	/* C4. Timer3 register */
	extern P_TMR3_Ctrl_DEF			*P_TMR3_Ctrl;
	extern GEN_REG_DEF				*P_TMR3_TCNT;
	extern GEN_REG_DEF				*P_TMR3_TGRA;
	extern GEN_REG_DEF				*P_TMR3_TGRB;
	extern GEN_REG_DEF				*P_TMR3_TGRC;
	extern GEN_REG_DEF				*P_TMR3_TGRD;
	extern GEN_REG_DEF				*P_TMR3_TPR;
	extern GEN_REG_DEF				*P_TMR3_TBRA;
	extern GEN_REG_DEF				*P_TMR3_TBRB;
	extern GEN_REG_DEF				*P_TMR3_TBRC;
	
	extern P_TMR3_IOCtrl_DEF		*P_TMR3_IOCtrl;
	extern P_TMR3_INT_DEF			*P_TMR3_INT;
	extern P_TMR3_Status_DEF		*P_TMR3_Status;				
	extern P_TMR3_OutputCtrl_DEF	*P_TMR3_OutputCtrl;
	extern P_TMR3_DeadTime_DEF		*P_TMR3_DeadTime;
	extern P_Fault1_Ctrl_DEF		*P_Fault1_Ctrl;	
	extern P_OL1_Ctrl_DEF			*P_OL1_Ctrl;

	/* C5. Timer4 register */
	extern P_TMR4_Ctrl_DEF			*P_TMR4_Ctrl;
	extern GEN_REG_DEF				*P_TMR4_TCNT;
	extern GEN_REG_DEF				*P_TMR4_TGRA;
	extern GEN_REG_DEF				*P_TMR4_TGRB;
	extern GEN_REG_DEF				*P_TMR4_TGRC;
	extern GEN_REG_DEF				*P_TMR4_TGRD;
	extern GEN_REG_DEF				*P_TMR4_TPR;
	extern GEN_REG_DEF				*P_TMR4_TBRA;
	extern GEN_REG_DEF				*P_TMR4_TBRB;
	extern GEN_REG_DEF				*P_TMR4_TBRC;
	
	extern P_TMR4_IOCtrl_DEF		*P_TMR4_IOCtrl;
	extern P_TMR4_INT_DEF			*P_TMR4_INT;
	extern P_TMR4_Status_DEF		*P_TMR4_Status;				
	extern P_TMR4_OutputCtrl_DEF	*P_TMR4_OutputCtrl;
	extern P_TMR4_DeadTime_DEF		*P_TMR4_DeadTime;
	extern P_Fault2_Ctrl_DEF		*P_Fault2_Ctrl;	
	extern P_OL2_Ctrl_DEF			*P_OL2_Ctrl;

	/* C6. Timer register */
	extern P_TMR_LDOK_DEF			*P_TMR_LDOK;	
	
	extern P_TMR_Start_DEF			*P_TMR_Start;
	extern P_TMR_Output_DEF			*P_TMR_Output;
	extern P_TPWM_Write_DEF			*P_TPWM_Write;
	
	extern P_POS0_DectCtrl_DEF		*P_POS0_DectCtrl;
	extern P_POS1_DectCtrl_DEF		*P_POS1_DectCtrl;

	extern P_POS0_DectData_DEF		*P_POS0_DectData;
	extern P_POS1_DectData_DEF		*P_POS1_DectData;
	
	extern P_Fault1_Release_DEF		*P_Fault1_Release;		
	extern P_Fault2_Release_DEF		*P_Fault2_Release;	
	
	/* D. ADC register */
	extern P_ADC_Setup_DEF 			*P_ADC_Setup;   
	extern P_ADC_Ctrl_DEF           *P_ADC_Ctrl;     
	extern P_ADC_Data_DEF           *P_ADC_Data;    
	extern P_ADC_Channel_DEF        *P_ADC_Channel;  

	/* E. SPI register */                                
	extern P_SPI_Ctrl_DEF        	*P_SPI_Ctrl;           
	extern P_SPI_TxStatus_DEF       *P_SPI_TxStatus;       
	extern P_SPI_TxBuf_DEF          *P_SPI_TxBuf;          
	extern P_SPI_RxStatus_DEF       *P_SPI_RxStatus;       
	extern P_SPI_RxBuf_DEF          *P_SPI_RxBuf;          
                                                         
	/* F. Flash organization and control register */     
	extern P_Flash_RW_DEF			*P_Flash_RW;           
	extern P_Flash_Cmd_DEF          *P_Flash_Cmd;         
                                                         
	/* G. UART control register */                       
	extern P_UART_Data_DEF 			*P_UART_Data;          
	extern P_UART_RXStatus_DEF      *P_UART_RXStatus;      
	extern P_UART_Ctrl_DEF          *P_UART_Ctrl;          
	extern P_UART_BaudRate_DEF      *P_UART_BaudRate;      
	extern P_UART_Status_DEF        *P_UART_Status;        
	
	/* H. Compare Match Timer register */
	extern P_CMT_Start_DEF			*P_CMT_Start;
	extern P_CMT_Ctrl_DEF			*P_CMT_Ctrl;
	extern GEN_REG_DEF				*P_CMT0_TCNT;
	extern GEN_REG_DEF				*P_CMT1_TCNT;
	extern GEN_REG_DEF				*P_CMT0_TPR;
	extern GEN_REG_DEF				*P_CMT1_TPR;
	
	/* I. Time Base register */
	extern GEN_REG_DEF				*P_TMB_Reset;
	extern P_BZO_Ctrl_DEF			*P_BZO_Ctrl;

#endif /* #ifndef SPMC75_REG_DEBUG */

/*****************************************************************************/
/* Chip-intrnal register constant macro definition						     */
/*****************************************************************************/
#define BIT0					0
#define BIT1					1
#define BIT2					2
#define BIT3					3
#define BIT4					4
#define BIT5					5
#define BIT6					6
#define BIT7					7
#define BIT8					8
#define BIT9					9
#define BIT10					10
#define BIT11					11
#define BIT12					12
#define BIT13					13
#define BIT14					14
#define BIT15					15

/*=================================*/
/* flash control register		   */
/*=================================*/
/* P_Wait_Enter register */ 
/* word set */
#define	CW_WaitCMD					0x5005
#define	CW_WaitClr					0x0001


/* P_Stdby_Enter register */ 
/* word set */
#define	CW_StdbyCMD					0xA00A
#define	CW_StdbyClr					0x0001

/* P_System_Option register */ 
/* bit set */
#define CB_SYS_CLK_R				0x0000			//R oscillator
#define CB_SYS_CLK_OSC				0x0001			//crystal oscillator

#define CB_SYS_WDG_Disable			0x0000			//disable watchdog function
#define CB_SYS_WDG_Enable			0x0001			//enable watchdog function

#define CB_SYS_LVR_Disable			0x0000			//disable low voltage reset function
#define CB_SYS_LVR_Enable			0x0001			//enable low voltage reset function

#define CB_SYS_LVD_Disable			0x0000			//disable low voltage detection function
#define CB_SYS_LVD_Enable			0x0001			//enable low voltage detection function

#define CB_SYS_Security_Protect		0x0000			//the normal block in the flash cannot be accessed
#define CB_SYS_Security_NoProtect	0x0001			//not protect, can be readable or write-able

#define CB_SYS_Verification 		0x02AA			//Verification Pattern
/* word set */
#define CW_SYS_CLK_R				0x0000
#define CW_SYS_CLK_OSC				0x0001

#define CW_SYS_WDG_Disable			(0x0000 << 1)
#define CW_SYS_WDG_Enable			(0x0001 << 1)

#define CW_SYS_LVR_Disable			(0x0000 << 2)
#define CW_SYS_LVR_Enable			(0x0001 << 2)

#define CW_SYS_LVD_Disable			(0x0000 << 3)
#define CW_SYS_LVD_Enable			(0x0001 << 3)

#define CW_SYS_Security_Protect		(0x0000 << 4)
#define CW_SYS_Security_NoProtect	(0x0001 << 4)

#define CW_SYS_Verification 		(0x02AA << 5)


/* P_Reset_Status register */ 
/* bit set */
#define CB_CLEAR_EXTRF				0x0001			//External reset pin reset flag
#define CB_CLEAR_PORF				0x0001			//Power-on reset flag
#define CB_CLEAR_WDRF				0x0001			//Watchdog reset flag
#define CB_CLEAR_LPLVRF				0x0001			//Long period low voltage reset flag
#define CB_CLEAR_SPLVRF				0x0001			//Short period low voltage reset flag
#define CB_CLEAR_IARF				0x0001			//Illegal address reset flag
#define CB_CLEAR_IIRF				0x0001			//Illegal instruction reset flag
#define CB_CLEAR_FCHK 				0x0055			//Flag clear check bits pattern
/* word set */
#define CW_CLEAR_EXTRF				0x0001
#define CW_CLEAR_PORF				(0x0001 << 1)
#define CW_CLEAR_WDRF				(0x0001 << 2)
#define CW_CLEAR_LVRF				(0x0001 << 3)
#define CW_CLEAR_IARF				(0x0001 << 5)
#define CW_CLEAR_IIRF				(0x0001 << 6)
#define CW_CLEAR_FCHK 				(0x0055 << 9)

/* P_Clk_Ctrl register */ 
/* bit set */
#define CB_CLK_OSCIE				0x0001			//Oscillator fail interrupt enable bit
#define CB_CLK_OSCSF				0x0001			//Oscillator status flag
/* word set */
#define CW_CLK_OSCIE				(0x0001 << 14)
#define CW_CLK_OSCSF				(0x0001 << 15)

/* P_WatchDog_Ctrl register */ 
/* bit set */
#define CB_WDPS_FCKdiv65536			0x0000			//Watchdog Timer Time-out Selections
#define CB_WDPS_FCKdiv32768			0x0001
#define CB_WDPS_FCKdiv16384			0x0002
#define CB_WDPS_FCKdiv8192			0x0003
#define CB_WDPS_FCKdiv4096			0x0004
#define CB_WDPS_FCKdiv2048			0x0005
#define CB_WDPS_FCKdiv1024			0x0006
#define CB_WDPS_FCKdiv512			0x0007

#define CB_WDCHK_Setting			0x0015			//Watchdog control register check bits

#define CB_WDRS_SYS_Reset			0x0000			//System reset
#define CB_WDRS_CPU_Reset			0x0001			//CPU reset

#define CB_WDEN						0x0001			//Watchdog timer enable bit
/* word set */
#define CW_WDPS_FCKdiv65536			0x0000
#define CW_WDPS_FCKdiv32768			0x0001
#define CW_WDPS_FCKdiv16384			0x0002
#define CW_WDPS_FCKdiv8192			0x0003
#define CW_WDPS_FCKdiv4096			0x0004
#define CW_WDPS_FCKdiv2048			0x0005
#define CW_WDPS_FCKdiv1024			0x0006
#define CW_WDPS_FCKdiv512			0x0007

#define CW_WDCHK_Setting			(0x0015 << 3)
#define CW_WDRS_SYS_Reset			(0x0000 << 14)
#define CW_WDRS_CPU_Reset			(0x0001 << 14)
#define CW_WDEN						(0x0001 << 15)

#define CW_WatchDog_Clear			0xA005

/* P_Wakeup_Ctrl register */ 
/* bit set */
#define CB_CMTWE_Enable				0x0001			//Compare match timer wake-up enable bit
#define CB_PDC0WE_Enable			0x0001			//PDC channel 0 wake-up enable bit
#define CB_PDC1WE_Enable			0x0001			//PDC channel 1 wake-up enable bit
#define CB_TPM2WE_Enable			0x0001			//TPM channel 2 wake-up enable bit
#define CB_EXT0WE_Enable			0x0001			//External interrupt 0 wake-up enable bit		
#define CB_EXT1WE_Enable			0x0001			//External interrupt 1 wake-up enable bit
#define CB_SPIWE_Enable				0x0001			//SPI wake-up enable bit
#define CB_UARTWE_Enable			0x0001			//UART wake-up enable bit	
#define CB_KEYWE_Enable				0x0001			// Key-change wake-up enable bit
/* word set */
#define CW_CMTWE_Enable				(0x0001<<4)
#define CW_PDC0WE_Enable			(0x0001<<5)
#define CW_PDC1WE_Enable			(0x0001<<6)
#define CW_TPM2WE_Enable			(0x0001<<7)
#define CW_EXT0WE_Enable			(0x0001<<11)
#define CW_EXT1WE_Enable			(0x0001<<12)
#define CW_SPIWE_Enable				(0x0001<<13)
#define CW_UARTWE_Enable			(0x0001<<14)
#define CW_KEYWE_Enable				(0x0001<<15)


/* P_Flash_RW register */
/* bit set */
#define	CB_BK15WDIS					(0x4000 >> 15)
#define	CB_BK14WDIS					(0x4000 >> 14)
#define	CB_BK13WDIS					(0x2000 >> 13)
#define	CB_BK12WDIS					(0x1000 >> 12)
#define	CB_BK11WDIS					(0x0800 >> 11)
#define	CB_BK10WDIS					(0x0400 >> 10)
#define	CB_BK9WDIS					(0x0200 >> 9)
#define	CB_BK8WDIS					(0x0100 >> 8)
#define	CB_BK7WDIS					(0x0080 >> 7)
#define	CB_BK6WDIS					(0x0040 >> 6)
#define	CB_BK5WDIS					(0x0020 >> 5)
#define	CB_BK4WDIS					(0x0010 >> 4)
#define	CB_BK3WDIS					(0x0008 >> 3)
#define	CB_BK2WDIS					(0x0004 >> 2)
#define	CB_BK1WDIS					(0x0002 >> 1)
#define	CB_BK0WDIS					0x0001
/* word set */
#define	CW_BK15WDIS					0x4000			//BANK 15 Write Disable
#define	CW_BK14WDIS					0x4000			//BANK 14 Write Disable
#define	CW_BK13WDIS					0x2000			//BANK 13 Write Disable
#define	CW_BK12WDIS					0x1000			//BANK 12 Write Disable
#define	CW_BK11WDIS					0x0800			//BANK 11 Write Disable
#define	CW_BK10WDIS					0x0400			//BANK 10 Write Disable
#define	CW_BK9WDIS					0x0200			//BANK 9 Write Disable
#define	CW_BK8WDIS					0x0100			//BANK 8 Write Disable
#define	CW_BK7WDIS					0x0080			//BANK 7 Write Disable
#define	CW_BK6WDIS					0x0040			//BANK 6 Write Disable
#define	CW_BK5WDIS					0x0020			//BANK 5 Write Disable
#define	CW_BK4WDIS					0x0010			//BANK 4 Write Disable
#define	CW_BK3WDIS					0x0008			//BANK 3 Write Disable
#define	CW_BK2WDIS					0x0004			//BANK 2 Write Disable
#define	CW_BK1WDIS					0x0002			//BANK 1 Write Disable
#define	CW_BK0WDIS					0x0001			//BANK 0 Write Disable

/* P_Flash_Cmd register */
/* word set */
#define	CW_FlashRW_CMD				0x5A5A			//Flash RW Command
#define	CW_FlashCMD					0xAAAA			//Flash Command FLash Block
#define	CW_PageErase				0x5511			//Flash Page Erase Command
#define	CW_Program					0x5533			//Flash Program Command
#define	CW_Sequential				0x5544			//Flash Sequential Program Command
#define	CW_SequentialEnd			0xFFFF			//Flash Sequential Program End Command

/* P_IOA_SPE register */
/* word set */
#define CW_IOA_TMR2_TGRA_SFR_EN		0x0200			//TGRA of Timer2 special function enable
#define CW_IOA_TMR2_TGRB_SFR_EN		0x0400			//TGRB of Timer2 special function enable
#define CW_IOA_TCLKA_SFR_EN			0x0800			//External clock A input enable
#define CW_IOA_TCLKB_SFR_EN			0x1000			//External clock B input enable
#define CW_IOA_TCLKC_SFR_EN			0x2000			//External clock C input enable
#define CW_IOA_TCLKD_SFREN			0x4000			//External clock D input enable

/* P_IOA_KCER register */
/* word set */
#define CW_IOA_KC8_EN				0x0100			//IOA8 key change enable
#define CW_IOA_KC9_EN				0x0200			//IOA9 key change enable
#define CW_IOA_KC10_EN				0x0400			//IOA10 key change enable
#define CW_IOA_KC11_EN				0x0800			//IOA11 key change enable
#define CW_IOA_KC12_EN				0x1000			//IOA12 key change enable
#define CW_IOA_KC13_EN				0x2000			//IOA13 key change enable
#define CW_IOA_KC14_EN				0x4000			//IOA14 key change enable
#define CW_IOA_KC15_EN				0x8000			//IOA15 key change enable

/* P_IOB_SPE register */
/* word set */
#define CW_IOB_W1N_SFR_EN			0x0001			//IOB0 serves as W1N
#define CW_IOB_V1N_SFR_EN			0x0002			//IOB1 serves as V1N
#define CW_IOB_U1N_SFR_EN			0x0004			//IOB2 serves as U1N
#define CW_IOB_W1_SFR_EN			0x0008			//IOB3 serves as W1
#define CW_IOB_V1_SFR_EN			0x0010			//IOB4 serves as V1
#define CW_IOB_U1_SFR_EN			0x0020			//IOB5 serves as U1
#define CW_IOB_FTIN1_SFR_EN			0x0040			//IOB6 serves as FTIN1
#define CW_IOB_OL1_SFR_EN			0x0080			//IOB7 serves as OL1
#define CW_IOB_TMR0_TGRC_SFR_EN		0x0100			//TGRC of Timer0 special function enable 
#define CW_IOB_TMR0_TGRB_SFR_EN		0x0200			//TGRB of Timer0 special function enable 
#define CW_IOB_TMR0_TGRA_SFR_EN		0x0400			//TGRA of Timer0 special function enable 

/* P_IOC_SPE register */
/* word set */
#define CW_IOC_EXTINT0_SFR_EN		0x0004			//IOC2 external input interrupt 0 enable
#define CW_IOC_EXTINT1_SFR_EN		0x0008			//IOC3 external input interrupt 0 enable
#define CW_IOC_TMR1_TGRA_SFR_EN		0x0020			//TGRA of Timer1 special function enable 
#define CW_IOC_TMR1_TGRB_SFR_EN		0x0040			//TGRB of Timer1 special function enable 
#define CW_IOC_TMR1_TGRC_SFR_EN		0x0080			//TGRC of Timer1 special function enable 
#define CW_IOC_OL2_SFR_EN			0x0100			//IOC8 serves as OL2
#define CW_IOC_FTIN2_SFR_EN			0x0200			//IOC9 serves as FTIN2
#define CW_IOC_U2_SFR_EN			0x0400			//IOC10 serves as U2
#define CW_IOC_V2_SFR_EN			0x0800			//IOC11 serves as V2
#define CW_IOC_W2_SFR_EN			0x1000			//IOC12 serves as W2
#define CW_IOC_U2N_SFR_EN			0x2000			//IOC13 serves as U2N
#define CW_IOC_V2N_SFR_EN			0x4000			//IOC14 serves as V2N
#define CW_IOC_W2N_SFR_EN			0x8000			//IOC15 serves as W2N

/*=================================*/
/* B. Timer0/Timer1/Timer2 register*/
/*=================================*/
/* P_TMR0_Ctrl register */
/* bit set */
#define CB_TMR0_TMRPS_FCKdiv1			0x0000			//Counts on FCK /1
#define CB_TMR0_TMRPS_FCKdiv4			0x0001			//Counts on FCK /4
#define CB_TMR0_TMRPS_FCKdiv16			0x0002			//Counts on FCK /16
#define CB_TMR0_TMRPS_FCKdiv64			0x0003			//Counts on FCK /64
#define CB_TMR0_TMRPS_FCKdiv256			0x0004			//Counts on FCK /256
#define CB_TMR0_TMRPS_FCKdiv1024		0x0005			//Counts on FCK /1024
#define CB_TMR0_TMRPS_TCLKA				0x0006			//Counts on TCLKA pin input
#define CB_TMR0_TMRPS_TCLKB				0x0007			//Counts on TCLKB pin input

#define CB_TMR0_CKEGS_Rising			0x0000			//Count at rising edge
#define CB_TMR0_CKEGS_Falling			0x0001			//Count at falling edge
#define CB_TMR0_CKEGS_Both				0x0002			//Count at both edges

#define CB_TMR0_CCLS_Disabled			0x0000			//TCNT clearing disabled	
#define CB_TMR0_CCLS_TGRA				0x0001			//TCNT cleared by P_Timer1/2_GeneralA capture input
#define CB_TMR0_CCLS_TGRB				0x0002			//TCNT cleared by P_Timer1/2_ GeneralB capture input
#define CB_TMR0_CCLS_TGRC				0x0003			//TCNT cleared by P_Timer1/2_GeneralC capture input
#define CB_TMR0_CCLS_PDR6				0x0004			//TCNT cleared by P_Timer1/2_PDR change 6 times
#define CB_TMR0_CCLS_PDR3				0x0005			//TCNT cleared by P_Timer1/2_PDR change 3 times
#define CB_TMR0_CCLS_PDR				0x0006			//TCNT cleared by P_PositionDetect1/2 compare match
#define CB_TMR0_CCLS_TPR				0x0007			//TCNT cleared by P_Timer1/2_Period compare match

#define CB_TMR0_CLEGS_NotClear			0x0000			//do not clear
#define CB_TMR0_CLEGS_Rising			0x0001			//rising edge
#define CB_TMR0_CLEGS_Falling			0x0002			//falling edge
#define CB_TMR0_CLEGS_Both				0x0003			//both edge

#define CB_TMR0_MODE_Normal				0x0000			//Normal operation (counter up-counting, compare match output mode)
#define CB_TMR0_MODE_Mode1				0x0004			//Phase counting mode 1 *1
#define CB_TMR0_MODE_Mode2				0x0005			//Phase counting mode 2 *1
#define CB_TMR0_MODE_Mode3				0x0006			//Phase counting mode 3 *1
#define CB_TMR0_MODE_Mode4				0x0007			//Phase counting mode 4 *1
#define CB_TMR0_MODE_PWM_Edge			0x0008			//1x0x= Edge-aligned PWM mode (counter up-count, PWM output)
#define CB_TMR0_MODE_PWM_Center			0x000A			//1x1x= Center-aligned PWM mode (counter continuous up-/down-count, PWM output)

#define CB_TMR0_SPCK_FCKdiv1			0x0000			//FCK/1
#define CB_TMR0_SPCK_FCKdiv2			0x0001			//FCK/2
#define CB_TMR0_SPCK_FCKdiv4			0x0002			//FCK/4
#define CB_TMR0_SPCK_FCKdiv8			0x0003			//FCK/8
/* word set */
#define CW_TMR0_TMRPS_FCKdiv1			0x0000
#define CW_TMR0_TMRPS_FCKdiv4			0x0001
#define CW_TMR0_TMRPS_FCKdiv16			0x0002
#define CW_TMR0_TMRPS_FCKdiv64			0x0003
#define CW_TMR0_TMRPS_FCKdiv256			0x0004
#define CW_TMR0_TMRPS_FCKdiv1024		0x0005
#define CW_TMR0_TMRPS_TCLKA				0x0006
#define CW_TMR0_TMRPS_TCLKB				0x0007

#define CW_TMR0_CKEGS_Rising			(0x0000 << 3)
#define CW_TMR0_CKEGS_Falling			(0x0001 << 3)
#define CW_TMR0_CKEGS_Both				(0x0002 << 3)

#define CW_TMR0_CCLS_Disabled			(0x0000 << 5)
#define CW_TMR0_CCLS_TGRA				(0x0001 << 5)
#define CW_TMR0_CCLS_TGRB				(0x0002 << 5)
#define CW_TMR0_CCLS_TGRC				(0x0003 << 5)
#define CW_TMR0_CCLS_PDR6				(0x0004 << 5)
#define CW_TMR0_CCLS_PDR3				(0x0005 << 5)
#define CW_TMR0_CCLS_PDR				(0x0006 << 5)
#define CW_TMR0_CCLS_TPR				(0x0007 << 5)

#define CW_TMR0_CLEGS_NotClear			(0x0000 << 8)
#define CW_TMR0_CLEGS_Rising			(0x0001 << 8)
#define CW_TMR0_CLEGS_Falling			(0x0002 << 8)
#define CW_TMR0_CLEGS_Both				(0x0003 << 8)

#define CW_TMR0_MODE_Normal				(0x0000 << 10)
#define CW_TMR0_MODE_Mode1				(0x0004 << 10)
#define CW_TMR0_MODE_Mode2				(0x0005 << 10)
#define CW_TMR0_MODE_Mode3				(0x0006 << 10)
#define CW_TMR0_MODE_Mode4				(0x0007 << 10)
#define CW_TMR0_MODE_PWM_Edge			(0x0008 << 10)
#define CW_TMR0_MODE_PWM_Center			(0x000A << 10)

#define CW_TMR0_SPCK_FCKdiv1			(0x0000 << 14)
#define CW_TMR0_SPCK_FCKdiv2			(0x0001 << 14)
#define CW_TMR0_SPCK_FCKdiv4			(0x0002 << 14)
#define CW_TMR0_SPCK_FCKdiv8			(0x0003 << 14)


/* P_TMR1_Ctrl register */
/* bit set */
#define CB_TMR1_TMRPS_FCKdiv1			0x0000			//Counts on FCK /1
#define CB_TMR1_TMRPS_FCKdiv4			0x0001			//Counts on FCK /4
#define CB_TMR1_TMRPS_FCKdiv16			0x0002			//Counts on FCK /16
#define CB_TMR1_TMRPS_FCKdiv64			0x0003			//Counts on FCK /64
#define CB_TMR1_TMRPS_FCKdiv256			0x0004			//Counts on FCK /256
#define CB_TMR1_TMRPS_FCKdiv1024		0x0005			//Counts on FCK /1024
#define CB_TMR1_TMRPS_TCLKA				0x0006			//Counts on TCLKA pin input
#define CB_TMR1_TMRPS_TCLKB				0x0007			//Counts on TCLKB pin input

#define CB_TMR1_CKEGS_Rising			0x0000			//Count at rising edge
#define CB_TMR1_CKEGS_Falling			0x0001			//Count at falling edge
#define CB_TMR1_CKEGS_Both				0x0002			//Count at both edges

#define CB_TMR1_CCLS_Disabled			0x0000			//TCNT clearing disabled	
#define CB_TMR1_CCLS_TGRA				0x0001			//TCNT cleared by P_Timer1/2_GeneralA capture input
#define CB_TMR1_CCLS_TGRB				0x0002			//TCNT cleared by P_Timer1/2_ GeneralB capture input
#define CB_TMR1_CCLS_TGRC				0x0003			//TCNT cleared by P_Timer1/2_GeneralC capture input
#define CB_TMR1_CCLS_PDR6				0x0004			//TCNT cleared by P_Timer1/2_PDR change 6 times
#define CB_TMR1_CCLS_PDR3				0x0005			//TCNT cleared by P_Timer1/2_PDR change 3 times
#define CB_TMR1_CCLS_PDR				0x0006			//TCNT cleared by P_PositionDetect1/2 compare match
#define CB_TMR1_CCLS_TPR				0x0007			//TCNT cleared by P_Timer1/2_Period compare match

#define CB_TMR1_CLEGS_NotClear			0x0000			//do not clear
#define CB_TMR1_CLEGS_Rising			0x0001			//rising edge
#define CB_TMR1_CLEGS_Falling			0x0002			//falling edge
#define CB_TMR1_CLEGS_Both				0x0003			//both edge

#define CB_TMR1_MODE_Normal				0x0000			//Normal operation (counter up-counting, compare match output mode)
#define CB_TMR1_MODE_Mode1				0x0004			//Phase counting mode 1 *1
#define CB_TMR1_MODE_Mode2				0x0005			//Phase counting mode 2 *1
#define CB_TMR1_MODE_Mode3				0x0006			//Phase counting mode 3 *1
#define CB_TMR1_MODE_Mode4				0x0007			//Phase counting mode 4 *1
#define CB_TMR1_MODE_PWM_Edge			0x0008			//1x0x= Edge-aligned PWM mode (counter up-count, PWM output)
#define CB_TMR1_MODE_PWM_Center			0x000A			//1x1x= Center-aligned PWM mode (counter continuous up-/down-count, PWM output)

#define CB_TMR1_SPCK_FCKdiv1			0x0000			//FCK/1
#define CB_TMR1_SPCK_FCKdiv2			0x0001			//FCK/2
#define CB_TMR1_SPCK_FCKdiv4			0x0002			//FCK/4
#define CB_TMR1_SPCK_FCKdiv8			0x0003			//FCK/8
/* word set */
#define CW_TMR1_TMRPS_FCKdiv1			0x0000
#define CW_TMR1_TMRPS_FCKdiv4			0x0001
#define CW_TMR1_TMRPS_FCKdiv16			0x0002
#define CW_TMR1_TMRPS_FCKdiv64			0x0003
#define CW_TMR1_TMRPS_FCKdiv256			0x0004
#define CW_TMR1_TMRPS_FCKdiv1024		0x0005
#define CW_TMR1_TMRPS_TCLKA				0x0006
#define CW_TMR1_TMRPS_TCLKB				0x0007

#define CW_TMR1_CKEGS_Rising			(0x0000 << 3)
#define CW_TMR1_CKEGS_Falling			(0x0001 << 3)
#define CW_TMR1_CKEGS_Both				(0x0002 << 3)

#define CW_TMR1_CCLS_Disabled			(0x0000 << 5)
#define CW_TMR1_CCLS_TGRA				(0x0001 << 5)
#define CW_TMR1_CCLS_TGRB				(0x0002 << 5)
#define CW_TMR1_CCLS_TGRC				(0x0003 << 5)
#define CW_TMR1_CCLS_PDR6				(0x0004 << 5)
#define CW_TMR1_CCLS_PDR3				(0x0005 << 5)
#define CW_TMR1_CCLS_PDR				(0x0006 << 5)
#define CW_TMR1_CCLS_TPR				(0x0007 << 5)

#define CW_TMR1_CLEGS_NotClear			(0x0000 << 8)
#define CW_TMR1_CLEGS_Rising			(0x0001 << 8)
#define CW_TMR1_CLEGS_Falling			(0x0002 << 8)
#define CW_TMR1_CLEGS_Both				(0x0003 << 8)

#define CW_TMR1_MODE_Normal				(0x0000 << 10)
#define CW_TMR1_MODE_Mode1				(0x0004 << 10)
#define CW_TMR1_MODE_Mode2				(0x0005 << 10)
#define CW_TMR1_MODE_Mode3				(0x0006 << 10)
#define CW_TMR1_MODE_Mode4				(0x0007 << 10)
#define CW_TMR1_MODE_PWM_Edge			(0x0008 << 10)
#define CW_TMR1_MODE_PWM_Center			(0x000A << 10)

#define CW_TMR1_SPCK_FCKdiv1			(0x0000 << 14)
#define CW_TMR1_SPCK_FCKdiv2			(0x0001 << 14)
#define CW_TMR1_SPCK_FCKdiv4			(0x0002 << 14)
#define CW_TMR1_SPCK_FCKdiv8			(0x0003 << 14)

/* P_TMR2_Ctrl register */
/* bit set */
#define CB_TMR2_TMRPS_FCKdiv1			0x0000			//Counts on FCK /1
#define CB_TMR2_TMRPS_FCKdiv4			0x0001			//Counts on FCK /4
#define CB_TMR2_TMRPS_FCKdiv16			0x0002			//Counts on FCK /16
#define CB_TMR2_TMRPS_FCKdiv64			0x0003			//Counts on FCK /64
#define CB_TMR2_TMRPS_FCKdiv256			0x0004			//Counts on FCK /256
#define CB_TMR2_TMRPS_FCKdiv1024		0x0005			//Counts on FCK /1024
#define CB_TMR2_TMRPS_TCLKA				0x0006			//Counts on TCLKA pin input
#define CB_TMR2_TMRPS_TCLKB				0x0007			//Counts on TCLKB pin input

#define CB_TMR2_CKEGS_Rising			0x0000			//Count at rising edge
#define CB_TMR2_CKEGS_Falling			0x0001			//Count at falling edge
#define CB_TMR2_CKEGS_Both				0x0002			//Count at both edges

#define CB_TMR2_CCLS_Disabled			0x0000			//TCNT clearing disabled	
#define CB_TMR2_CCLS_TGRA				0x0001			//TCNT cleared by P_Timer1/2_GeneralA capture input
#define CB_TMR2_CCLS_TGRB				0x0002			//TCNT cleared by P_Timer1/2_ GeneralB capture input
#define CB_TMR2_CCLS_TPR				0x0007			//TCNT cleared by P_Timer2_Period compare match

#define CB_TMR2_CLEGS_NotClear			0x0000			//do not clear
#define CB_TMR2_CLEGS_Rising			0x0001			//rising edge
#define CB_TMR2_CLEGS_Falling			0x0002			//falling edge
#define CB_TMR2_CLEGS_Both				0x0003			//both edge

#define CB_TMR2_MODE_Normal				0x0000			//Normal operation (counter up-counting, compare match output mode)
#define CB_TMR2_MODE_PWM_Edge			0x0008			//1x0x= Edge-aligned PWM mode (counter up-count, PWM output)
#define CB_TMR2_MODE_PWM_Center			0x000A			//1x1x= Center-aligned PWM mode (counter continuous up-/down-count, PWM output)

#define CB_TMR2_SPCK_FCKdiv1			0x0000			//FCK/1
#define CB_TMR2_SPCK_FCKdiv2			0x0001			//FCK/2
#define CB_TMR2_SPCK_FCKdiv4			0x0002			//FCK/4
#define CB_TMR2_SPCK_FCKdiv8			0x0003			//FCK/8
/* word set */
#define CW_TMR2_TMRPS_FCKdiv1			0x0000
#define CW_TMR2_TMRPS_FCKdiv4			0x0001
#define CW_TMR2_TMRPS_FCKdiv16			0x0002
#define CW_TMR2_TMRPS_FCKdiv64			0x0003
#define CW_TMR2_TMRPS_FCKdiv256			0x0004
#define CW_TMR2_TMRPS_FCKdiv1024		0x0005
#define CW_TMR2_TMRPS_TCLKA				0x0006
#define CW_TMR2_TMRPS_TCLKB				0x0007

#define CW_TMR2_CKEGS_Rising			(0x0000 << 3)
#define CW_TMR2_CKEGS_Falling			(0x0001 << 3)
#define CW_TMR2_CKEGS_Both				(0x0002 << 3)

#define CW_TMR2_CCLS_Disabled			(0x0000 << 5)
#define CW_TMR2_CCLS_TGRA				(0x0001 << 5)
#define CW_TMR2_CCLS_TGRB				(0x0002 << 5)
#define CW_TMR2_CCLS_TPR				(0x0007 << 5)

#define CW_TMR2_CLEGS_NotClear			(0x0000 << 8)
#define CW_TMR2_CLEGS_Rising			(0x0001 << 8)
#define CW_TMR2_CLEGS_Falling			(0x0002 << 8)
#define CW_TMR2_CLEGS_Both				(0x0003 << 8)

#define CW_TMR2_MODE_Normal				(0x0000 << 10)
#define CW_TMR2_MODE_PWM_Edge			(0x0008 << 10)
#define CW_TMR2_MODE_PWM_Center			(0x000A << 10)

#define CW_TMR2_SPCK_FCKdiv1			(0x0000 << 14)
#define CW_TMR2_SPCK_FCKdiv2			(0x0001 << 14)
#define CW_TMR2_SPCK_FCKdiv4			(0x0002 << 14)
#define CW_TMR2_SPCK_FCKdiv8			(0x0003 << 14)


/* P_TMR3_Ctrl register */
/* bit set */
#define CB_TMR3_TMRPS_FCKdiv1			0x0000			//Counts on FCK /1
#define CB_TMR3_TMRPS_FCKdiv4			0x0001			//Counts on FCK /4
#define CB_TMR3_TMRPS_FCKdiv16			0x0002			//Counts on FCK /16
#define CB_TMR3_TMRPS_FCKdiv64			0x0003			//Counts on FCK /64
#define CB_TMR3_TMRPS_FCKdiv256			0x0004			//Counts on FCK /256
#define CB_TMR3_TMRPS_FCKdiv1024		0x0005			//Counts on FCK /1024
#define CB_TMR3_TMRPS_TCLKA				0x0006			//Counts on TCLKA pin input
#define CB_TMR3_TMRPS_TCLKB				0x0007			//Counts on TCLKB pin input

#define CB_TMR3_CKEGS_Rising			0x0000			//Count at rising edge
#define CB_TMR3_CKEGS_Falling			0x0001			//Count at falling edge
#define CB_TMR3_CKEGS_Both				0x0002			//Count at both edges

#define CB_TMR3_CCLS_Disabled			0x0000			//TCNT clearing disabled	
#define CB_TMR3_CCLS_TPR				0x0007			//TCNT cleared by P_Timer3/4_Period compare match

//#define CB_TMR3_LDOK					0x0001			//TGRA-C ok to load

#define CB_TMR3_MODE_Normal				0x0000			//Normal operation (counter up-counting, compare match output mode)
#define CB_TMR3_MODE_PWM_Edge			0x0008			//1x0x= Edge-aligned PWM mode (counter up-count, PWM output)
#define CB_TMR3_MODE_PWM_Center			0x000A			//1x1x= Center-aligned PWM mode (counter continuous up-/down-count, PWM output)

#define CB_TMR3_PRDINT_Period			0x0000			//Interrupt every period
#define CB_TMR3_PRDINT_2Period			0x0001			//Interrupt once every 2 periods
#define CB_TMR3_PRDINT_4Period			0x0002			//Interrupt once every 4 periods
#define CB_TMR3_PRDINT_8Period			0x0003			//Interrupt once every 8 periods
/* word set */
#define CW_TMR3_TMRPS_FCKdiv1			0x0000
#define CW_TMR3_TMRPS_FCKdiv4			0x0001
#define CW_TMR3_TMRPS_FCKdiv16			0x0002
#define CW_TMR3_TMRPS_FCKdiv64			0x0003
#define CW_TMR3_TMRPS_FCKdiv256			0x0004
#define CW_TMR3_TMRPS_FCKdiv1024		0x0005
#define CW_TMR3_TMRPS_TCLKA				0x0006
#define CW_TMR3_TMRPS_TCLKB				0x0007

#define CW_TMR3_CKEGS_Rising			(0x0000 << 3)
#define CW_TMR3_CKEGS_Falling			(0x0001 << 3)
#define CW_TMR3_CKEGS_Both				(0x0002 << 3)

#define CW_TMR3_CCLS_Disabled			(0x0000 << 5)
#define CW_TMR3_CCLS_TPR				(0x0007 << 5)

//#define CW_TMR3_LDOK					(0x0001 << 9)

#define CW_TMR3_MODE_Normal				(0x0000 << 10)
#define CW_TMR3_MODE_PWM_Edge			(0x0008 << 10)
#define CW_TMR3_MODE_PWM_Center			(0x000A << 10)

#define CW_TMR3_PRDINT_Period			(0x0000 << 14)
#define CW_TMR3_PRDINT_2Period			(0x0001 << 14)
#define CW_TMR3_PRDINT_4Period			(0x0002 << 14)
#define CW_TMR3_PRDINT_8Period			(0x0003 << 14)

/* P_TMR4_Ctrl register */
/* bit set */
#define CB_TMR4_TMRPS_FCKdiv1			0x0000			//Counts on FCK /1
#define CB_TMR4_TMRPS_FCKdiv4			0x0001			//Counts on FCK /4
#define CB_TMR4_TMRPS_FCKdiv16			0x0002			//Counts on FCK /16
#define CB_TMR4_TMRPS_FCKdiv64			0x0003			//Counts on FCK /64
#define CB_TMR4_TMRPS_FCKdiv256			0x0004			//Counts on FCK /256
#define CB_TMR4_TMRPS_FCKdiv1024		0x0005			//Counts on FCK /1024
#define CB_TMR4_TMRPS_TCLKA				0x0006			//Counts on TCLKA pin input
#define CB_TMR4_TMRPS_TCLKB				0x0007			//Counts on TCLKB pin input

#define CB_TMR4_CKEGS_Rising			0x0000			//Count at rising edge
#define CB_TMR4_CKEGS_Falling			0x0001			//Count at falling edge
#define CB_TMR4_CKEGS_Both				0x0002			//Count at both edges

#define CB_TMR4_CCLS_Disabled			0x0000			//TCNT clearing disabled	
#define CB_TMR4_CCLS_TPR				0x0007			//TCNT cleared by P_Timer3/4_Period compare match

//#define CB_TMR4_LDOK					0x0001			//TGRA-C ok to load

#define CB_TMR4_MODE_Normal				0x0000			//Normal operation (counter up-counting, compare match output mode)
#define CB_TMR4_MODE_PWM_Edge			0x0008			//1x0x= Edge-aligned PWM mode (counter up-count, PWM output)
#define CB_TMR4_MODE_PWM_Center			0x000A			//1x1x= Center-aligned PWM mode (counter continuous up-/down-count, PWM output)

#define CB_TMR4_PRDINT_Period			0x0000			//Interrupt every period
#define CB_TMR4_PRDINT_2Period			0x0001			//Interrupt once every 2 periods
#define CB_TMR4_PRDINT_4Period			0x0002			//Interrupt once every 4 periods
#define CB_TMR4_PRDINT_8Period			0x0003			//Interrupt once every 8 periods
/* word set */
#define CW_TMR4_TMRPS_FCKdiv1			0x0000
#define CW_TMR4_TMRPS_FCKdiv4			0x0001
#define CW_TMR4_TMRPS_FCKdiv16			0x0002
#define CW_TMR4_TMRPS_FCKdiv64			0x0003
#define CW_TMR4_TMRPS_FCKdiv256			0x0004
#define CW_TMR4_TMRPS_FCKdiv1024		0x0005
#define CW_TMR4_TMRPS_TCLKA				0x0006
#define CW_TMR4_TMRPS_TCLKB				0x0007

#define CW_TMR4_CKEGS_Rising			(0x0000 << 3)
#define CW_TMR4_CKEGS_Falling			(0x0001 << 3)
#define CW_TMR4_CKEGS_Both				(0x0002 << 3)

#define CW_TMR4_CCLS_Disabled			(0x0000 << 5)
#define CW_TMR4_CCLS_TPR				(0x0007 << 5)

//#define CW_TMR4_LDOK					(0x0001 << 9)

#define CW_TMR4_MODE_Normal				(0x0000 << 10)
#define CW_TMR4_MODE_PWM_Edge			(0x0008 << 10)
#define CW_TMR4_MODE_PWM_Center			(0x000A << 10)

#define CW_TMR4_PRDINT_Period			(0x0000 << 14)
#define CW_TMR4_PRDINT_2Period			(0x0001 << 14)
#define CW_TMR4_PRDINT_4Period			(0x0002 << 14)
#define CW_TMR4_PRDINT_8Period			(0x0003 << 14)

/* P_TMR0_IOCtrl register */
/* bit set */
#define CB_TMR0_IOAMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR0_IOAMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR0_IOAMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR0_IOAMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR0_IOAMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold
#define CB_TMR0_IOAMOD_Capture_Rising	0x0008			//Capture Mode: Issue input capture interrupt at rising edge
#define CB_TMR0_IOAMOD_Capture_Falling	0x0009			//Capture Mode: Issue input capture interrupt at falling edge
#define CB_TMR0_IOAMOD_Capture_Both		0x000A			//Capture Mode: Issue input capture interrupt at both edges
#define CB_TMR0_IOAMOD_Capture_PDR		0x000C			//Capture Mode: Input capture when Position Detection Register changes

#define CB_TMR0_IOBMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR0_IOBMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR0_IOBMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR0_IOBMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR0_IOBMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold
#define CB_TMR0_IOBMOD_Capture_Rising	0x0008			//Capture Mode: Issue input capture interrupt at rising edge
#define CB_TMR0_IOBMOD_Capture_Falling	0x0009			//Capture Mode: Issue input capture interrupt at falling edge
#define CB_TMR0_IOBMOD_Capture_Both		0x000A			//Capture Mode: Issue input capture interrupt at both edges
#define CB_TMR0_IOBMOD_Capture_PDR		0x000C			//Capture Mode: Input capture when Position Detection Register changes

#define CB_TMR0_IOCMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR0_IOCMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR0_IOCMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR0_IOCMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR0_IOCMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold
#define CB_TMR0_IOCMOD_Capture_Rising	0x0008			//Capture Mode: Issue input capture interrupt at rising edge
#define CB_TMR0_IOCMOD_Capture_Falling	0x0009			//Capture Mode: Issue input capture interrupt at falling edge
#define CB_TMR0_IOCMOD_Capture_Both		0x000A			//Capture Mode: Issue input capture interrupt at both edges
#define CB_TMR0_IOCMOD_Capture_PDR		0x000C			//Capture Mode: Input capture when Position Detection Register changes
/* word set */
#define CW_TMR0_IOAMOD_Output_00		0x0000
#define CW_TMR0_IOAMOD_Output_01		0x0001
#define CW_TMR0_IOAMOD_Output_10		0x0002
#define CW_TMR0_IOAMOD_Output_11		0x0003
#define CW_TMR0_IOAMOD_Output_Hold		0x0004
#define CW_TMR0_IOAMOD_Capture_Rising	0x0008	
#define CW_TMR0_IOAMOD_Capture_Falling	0x0009	
#define CW_TMR0_IOAMOD_Capture_Both		0x000A	
#define CW_TMR0_IOAMOD_Capture_PDR		0x000C	

#define CW_TMR0_IOBMOD_Output_00		(0x0000 << 4)
#define CW_TMR0_IOBMOD_Output_01		(0x0001 << 4)
#define CW_TMR0_IOBMOD_Output_10		(0x0002 << 4)
#define CW_TMR0_IOBMOD_Output_11		(0x0003 << 4)
#define CW_TMR0_IOBMOD_Output_Hold		(0x0004 << 4)
#define CW_TMR0_IOBMOD_Capture_Rising	(0x0008 << 4)	
#define CW_TMR0_IOBMOD_Capture_Falling	(0x0009 << 4)	
#define CW_TMR0_IOBMOD_Capture_Both		(0x000A << 4)	
#define CW_TMR0_IOBMOD_Capture_PDR		(0x000C << 4)	

#define CW_TMR0_IOCMOD_Output_00		(0x0000 << 8)
#define CW_TMR0_IOCMOD_Output_01		(0x0001 << 8)
#define CW_TMR0_IOCMOD_Output_10		(0x0002 << 8)
#define CW_TMR0_IOCMOD_Output_11		(0x0003 << 8)
#define CW_TMR0_IOCMOD_Output_Hold		(0x0004 << 8)
#define CW_TMR0_IOCMOD_Capture_Rising	(0x0008 << 8)	
#define CW_TMR0_IOCMOD_Capture_Falling	(0x0009 << 8)	
#define CW_TMR0_IOCMOD_Capture_Both		(0x000A << 8)	
#define CW_TMR0_IOCMOD_Capture_PDR		(0x000C << 8)	


/* P_TMR1_IOCtrl register */
/* bit set */
#define CB_TMR1_IOAMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR1_IOAMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR1_IOAMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR1_IOAMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR1_IOAMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold
#define CB_TMR1_IOAMOD_Capture_Rising	0x0008			//Capture Mode: Issue input capture interrupt at rising edge
#define CB_TMR1_IOAMOD_Capture_Falling	0x0009			//Capture Mode: Issue input capture interrupt at falling edge
#define CB_TMR1_IOAMOD_Capture_Both		0x000A			//Capture Mode: Issue input capture interrupt at both edges
#define CB_TMR1_IOAMOD_Capture_PDR		0x000C			//Capture Mode: Input capture when Position Detection Register changes

#define CB_TMR1_IOBMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR1_IOBMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR1_IOBMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR1_IOBMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR1_IOBMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold
#define CB_TMR1_IOBMOD_Capture_Rising	0x0008			//Capture Mode: Issue input capture interrupt at rising edge
#define CB_TMR1_IOBMOD_Capture_Falling	0x0009			//Capture Mode: Issue input capture interrupt at falling edge
#define CB_TMR1_IOBMOD_Capture_Both		0x000A			//Capture Mode: Issue input capture interrupt at both edges
#define CB_TMR1_IOBMOD_Capture_PDR		0x000C			//Capture Mode: Input capture when Position Detection Register changes

#define CB_TMR1_IOCMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR1_IOCMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR1_IOCMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR1_IOCMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR1_IOCMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold
#define CB_TMR1_IOCMOD_Capture_Rising	0x0008			//Capture Mode: Issue input capture interrupt at rising edge
#define CB_TMR1_IOCMOD_Capture_Falling	0x0009			//Capture Mode: Issue input capture interrupt at falling edge
#define CB_TMR1_IOCMOD_Capture_Both		0x000A			//Capture Mode: Issue input capture interrupt at both edges
#define CB_TMR1_IOCMOD_Capture_PDR		0x000C			//Capture Mode: Input capture when Position Detection Register changes
/* word set */
#define CW_TMR1_IOAMOD_Output_00		0x0000
#define CW_TMR1_IOAMOD_Output_01		0x0001
#define CW_TMR1_IOAMOD_Output_10		0x0002
#define CW_TMR1_IOAMOD_Output_11		0x0003
#define CW_TMR1_IOAMOD_Output_Hold		0x0004
#define CW_TMR1_IOAMOD_Capture_Rising	0x0008	
#define CW_TMR1_IOAMOD_Capture_Falling	0x0009	
#define CW_TMR1_IOAMOD_Capture_Both		0x000A	
#define CW_TMR1_IOAMOD_Capture_PDR		0x000C	

#define CW_TMR1_IOBMOD_Output_00		(0x0000 << 4)
#define CW_TMR1_IOBMOD_Output_01		(0x0001 << 4)
#define CW_TMR1_IOBMOD_Output_10		(0x0002 << 4)
#define CW_TMR1_IOBMOD_Output_11		(0x0003 << 4)
#define CW_TMR1_IOBMOD_Output_Hold		(0x0004 << 4)
#define CW_TMR1_IOBMOD_Capture_Rising	(0x0008 << 4)	
#define CW_TMR1_IOBMOD_Capture_Falling	(0x0009 << 4)	
#define CW_TMR1_IOBMOD_Capture_Both		(0x000A << 4)	
#define CW_TMR1_IOBMOD_Capture_PDR		(0x000C << 4)	

#define CW_TMR1_IOCMOD_Output_00		(0x0000 << 8)
#define CW_TMR1_IOCMOD_Output_01		(0x0001 << 8)
#define CW_TMR1_IOCMOD_Output_10		(0x0002 << 8)
#define CW_TMR1_IOCMOD_Output_11		(0x0003 << 8)
#define CW_TMR1_IOCMOD_Output_Hold		(0x0004 << 8)
#define CW_TMR1_IOCMOD_Capture_Rising	(0x0008 << 8)	
#define CW_TMR1_IOCMOD_Capture_Falling	(0x0009 << 8)	
#define CW_TMR1_IOCMOD_Capture_Both		(0x000A << 8)	
#define CW_TMR1_IOCMOD_Capture_PDR		(0x000C << 8)	


/* P_TMR2_IOCtrl register */
/* bit set */
#define CB_TMR2_IOAMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR2_IOAMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR2_IOAMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR2_IOAMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR2_IOAMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold
#define CB_TMR2_IOAMOD_Capture_Rising	0x0008			//Capture Mode: Issue input capture interrupt at rising edge
#define CB_TMR2_IOAMOD_Capture_Falling	0x0009			//Capture Mode: Issue input capture interrupt at falling edge
#define CB_TMR2_IOAMOD_Capture_Both		0x000A			//Capture Mode: Issue input capture interrupt at both edges

#define CB_TMR2_IOBMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR2_IOBMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR2_IOBMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR2_IOBMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR2_IOBMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold
#define CB_TMR2_IOBMOD_Capture_Rising	0x0008			//Capture Mode: Issue input capture interrupt at rising edge
#define CB_TMR2_IOBMOD_Capture_Falling	0x0009			//Capture Mode: Issue input capture interrupt at falling edge
#define CB_TMR2_IOBMOD_Capture_Both		0x000A			//Capture Mode: Issue input capture interrupt at both edges
/* word set */
#define CW_TMR2_IOAMOD_Output_00		0x0000
#define CW_TMR2_IOAMOD_Output_01		0x0001
#define CW_TMR2_IOAMOD_Output_10		0x0002
#define CW_TMR2_IOAMOD_Output_11		0x0003
#define CW_TMR2_IOAMOD_Output_Hold		0x0004
#define CW_TMR2_IOAMOD_Capture_Rising	0x0008	
#define CW_TMR2_IOAMOD_Capture_Falling	0x0009	
#define CW_TMR2_IOAMOD_Capture_Both		0x000A	

#define CW_TMR2_IOBMOD_Output_00		(0x0000 << 4)
#define CW_TMR2_IOBMOD_Output_01		(0x0001 << 4)
#define CW_TMR2_IOBMOD_Output_10		(0x0002 << 4)
#define CW_TMR2_IOBMOD_Output_11		(0x0003 << 4)
#define CW_TMR2_IOBMOD_Output_Hold		(0x0004 << 4)
#define CW_TMR2_IOBMOD_Capture_Rising	(0x0008 << 4)	
#define CW_TMR2_IOBMOD_Capture_Falling	(0x0009 << 4)	
#define CW_TMR2_IOBMOD_Capture_Both		(0x000A << 4)	


/* P_TMR3_IOCtrl register */
/* bit set */
#define CB_TMR3_IOAMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR3_IOAMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR3_IOAMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR3_IOAMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR3_IOAMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold

#define CB_TMR3_IOBMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR3_IOBMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR3_IOBMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR3_IOBMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR3_IOBMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold

#define CB_TMR3_IOCMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR3_IOCMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR3_IOCMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR3_IOCMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR3_IOCMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold
/* word set */
#define CW_TMR3_IOAMOD_Output_00		0x0000
#define CW_TMR3_IOAMOD_Output_01		0x0001
#define CW_TMR3_IOAMOD_Output_10		0x0002
#define CW_TMR3_IOAMOD_Output_11		0x0003
#define CW_TMR3_IOAMOD_Output_Hold		0x0004

#define CW_TMR3_IOBMOD_Output_00		(0x0000 << 4)
#define CW_TMR3_IOBMOD_Output_01		(0x0001 << 4)
#define CW_TMR3_IOBMOD_Output_10		(0x0002 << 4)
#define CW_TMR3_IOBMOD_Output_11		(0x0003 << 4)
#define CW_TMR3_IOBMOD_Output_Hold		(0x0004 << 4)

#define CW_TMR3_IOCMOD_Output_00		(0x0000 << 8)
#define CW_TMR3_IOCMOD_Output_01		(0x0001 << 8)
#define CW_TMR3_IOCMOD_Output_10		(0x0002 << 8)
#define CW_TMR3_IOCMOD_Output_11		(0x0003 << 8)
#define CW_TMR3_IOCMOD_Output_Hold		(0x0004 << 8)


/* P_TMR4_IOCtrl register */
/* bit set */
#define CB_TMR4_IOAMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR4_IOAMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR4_IOAMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR4_IOAMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR4_IOAMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold

#define CB_TMR4_IOBMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR4_IOBMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR4_IOBMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR4_IOBMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR4_IOBMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold

#define CB_TMR4_IOCMOD_Output_00		0x0000			//Compare Mode: Initial output 0, 0 output at compare match
#define CB_TMR4_IOCMOD_Output_01		0x0001			//Compare Mode: Initial output 0, 1 output at compare match
#define CB_TMR4_IOCMOD_Output_10		0x0002			//Compare Mode: Initial output 1, 0 output at compare match
#define CB_TMR4_IOCMOD_Output_11		0x0003			//Compare Mode: Initial output 1, 1 output at compare match
#define CB_TMR4_IOCMOD_Output_Hold		0x0004			//Compare Mode: 01xx= Output hold
/* word set */
#define CW_TMR4_IOAMOD_Output_00		0x0000
#define CW_TMR4_IOAMOD_Output_01		0x0001
#define CW_TMR4_IOAMOD_Output_10		0x0002
#define CW_TMR4_IOAMOD_Output_11		0x0003
#define CW_TMR4_IOAMOD_Output_Hold		0x0004

#define CW_TMR4_IOBMOD_Output_00		(0x0000 << 4)
#define CW_TMR4_IOBMOD_Output_01		(0x0001 << 4)
#define CW_TMR4_IOBMOD_Output_10		(0x0002 << 4)
#define CW_TMR4_IOBMOD_Output_11		(0x0003 << 4)
#define CW_TMR4_IOBMOD_Output_Hold		(0x0004 << 4)

#define CW_TMR4_IOCMOD_Output_00		(0x0000 << 8)
#define CW_TMR4_IOCMOD_Output_01		(0x0001 << 8)
#define CW_TMR4_IOCMOD_Output_10		(0x0002 << 8)
#define CW_TMR4_IOCMOD_Output_11		(0x0003 << 8)
#define CW_TMR4_IOCMOD_Output_Hold		(0x0004 << 8)


/* P_TMR0_INT register */
/* bit set */
#define CB_TMR0_TGAIE_Enable			0x0001			//Timer General A Register interrupt enable bit
#define CB_TMR0_TGBIE_Enable			0x0001			//Timer General B Register interrupt enable bit
#define CB_TMR0_TGCIE_Enable			0x0001			//Timer General C Register interrupt enable bit
#define CB_TMR0_TPRIE_Enable			0x0001			//Timer Period Register interrupt enable bit
#define CB_TMR0_TCVIE_Enable			0x0001			//Overflow interrupt enable bit
#define CB_TMR0_TCUIE_Enable			0x0001			//Underflow interrupt enable bit
#define CB_TMR0_TADSE_Enable			0x0001			//A/D conversion start request enable bit
#define CB_TMR0_PDCIE_Enable			0x0001			//Position detection change interrupt enable bit
/* word set */
#define CW_TMR0_TGAIE_Enable			0x0001	
#define CW_TMR0_TGBIE_Enable			(0x0001 << 1)	
#define CW_TMR0_TGCIE_Enable			(0x0001 << 2)	
#define CW_TMR0_TPRIE_Enable			(0x0001 << 4)	
#define CW_TMR0_TCVIE_Enable			(0x0001 << 5)	
#define CW_TMR0_TCUIE_Enable			(0x0001 << 6)	
#define CW_TMR0_TADSE_Enable			(0x0001 << 7)	
#define CW_TMR0_PDCIE_Enable			(0x0001 << 8)	


/* P_TMR1_INT register */
/* bit set */
#define CB_TMR1_TGAIE_Enable			0x0001			//Timer General A Register interrupt enable bit
#define CB_TMR1_TGBIE_Enable			0x0001			//Timer General B Register interrupt enable bit
#define CB_TMR1_TGCIE_Enable			0x0001			//Timer General C Register interrupt enable bit
#define CB_TMR1_TPRIE_Enable			0x0001			//Timer Period Register interrupt enable bit
#define CB_TMR1_TCVIE_Enable			0x0001			//Overflow interrupt enable bit
#define CB_TMR1_TCUIE_Enable			0x0001			//Underflow interrupt enable bit
#define CB_TMR1_TADSE_Enable			0x0001			//A/D conversion start request enable bit
#define CB_TMR1_PDCIE_Enable			0x0001			//Position detection change interrupt enable bit
/* word set */
#define CW_TMR1_TGAIE_Enable			0x0001	
#define CW_TMR1_TGBIE_Enable			(0x0001 << 1)	
#define CW_TMR1_TGCIE_Enable			(0x0001 << 2)	
#define CW_TMR1_TPRIE_Enable			(0x0001 << 4)	
#define CW_TMR1_TCVIE_Enable			(0x0001 << 5)	
#define CW_TMR1_TCUIE_Enable			(0x0001 << 6)	
#define CW_TMR1_TADSE_Enable			(0x0001 << 7)	
#define CW_TMR1_PDCIE_Enable			(0x0001 << 8)	


/* P_TMR2_INT register */
/* bit set */
#define CB_TMR2_TGAIE_Enable			0x0001			//Timer General A Register interrupt enable bit
#define CB_TMR2_TGBIE_Enable			0x0001			//Timer General B Register interrupt enable bit
#define CB_TMR2_TPRIE_Enable			0x0001			//Timer Period Register interrupt enable bit
#define CB_TMR2_TADSE_Enable			0x0001			//A/D conversion start request enable bit
/* word set */
#define CW_TMR2_TGAIE_Enable			0x0001	
#define CW_TMR2_TGBIE_Enable			(0x0001 << 1)	
#define CW_TMR2_TPRIE_Enable			(0x0001 << 4)	
#define CW_TMR2_TADSE_Enable			(0x0001 << 7)	


/* P_TMR3_INT register */
/* bit set */
#define CB_TMR3_TGDIE_Enable			0x0001			//Timer General D Register interrupt enable bit
#define CB_TMR3_TPRIE_Enable			0x0001			//Timer Period Register interrupt enable bit
#define CB_TMR3_TADSE_Enable			0x0001			//A/D conversion start request enable bit
/* word set */
#define CW_TMR3_TGDIE_Enable			(0x0001 << 3)	
#define CW_TMR3_TPRIE_Enable			(0x0001 << 4)	
#define CW_TMR3_TADSE_Enable			(0x0001 << 7)	


/* P_TMR4_INT register */
/* bit set */
#define CB_TMR4_TGDIE_Enable			0x0001			//Timer General D Register interrupt enable bit
#define CB_TMR4_TPRIE_Enable			0x0001			//Timer Period Register interrupt enable bit
#define CB_TMR4_TADSE_Enable			0x0001			//A/D conversion start request enable bit
/* word set */
#define CW_TMR4_TGDIE_Enable			(0x0001 << 3)	
#define CW_TMR4_TPRIE_Enable			(0x0001 << 4)	
#define CW_TMR4_TADSE_Enable			(0x0001 << 7)	


/* P_TMR0_Status register */
/* bit set */
#define CB_TMR0_TGAIF_Enable			0x0001			//Timer General A Register capture/output compare flag
#define CB_TMR0_TGBIF_Enable			0x0001			//Timer General B Register capture/output compare flag
#define CB_TMR0_TGCIF_Enable			0x0001			//Timer General C Register capture/output compare flag
#define CB_TMR0_TPRIF_Enable			0x0001			//Timer Period Register output compare flag
#define CB_TMR0_TCVIF_Enable			0x0001			//Timer Counter Overflow flag
#define CB_TMR0_TCUIF_Enable			0x0001			//Timer Counter Underflow flag
#define CB_TMR0_TCDF_Enable				0x0001			//Timer Counter Count direction flag
#define CB_TMR0_PDCIF_Enable			0x0001			//Position detection changes interrupt flag
/* word set */
#define CW_TMR0_TGAIF_Enable			0x0001	
#define CW_TMR0_TGBIF_Enable			(0x0001 << 1)	
#define CW_TMR0_TGCIF_Enable			(0x0001 << 2)	
#define CW_TMR0_TPRIF_Enable			(0x0001 << 4)	
#define CW_TMR0_TCVIF_Enable			(0x0001 << 5)	
#define CW_TMR0_TCUIF_Enable			(0x0001 << 6)	
#define CW_TMR0_TCDF_Enable				(0x0001 << 7)	
#define CW_TMR0_PDCIF_Enable			(0x0001 << 8)	


/* P_TMR1_Status register */
/* bit set */
#define CB_TMR1_TGAIF_Enable			0x0001			//Timer General A Register capture/output compare flag
#define CB_TMR1_TGBIF_Enable			0x0001			//Timer General B Register capture/output compare flag
#define CB_TMR1_TGCIF_Enable			0x0001			//Timer General C Register capture/output compare flag
#define CB_TMR1_TPRIF_Enable			0x0001			//Timer Period Register output compare flag
#define CB_TMR1_TCVIF_Enable			0x0001			//Timer Counter Overflow flag
#define CB_TMR1_TCUIF_Enable			0x0001			//Timer Counter Underflow flag
#define CB_TMR1_TCDF_Enable				0x0001			//Timer Counter Count direction flag
#define CB_TMR1_PDCIF_Enable			0x0001			//Position detection changes interrupt flag
/* word set */
#define CW_TMR1_TGAIF_Enable			0x0001	
#define CW_TMR1_TGBIF_Enable			(0x0001 << 1)	
#define CW_TMR1_TGCIF_Enable			(0x0001 << 2)	
#define CW_TMR1_TPRIF_Enable			(0x0001 << 4)	
#define CW_TMR1_TCVIF_Enable			(0x0001 << 5)	
#define CW_TMR1_TCUIF_Enable			(0x0001 << 6)	
#define CW_TMR1_TCDF_Enable				(0x0001 << 7)	
#define CW_TMR1_PDCIF_Enable			(0x0001 << 8)	


/* P_TMR2_Status register */
/* bit set */
#define CB_TMR2_TGAIF_Enable			0x0001			//Timer General A Register capture/output compare flag
#define CB_TMR2_TGBIF_Enable			0x0001			//Timer General B Register capture/output compare flag
#define CB_TMR2_TPRIF_Enable			0x0001			//Timer Period Register output compare flag
#define CB_TMR2_TCDF_Enable				0x0001			//Timer Count direction flag
/* word set */
#define CW_TMR2_TGAIF_Enable			0x0001	
#define CW_TMR2_TGBIF_Enable			(0x0001 << 1)	
#define CW_TMR2_TPRIF_Enable			(0x0001 << 4)	
#define CW_TMR2_TCDF_Enable				(0x0001 << 7)	


/* P_TMR3_Status register */
/* bit set */
#define CB_TMR3_TGDIF_Enable			0x0001			//Timer General D Register capture/output compare flag
#define CB_TMR3_TPRIF_Enable			0x0001			//Timer Period Register output compare flag
#define CB_TMR3_TCDF_Enable				0x0001			//Timer Count direction flag
/* word set */
#define CW_TMR3_TGDIF_Enable			(0x0001 << 3)	
#define CW_TMR3_TPRIF_Enable			(0x0001 << 4)	
#define CW_TMR3_TCDF_Enable				(0x0001 << 7)	


/* P_TMR4_Status register */
/* bit set */
#define CB_TMR4_TGDIF_Enable			0x0001			//Timer General D Register capture/output compare flag
#define CB_TMR4_TPRIF_Enable			0x0001			//Timer Period Register output compare flag
#define CB_TMR4_TCDF_Enable				0x0001			//Timer Count direction flag
/* word set */
#define CW_TMR4_TGDIF_Enable			(0x0001 << 3)	
#define CW_TMR4_TPRIF_Enable			(0x0001 << 4)	
#define CW_TMR4_TCDF_Enable				(0x0001 << 7)	


/* P_TMR_Start register */
/* bit set */
#define CB_TMR_TMR0ST_Start				0x0001			//Timer 0 counter start setting
#define CB_TMR_TMR1ST_Start				0x0001			//Timer 1 counter start setting
#define CB_TMR_TMR2ST_Start				0x0001			//Timer 2 counter start setting
#define CB_TMR_TMR3ST_Start				0x0001			//Timer 3 counter start setting
#define CB_TMR_TMR4ST_Start				0x0001			//Timer 4 counter start setting
/* word set */
#define CW_TMR_TMR0ST_Start				0x0001	
#define CW_TMR_TMR1ST_Start				(0x0001 << 1)	
#define CW_TMR_TMR2ST_Start				(0x0001 << 2)	
#define CW_TMR_TMR3ST_Start				(0x0001 << 3)	
#define CW_TMR_TMR4ST_Start				(0x0001 << 4)	


/* P_TMR_Output register */
/* bit set */
#define CB_TMR_TMR3AOE_Enable			0x0001			//Timer 3 IOA Output enable(TIO3A)
#define CB_TMR_TMR3BOE_Enable			0x0001			//Timer 3 IOB Output enable(TIO3B)
#define CB_TMR_TMR3COE_Enable			0x0001			//Timer 3 IOC Output enable(TIO3C)
#define CB_TMR_TMR3DOE_Enable			0x0001			//Timer 3 IOD Output enable(TIO3D)
#define CB_TMR_TMR3EOE_Enable			0x0001			//Timer 3 IOE Output enable(TIO3E)
#define CB_TMR_TMR3FOE_Enable			0x0001			//Timer 3 IOF Output enable(TIO3F)
#define CB_TMR_TMR4AOE_Enable			0x0001			//Timer 4 IOA Output enable(TIO4A)
#define CB_TMR_TMR4BOE_Enable			0x0001			//Timer 4 IOB Output enable(TIO4B)
#define CB_TMR_TMR4COE_Enable			0x0001			//Timer 4 IOC Output enable(TIO4C)
#define CB_TMR_TMR4DOE_Enable			0x0001			//Timer 4 IOD Output enable(TIO4D)
#define CB_TMR_TMR4EOE_Enable			0x0001			//Timer 4 IOE Output enable(TIO4E)
#define CB_TMR_TMR4FOE_Enable			0x0001			//Timer 4 IOF Output enable(TIO4F)
/* word set */
#define CW_TMR_TMR3AOE_Enable			0x0001
#define CW_TMR_TMR3BOE_Enable			(0x0001 << 1)
#define CW_TMR_TMR3COE_Enable			(0x0001 << 2)
#define CW_TMR_TMR3DOE_Enable			(0x0001 << 3)
#define CW_TMR_TMR3EOE_Enable			(0x0001 << 4)
#define CW_TMR_TMR3FOE_Enable			(0x0001 << 5)
#define CW_TMR_TMR4AOE_Enable			(0x0001 << 8)
#define CW_TMR_TMR4BOE_Enable			(0x0001 << 9)
#define CW_TMR_TMR4COE_Enable			(0x0001 << 10)
#define CW_TMR_TMR4DOE_Enable			(0x0001 << 11)
#define CW_TMR_TMR4EOE_Enable			(0x0001 << 12)
#define CW_TMR_TMR4FOE_Enable			(0x0001 << 13)


/* P_TMR3_OutputCtrl register */
/* bit set */
#define CB_TMR3_UOC_Mode0				0x0000			//U phase output control
#define CB_TMR3_UOC_Mode1				0x0001
#define CB_TMR3_UOC_Mode2				0x0002
#define CB_TMR3_UOC_Mode3				0x0003

#define CB_TMR3_VOC_Mode0				0x0000			//V phase output control
#define CB_TMR3_VOC_Mode1				0x0001
#define CB_TMR3_VOC_Mode2				0x0002
#define CB_TMR3_VOC_Mode3				0x0003

#define CB_TMR3_WOC_Mode0				0x0000			//W phase output control
#define CB_TMR3_WOC_Mode1				0x0001
#define CB_TMR3_WOC_Mode2				0x0002
#define CB_TMR3_WOC_Mode3				0x0003

#define CB_TMR3_SYNC_NoSync				0x0000			//No sync
#define CB_TMR3_SYNC_PDR				0x0001			//Synchronized to Position Detection Register change
#define CB_TMR3_SYNC_TGB				0x0002			//Synchronized to Timer General B Register compare match
#define CB_TMR3_SYNC_TGC				0x0003			//Synchronized to Timer General C Register compare match

#define CB_TMR3_UPWM_Out_HL				0x0000			//U phase PWM output select: H/L level output
#define CB_TMR3_UPWM_Out_PWM			0x0001			//U phase PWM output select: PWM waveform output
#define CB_TMR3_VPWM_Out_HL				0x0000			//V phase PWM output select: H/L level output
#define CB_TMR3_VPWM_Out_PWM			0x0001			//V phase PWM output select: PWM waveform output
#define CB_TMR3_WPWM_Out_HL				0x0000			//W phase PWM output select: H/L level output
#define CB_TMR3_WPWM_Out_PWM			0x0001			//W phase PWM output select: PWM waveform output

#define CB_TMR3_POLP_Active_Low			0x0000			//Upper phase polarity select.Active low
#define CB_TMR3_POLP_Active_High		0x0001			//Upper phase polarity select.Active high

#define CB_TMR3_DUTYMODE_UCom			0x0000			//U phase in common (same as Timer General A Register)
#define CB_TMR3_DUTYMODE_Independent	0x0001			//Three phases independent

/* word set */
#define CW_TMR3_UOC_Mode0				0x0000	
#define CW_TMR3_UOC_Mode1				0x0001
#define CW_TMR3_UOC_Mode2				0x0002
#define CW_TMR3_UOC_Mode3				0x0003

#define CW_TMR3_VOC_Mode0				(0x0000 << 2)	
#define CW_TMR3_VOC_Mode1				(0x0001 << 2)
#define CW_TMR3_VOC_Mode2				(0x0002 << 2)
#define CW_TMR3_VOC_Mode3				(0x0003 << 2)

#define CW_TMR3_WOC_Mode0				(0x0000 << 4)	
#define CW_TMR3_WOC_Mode1				(0x0001 << 4)
#define CW_TMR3_WOC_Mode2				(0x0002 << 4)
#define CW_TMR3_WOC_Mode3				(0x0003 << 4)

#define CW_TMR3_SYNC_NoSync				(0x0000 << 6)	
#define CW_TMR3_SYNC_PDR				(0x0001 << 6)	
#define CW_TMR3_SYNC_TGB				(0x0002 << 6)	
#define CW_TMR3_SYNC_TGC				(0x0003 << 6)	

#define CW_TMR3_UPWM_Out_HL				(0x0000 << 8)	
#define CW_TMR3_UPWM_Out_PWM			(0x0001 << 8)	
#define CW_TMR3_VPWM_Out_HL				(0x0000 << 9)	
#define CW_TMR3_VPWM_Out_PWM			(0x0001 << 9)	
#define CW_TMR3_WPWM_Out_HL				(0x0000 << 10)
#define CW_TMR3_WPWM_Out_PWM			(0x0001 << 10)

#define CW_TMR3_POLP_Active_Low			(0x0000 << 14)
#define CW_TMR3_POLP_Active_High		(0x0001 << 14)

#define CW_TMR3_DUTYMODE_UCom			(0x0000 << 15)
#define CW_TMR3_DUTYMODE_Independent	(0x0001 << 15)

/* POLP = 1 */
#define CW_TMR3_POLP_1_UP_CPWM_UN_PWM			(CW_TMR3_UOC_Mode0 | CW_TMR3_UPWM_Out_PWM)
#define CW_TMR3_POLP_1_UP_L_UN_PWM				(CW_TMR3_UOC_Mode1 | CW_TMR3_UPWM_Out_PWM)				
#define CW_TMR3_POLP_1_UP_PWM_UN_L				(CW_TMR3_UOC_Mode2 | CW_TMR3_UPWM_Out_PWM)
#define CW_TMR3_POLP_1_UP_PWM_UN_CPWM			(CW_TMR3_UOC_Mode3 | CW_TMR3_UPWM_Out_PWM)

#define CW_TMR3_POLP_1_VP_CPWM_VN_PWM			(CW_TMR3_VOC_Mode0 | CW_TMR3_VPWM_Out_PWM)
#define CW_TMR3_POLP_1_VP_L_VN_PWM				(CW_TMR3_VOC_Mode1 | CW_TMR3_VPWM_Out_PWM)				
#define CW_TMR3_POLP_1_VP_PWM_VN_L				(CW_TMR3_VOC_Mode2 | CW_TMR3_VPWM_Out_PWM)
#define CW_TMR3_POLP_1_VP_PWM_VN_CPWM			(CW_TMR3_VOC_Mode3 | CW_TMR3_VPWM_Out_PWM)

#define CW_TMR3_POLP_1_WP_CPWM_WN_PWM			(CW_TMR3_WOC_Mode0 | CW_TMR3_WPWM_Out_PWM)
#define CW_TMR3_POLP_1_WP_L_WN_PWM				(CW_TMR3_WOC_Mode1 | CW_TMR3_WPWM_Out_PWM)				
#define CW_TMR3_POLP_1_WP_PWM_WN_L				(CW_TMR3_WOC_Mode2 | CW_TMR3_WPWM_Out_PWM)
#define CW_TMR3_POLP_1_WP_PWM_WN_CPWM			(CW_TMR3_WOC_Mode3 | CW_TMR3_WPWM_Out_PWM)

#define CW_TMR3_POLP_1_UP_L_UN_L				(CW_TMR3_UOC_Mode0 | CW_TMR3_UPWM_Out_HL)
#define CW_TMR3_POLP_1_UP_L_UN_H				(CW_TMR3_UOC_Mode1 | CW_TMR3_UPWM_Out_HL)
#define CW_TMR3_POLP_1_UP_H_UN_L				(CW_TMR3_UOC_Mode2 | CW_TMR3_UPWM_Out_HL)
#define CW_TMR3_POLP_1_UP_H_UN_H				(CW_TMR3_UOC_Mode3 | CW_TMR3_UPWM_Out_HL)

#define CW_TMR3_POLP_1_VP_L_VN_L				(CW_TMR3_VOC_Mode0 | CW_TMR3_VPWM_Out_HL)
#define CW_TMR3_POLP_1_VP_L_VN_H				(CW_TMR3_VOC_Mode1 | CW_TMR3_VPWM_Out_HL)
#define CW_TMR3_POLP_1_VP_H_VN_L				(CW_TMR3_VOC_Mode2 | CW_TMR3_VPWM_Out_HL)
#define CW_TMR3_POLP_1_VP_H_VN_H				(CW_TMR3_VOC_Mode3 | CW_TMR3_VPWM_Out_HL)

#define CW_TMR3_POLP_1_WP_L_WN_L				(CW_TMR3_WOC_Mode0 | CW_TMR3_WPWM_Out_HL)
#define CW_TMR3_POLP_1_WP_L_WN_H				(CW_TMR3_WOC_Mode1 | CW_TMR3_WPWM_Out_HL)
#define CW_TMR3_POLP_1_WP_H_WN_L				(CW_TMR3_WOC_Mode2 | CW_TMR3_WPWM_Out_HL)
#define CW_TMR3_POLP_1_WP_H_WN_H				(CW_TMR3_WOC_Mode3 | CW_TMR3_WPWM_Out_HL)

/* POLP = 0 */
#define CW_TMR3_POLP_0_UP_PWM_UN_CPWM			(CW_TMR3_UOC_Mode0 | CW_TMR3_UPWM_Out_PWM)
#define CW_TMR3_POLP_0_UP_H_UN_CPWM				(CW_TMR3_UOC_Mode1 | CW_TMR3_UPWM_Out_PWM)
#define CW_TMR3_POLP_0_UP_CPWM_UN_H				(CW_TMR3_UOC_Mode2 | CW_TMR3_UPWM_Out_PWM)
#define CW_TMR3_POLP_0_UP_CPWM_UN_PWM			(CW_TMR3_UOC_Mode3 | CW_TMR3_UPWM_Out_PWM)

#define CW_TMR3_POLP_0_VP_PWM_VN_CPWM			(CW_TMR3_VOC_Mode0 | CW_TMR3_VPWM_Out_PWM)
#define CW_TMR3_POLP_0_VP_H_VN_CPWM				(CW_TMR3_VOC_Mode1 | CW_TMR3_VPWM_Out_PWM)
#define CW_TMR3_POLP_0_VP_CPWM_VN_H				(CW_TMR3_VOC_Mode2 | CW_TMR3_VPWM_Out_PWM)
#define CW_TMR3_POLP_0_VP_CPWM_VN_PWM			(CW_TMR3_VOC_Mode3 | CW_TMR3_VPWM_Out_PWM)

#define CW_TMR3_POLP_0_WP_PWM_WN_CPWM			(CW_TMR3_WOC_Mode0 | CW_TMR3_WPWM_Out_PWM)
#define CW_TMR3_POLP_0_WP_H_WN_CPWM				(CW_TMR3_WOC_Mode1 | CW_TMR3_WPWM_Out_PWM)
#define CW_TMR3_POLP_0_WP_CPWM_WN_H				(CW_TMR3_WOC_Mode2 | CW_TMR3_WPWM_Out_PWM)
#define CW_TMR3_POLP_0_WP_CPWM_WN_PWM			(CW_TMR3_WOC_Mode3 | CW_TMR3_WPWM_Out_PWM)

#define CW_TMR3_POLP_0_UP_H_UN_H				(CW_TMR3_UOC_Mode0 | CW_TMR3_UPWM_Out_HL)
#define CW_TMR3_POLP_0_UP_H_UN_L				(CW_TMR3_UOC_Mode1 | CW_TMR3_UPWM_Out_HL)
#define CW_TMR3_POLP_0_UP_L_UN_H				(CW_TMR3_UOC_Mode2 | CW_TMR3_UPWM_Out_HL)
#define CW_TMR3_POLP_0_UP_L_UN_L				(CW_TMR3_UOC_Mode3 | CW_TMR3_UPWM_Out_HL)

#define CW_TMR3_POLP_0_VP_H_VN_H				(CW_TMR3_VOC_Mode0 | CW_TMR3_VPWM_Out_HL)
#define CW_TMR3_POLP_0_VP_H_VN_L				(CW_TMR3_VOC_Mode1 | CW_TMR3_VPWM_Out_HL)
#define CW_TMR3_POLP_0_VP_L_VN_H				(CW_TMR3_VOC_Mode2 | CW_TMR3_VPWM_Out_HL)
#define CW_TMR3_POLP_0_VP_L_VN_L				(CW_TMR3_VOC_Mode3 | CW_TMR3_VPWM_Out_HL)

#define CW_TMR3_POLP_0_WP_H_WN_H				(CW_TMR3_WOC_Mode0 | CW_TMR3_WPWM_Out_HL)
#define CW_TMR3_POLP_0_WP_H_WN_L				(CW_TMR3_WOC_Mode1 | CW_TMR3_WPWM_Out_HL)
#define CW_TMR3_POLP_0_WP_L_WN_H				(CW_TMR3_WOC_Mode2 | CW_TMR3_WPWM_Out_HL)
#define CW_TMR3_POLP_0_WP_L_WN_L				(CW_TMR3_WOC_Mode3 | CW_TMR3_WPWM_Out_HL)


/* P_TMR4_OutputCtrl register */
/* bit set */
#define CB_TMR4_UOC_Mode0				0x0000			//U phase output control
#define CB_TMR4_UOC_Mode1				0x0001
#define CB_TMR4_UOC_Mode2				0x0002
#define CB_TMR4_UOC_Mode3				0x0003

#define CB_TMR4_VOC_Mode0				0x0000			//V phase output control
#define CB_TMR4_VOC_Mode1				0x0001
#define CB_TMR4_VOC_Mode2				0x0002
#define CB_TMR4_VOC_Mode3				0x0003

#define CB_TMR4_WOC_Mode0				0x0000			//W phase output control
#define CB_TMR4_WOC_Mode1				0x0001
#define CB_TMR4_WOC_Mode2				0x0002
#define CB_TMR4_WOC_Mode3				0x0003

#define CB_TMR4_SYNC_NoSync				0x0000			//No sync
#define CB_TMR4_SYNC_PDR				0x0001			//Synchronized to Position Detection Register change
#define CB_TMR4_SYNC_TGB				0x0002			//Synchronized to Timer General B Register compare match
#define CB_TMR4_SYNC_TGC				0x0003			//Synchronized to Timer General C Register compare match

#define CB_TMR4_UPWM_Out_HL				0x0000			//U phase PWM output select: H/L level output
#define CB_TMR4_UPWM_Out_PWM			0x0001			//U phase PWM output select: PWM waveform output
#define CB_TMR4_VPWM_Out_HL				0x0000			//V phase PWM output select: H/L level output
#define CB_TMR4_VPWM_Out_PWM			0x0001			//V phase PWM output select: PWM waveform output
#define CB_TMR4_WPWM_Out_HL				0x0000			//W phase PWM output select: H/L level output
#define CB_TMR4_WPWM_Out_PWM			0x0001			//W phase PWM output select: PWM waveform output

#define CB_TMR4_POLP_Active_Low			0x0000			//Upper phase polarity select.Active low
#define CB_TMR4_POLP_Active_High		0x0001			//Upper phase polarity select.Active high

#define CB_TMR4_DUTYMODE_UCom			0x0000			//U phase in common (same as Timer General A Register)
#define CB_TMR4_DUTYMODE_Independent	0x0001			//Three phases independent

/* word set */
#define CW_TMR4_UOC_Mode0				0x0000	
#define CW_TMR4_UOC_Mode1				0x0001
#define CW_TMR4_UOC_Mode2				0x0002
#define CW_TMR4_UOC_Mode3				0x0003

#define CW_TMR4_VOC_Mode0				(0x0000 << 2)	
#define CW_TMR4_VOC_Mode1				(0x0001 << 2)
#define CW_TMR4_VOC_Mode2				(0x0002 << 2)
#define CW_TMR4_VOC_Mode3				(0x0003 << 2)

#define CW_TMR4_WOC_Mode0				(0x0000 << 4)	
#define CW_TMR4_WOC_Mode1				(0x0001 << 4)
#define CW_TMR4_WOC_Mode2				(0x0002 << 4)
#define CW_TMR4_WOC_Mode3				(0x0003 << 4)

#define CW_TMR4_SYNC_NoSync				(0x0000 << 6)	
#define CW_TMR4_SYNC_PDR				(0x0001 << 6)	
#define CW_TMR4_SYNC_TGB				(0x0002 << 6)	
#define CW_TMR4_SYNC_TGC				(0x0003 << 6)	

#define CW_TMR4_UPWM_Out_HL				(0x0000 << 8)	
#define CW_TMR4_UPWM_Out_PWM			(0x0001 << 8)	
#define CW_TMR4_VPWM_Out_HL				(0x0000 << 9)	
#define CW_TMR4_VPWM_Out_PWM			(0x0001 << 9)	
#define CW_TMR4_WPWM_Out_HL				(0x0000 << 10)
#define CW_TMR4_WPWM_Out_PWM			(0x0001 << 10)

#define CW_TMR4_POLP_Active_Low			(0x0000 << 14)
#define CW_TMR4_POLP_Active_High		(0x0001 << 14)

#define CW_TMR4_DUTYMODE_UCom			(0x0000 << 15)
#define CW_TMR4_DUTYMODE_Independent	(0x0001 << 15)

/* POLP = 1 */
#define CW_TMR4_POLP_1_UP_CPWM_UN_PWM			(CW_TMR4_UOC_Mode0 | CW_TMR4_UPWM_Out_PWM)
#define CW_TMR4_POLP_1_UP_L_UN_PWM				(CW_TMR4_UOC_Mode1 | CW_TMR4_UPWM_Out_PWM)				
#define CW_TMR4_POLP_1_UP_PWM_UN_L				(CW_TMR4_UOC_Mode2 | CW_TMR4_UPWM_Out_PWM)
#define CW_TMR4_POLP_1_UP_PWM_UN_CPWM			(CW_TMR4_UOC_Mode3 | CW_TMR4_UPWM_Out_PWM)

#define CW_TMR4_POLP_1_VP_CPWM_VN_PWM			(CW_TMR4_VOC_Mode0 | CW_TMR4_VPWM_Out_PWM)
#define CW_TMR4_POLP_1_VP_L_VN_PWM				(CW_TMR4_VOC_Mode1 | CW_TMR4_VPWM_Out_PWM)				
#define CW_TMR4_POLP_1_VP_PWM_VN_L				(CW_TMR4_VOC_Mode2 | CW_TMR4_VPWM_Out_PWM)
#define CW_TMR4_POLP_1_VP_PWM_VN_CPWM			(CW_TMR4_VOC_Mode3 | CW_TMR4_VPWM_Out_PWM)

#define CW_TMR4_POLP_1_WP_CPWM_WN_PWM			(CW_TMR4_WOC_Mode0 | CW_TMR4_WPWM_Out_PWM)
#define CW_TMR4_POLP_1_WP_L_WN_PWM				(CW_TMR4_WOC_Mode1 | CW_TMR4_WPWM_Out_PWM)				
#define CW_TMR4_POLP_1_WP_PWM_WN_L				(CW_TMR4_WOC_Mode2 | CW_TMR4_WPWM_Out_PWM)
#define CW_TMR4_POLP_1_WP_PWM_WN_CPWM			(CW_TMR4_WOC_Mode3 | CW_TMR4_WPWM_Out_PWM)

#define CW_TMR4_POLP_1_UP_L_UN_L				(CW_TMR4_UOC_Mode0 | CW_TMR4_UPWM_Out_HL)
#define CW_TMR4_POLP_1_UP_L_UN_H				(CW_TMR4_UOC_Mode1 | CW_TMR4_UPWM_Out_HL)
#define CW_TMR4_POLP_1_UP_H_UN_L				(CW_TMR4_UOC_Mode2 | CW_TMR4_UPWM_Out_HL)
#define CW_TMR4_POLP_1_UP_H_UN_H				(CW_TMR4_UOC_Mode3 | CW_TMR4_UPWM_Out_HL)

#define CW_TMR4_POLP_1_VP_L_VN_L				(CW_TMR4_VOC_Mode0 | CW_TMR4_VPWM_Out_HL)
#define CW_TMR4_POLP_1_VP_L_VN_H				(CW_TMR4_VOC_Mode1 | CW_TMR4_VPWM_Out_HL)
#define CW_TMR4_POLP_1_VP_H_VN_L				(CW_TMR4_VOC_Mode2 | CW_TMR4_VPWM_Out_HL)
#define CW_TMR4_POLP_1_VP_H_VN_H				(CW_TMR4_VOC_Mode3 | CW_TMR4_VPWM_Out_HL)

#define CW_TMR4_POLP_1_WP_L_WN_L				(CW_TMR4_WOC_Mode0 | CW_TMR4_WPWM_Out_HL)
#define CW_TMR4_POLP_1_WP_L_WN_H				(CW_TMR4_WOC_Mode1 | CW_TMR4_WPWM_Out_HL)
#define CW_TMR4_POLP_1_WP_H_WN_L				(CW_TMR4_WOC_Mode2 | CW_TMR4_WPWM_Out_HL)
#define CW_TMR4_POLP_1_WP_H_WN_H				(CW_TMR4_WOC_Mode3 | CW_TMR4_WPWM_Out_HL)

/* POLP = 0 */
#define CW_TMR4_POLP_0_UP_PWM_UN_CPWM			(CW_TMR4_UOC_Mode0 | CW_TMR4_UPWM_Out_PWM)
#define CW_TMR4_POLP_0_UP_H_UN_CPWM				(CW_TMR4_UOC_Mode1 | CW_TMR4_UPWM_Out_PWM)
#define CW_TMR4_POLP_0_UP_CPWM_UN_H				(CW_TMR4_UOC_Mode2 | CW_TMR4_UPWM_Out_PWM)
#define CW_TMR4_POLP_0_UP_CPWM_UN_PWM			(CW_TMR4_UOC_Mode3 | CW_TMR4_UPWM_Out_PWM)

#define CW_TMR4_POLP_0_VP_PWM_VN_CPWM			(CW_TMR4_VOC_Mode0 | CW_TMR4_VPWM_Out_PWM)
#define CW_TMR4_POLP_0_VP_H_VN_CPWM				(CW_TMR4_VOC_Mode1 | CW_TMR4_VPWM_Out_PWM)
#define CW_TMR4_POLP_0_VP_CPWM_VN_H				(CW_TMR4_VOC_Mode2 | CW_TMR4_VPWM_Out_PWM)
#define CW_TMR4_POLP_0_VP_CPWM_VN_PWM			(CW_TMR4_VOC_Mode3 | CW_TMR4_VPWM_Out_PWM)

#define CW_TMR4_POLP_0_WP_PWM_WN_CPWM			(CW_TMR4_WOC_Mode0 | CW_TMR4_WPWM_Out_PWM)
#define CW_TMR4_POLP_0_WP_H_WN_CPWM				(CW_TMR4_WOC_Mode1 | CW_TMR4_WPWM_Out_PWM)
#define CW_TMR4_POLP_0_WP_CPWM_WN_H				(CW_TMR4_WOC_Mode2 | CW_TMR4_WPWM_Out_PWM)
#define CW_TMR4_POLP_0_WP_CPWM_WN_PWM			(CW_TMR4_WOC_Mode3 | CW_TMR4_WPWM_Out_PWM)

#define CW_TMR4_POLP_0_UP_H_UN_H				(CW_TMR4_UOC_Mode0 | CW_TMR4_UPWM_Out_HL)
#define CW_TMR4_POLP_0_UP_H_UN_L				(CW_TMR4_UOC_Mode1 | CW_TMR4_UPWM_Out_HL)
#define CW_TMR4_POLP_0_UP_L_UN_H				(CW_TMR4_UOC_Mode2 | CW_TMR4_UPWM_Out_HL)
#define CW_TMR4_POLP_0_UP_L_UN_L				(CW_TMR4_UOC_Mode3 | CW_TMR4_UPWM_Out_HL)

#define CW_TMR4_POLP_0_VP_H_VN_H				(CW_TMR4_VOC_Mode0 | CW_TMR4_VPWM_Out_HL)
#define CW_TMR4_POLP_0_VP_H_VN_L				(CW_TMR4_VOC_Mode1 | CW_TMR4_VPWM_Out_HL)
#define CW_TMR4_POLP_0_VP_L_VN_H				(CW_TMR4_VOC_Mode2 | CW_TMR4_VPWM_Out_HL)
#define CW_TMR4_POLP_0_VP_L_VN_L				(CW_TMR4_VOC_Mode3 | CW_TMR4_VPWM_Out_HL)

#define CW_TMR4_POLP_0_WP_H_WN_H				(CW_TMR4_WOC_Mode0 | CW_TMR4_WPWM_Out_HL)
#define CW_TMR4_POLP_0_WP_H_WN_L				(CW_TMR4_WOC_Mode1 | CW_TMR4_WPWM_Out_HL)
#define CW_TMR4_POLP_0_WP_L_WN_H				(CW_TMR4_WOC_Mode2 | CW_TMR4_WPWM_Out_HL)
#define CW_TMR4_POLP_0_WP_L_WN_L				(CW_TMR4_WOC_Mode3 | CW_TMR4_WPWM_Out_HL)


/* P_POS0_DectCtrl register */							//Timer 0 Position Detection Control Register
/* bit set */
#define CB_TMR0_PDCR_PDEN				0x0001			//Position detection enable

#define CB_TMR0_PDCR_SPLMOD_Mode1		0x0000			//Sample when PWM is on
#define CB_TMR0_PDCR_SPLMOD_Mode2		0x0001			//Sample regularly
#define CB_TMR0_PDCR_SPLMOD_Mode3		0x0002			//Sample when lower phases conducting current

#define CB_TMR0_PDCR_SPLCK_FCKdiv4		0x0000			//Sampling clock select. Select FCK/4
#define CB_TMR0_PDCR_SPLCK_FCKdiv8		0x0001			//Sampling clock select. Select FCK/8
#define CB_TMR0_PDCR_SPLCK_FCKdiv32		0x0002			//Sampling clock select. Select FCK/32
#define CB_TMR0_PDCR_SPLCK_FCKdiv128	0x0003			//Sampling clock select. Select FCK/128
/* word set */
#define CW_TMR0_PDCR_PDEN				(0x0001 << 7)

#define CW_TMR0_PDCR_SPLMOD_Mode1		(0x0000 << 12)
#define CW_TMR0_PDCR_SPLMOD_Mode2		(0x0001 << 12)
#define CW_TMR0_PDCR_SPLMOD_Mode3		(0x0002 << 12)

#define CW_TMR0_PDCR_SPLCK_FCKdiv4		(0x0000 << 14)
#define CW_TMR0_PDCR_SPLCK_FCKdiv8		(0x0001 << 14)
#define CW_TMR0_PDCR_SPLCK_FCKdiv32		(0x0002 << 14)
#define CW_TMR0_PDCR_SPLCK_FCKdiv128	(0x0003 << 14)


/* P_POS1_DectCtrl register */							//Timer 1 Position Detection Control Register
/* bit set */
#define CB_TMR1_PDCR_PDEN				0x0001			//Position detection enable

#define CB_TMR1_PDCR_SPLMOD_Mode1		0x0000			//Sample when PWM is on
#define CB_TMR1_PDCR_SPLMOD_Mode2		0x0001			//Sample regularly
#define CB_TMR1_PDCR_SPLMOD_Mode3		0x0002			//Sample when lower phases conducting current

#define CB_TMR1_PDCR_SPLCK_FCKdiv4		0x0000			//Sampling clock select. Select FCK/4
#define CB_TMR1_PDCR_SPLCK_FCKdiv8		0x0001			//Sampling clock select. Select FCK/8
#define CB_TMR1_PDCR_SPLCK_FCKdiv32		0x0002			//Sampling clock select. Select FCK/32
#define CB_TMR1_PDCR_SPLCK_FCKdiv128	0x0003			//Sampling clock select. Select FCK/128
/* word set */
#define CW_TMR1_PDCR_PDEN				(0x0001 << 7)

#define CW_TMR1_PDCR_SPLMOD_Mode1		(0x0000 << 12)
#define CW_TMR1_PDCR_SPLMOD_Mode2		(0x0001 << 12)
#define CW_TMR1_PDCR_SPLMOD_Mode3		(0x0002 << 12)

#define CW_TMR1_PDCR_SPLCK_FCKdiv4		(0x0000 << 14)
#define CW_TMR1_PDCR_SPLCK_FCKdiv8		(0x0001 << 14)
#define CW_TMR1_PDCR_SPLCK_FCKdiv32		(0x0002 << 14)
#define CW_TMR1_PDCR_SPLCK_FCKdiv128	(0x0003 << 14)


/* P_POS0_DectData register */							//Timer 0 Position Detection Register
/* bit set */
#define CB_TMR0_PDR_TIO0A				0x0001			//Noise filtered position detection input from pin TIO0A
#define CB_TMR0_PDR_TIO0B				0x0001			//Noise filtered position detection input from pin TIO0B
#define CB_TMR0_PDR_TIO0C				0x0001			//Noise filtered position detection input from pin TIO0C
/* word set */
#define CW_TMR0_PDR_TIO0A				0x0001
#define CW_TMR0_PDR_TIO0B				(0x0001 << 1)
#define CW_TMR0_PDR_TIO0C				(0x0001 << 2)


/* P_POS1_DectData register */							//Timer 1 Position Detection Register
/* bit set */
#define CB_TMR1_PDR_TIO1A				0x0001			//Noise filtered position detection input from pin TIO1A
#define CB_TMR1_PDR_TIO1B				0x0001			//Noise filtered position detection input from pin TIO1B
#define CB_TMR1_PDR_TIO1C				0x0001			//Noise filtered position detection input from pin TIO1C
/* word set */
#define CW_TMR1_PDR_TIO1A				0x0001
#define CW_TMR1_PDR_TIO1B				(0x0001 << 1)
#define CW_TMR1_PDR_TIO1C				(0x0001 << 2)


/* P_TMR3_DeadTime register */							//Timer 3 Dead Time Control Register
/* bit set */
#define CB_TMR3_DTCR_DTUE				0x0001			//Dead-time timer enable for U phases
#define CB_TMR3_DTCR_DTVE				0x0001			//Dead-time timer enable for V phases
#define CB_TMR3_DTCR_DTWE				0x0001			//Dead-time timer enable for W phases
/* word set */
#define CW_TMR3_DTCR_DTUE				(0x0001 << 12)
#define CW_TMR3_DTCR_DTVE				(0x0001 << 13)
#define CW_TMR3_DTCR_DTWE				(0x0001 << 14)


/* P_TMR4_DeadTime register */							//Timer 4 Dead Time Control Register
/* bit set */
#define CB_TMR4_DTCR_DTUE				0x0001			//Dead-time timer enable for U phases
#define CB_TMR4_DTCR_DTVE				0x0001			//Dead-time timer enable for V phases
#define CB_TMR4_DTCR_DTWE				0x0001			//Dead-time timer enable for W phases
/* word set */
#define CW_TMR4_DTCR_DTUE				(0x0001 << 12)
#define CW_TMR4_DTCR_DTVE				(0x0001 << 13)
#define CW_TMR4_DTCR_DTWE				(0x0001 << 14)


/* P_TPWM_Write register */								//Timer /PWM Module Write Enable Control Register
/* bit set */
//#define CB_TWCR_TMR3WE					0x0001			//Timer 3 setting registers write enable select bit
//#define CB_TWCR_TMR4WE					0x0001			//Timer 4 setting registers write enable select bit
/* word set */
#define CW_TWCR_TMR3WE					0x5A01  		//Timer 3 setting registers write enable select bit 
#define CW_TWCR_TMR4WE					0x5A02          //Timer 4 setting registers write enable select bit 



/* P_Fault1_Ctrl register */							//Timer 3 Fault Input Control Register
/* bit set */
#define CB_TMR3_FCR_FTPINIF				0x0001			//Fault input 1/2 status flag
#define CB_TMR3_FCR_FTPINIE				0x0001			//Fault input 1/2 interrupt enable
#define CB_TMR3_FCR_FTPINE				0x0001			//Fault input pin 1/2 enable
#define CB_TMR3_FCR_OSF					0x0001			//Output short flag

#define CB_TMR3_FCR_OCLS_Low			0x0000			//Compare low-level
#define CB_TMR3_FCR_OCLS_High			0x0001			//Compare high-level

#define CB_TMR3_FCR_OCIE				0x0001			//Output compare interrupt enable
#define CB_TMR3_FCR_OCE					0x0001			//Output compare enable
/* vord set */
#define CW_TMR3_FCR_FTPINIF				(0x0001 << 5)
#define CW_TMR3_FCR_FTPINIE				(0x0001 << 6)
#define CW_TMR3_FCR_FTPINE				(0x0001 << 7)
#define CW_TMR3_FCR_OSF					(0x0001 << 12)

#define CW_TMR3_FCR_OCLS_Low			(0x0000 << 13)
#define CW_TMR3_FCR_OCLS_High			(0x0001 << 13)

#define CW_TMR3_FCR_OCIE				(0x0001 << 14)
#define CW_TMR3_FCR_OCE					(0x0001 << 15)


/* P_Fault2_Ctrl register */							//Timer 4 Fault Input Control Register
/* bit set */
#define CB_TMR4_FCR_FTPINIF				0x0001			//Fault input 1/2 status flag
#define CB_TMR4_FCR_FTPINIE				0x0001			//Fault input 1/2 interrupt enable
#define CB_TMR4_FCR_FTPINE				0x0001			//FFault input pin 1/2 enable
#define CB_TMR4_FCR_OSF					0x0001			//Output short flag

#define CB_TMR4_FCR_OCLS_Low			0x0000			//Compare low-level
#define CB_TMR4_FCR_OCLS_High			0x0001			//Compare high-level

#define CB_TMR4_FCR_OCIE				0x0001			//Output compare interrupt enable
#define CB_TMR4_FCR_OCE					0x0001			//Output compare enable
/* vord set */
#define CW_TMR4_FCR_FTPINIF				(0x0001 << 5)
#define CW_TMR4_FCR_FTPINIE				(0x0001 << 6)
#define CW_TMR4_FCR_FTPINE				(0x0001 << 7)
#define CW_TMR4_FCR_OSF					(0x0001 << 12)

#define CW_TMR4_FCR_OCLS_Low			(0x0000 << 13)
#define CW_TMR4_FCR_OCLS_High			(0x0001 << 13)

#define CW_TMR4_FCR_OCIE				(0x0001 << 14)
#define CW_TMR4_FCR_OCE					(0x0001 << 15)


/* P_OL1_Ctrl register */								//Timer 3 Overload Protecttion Control/Status Register
/* bit set */
#define CB_TMR3_OPR_RTOL				0x0001			//Return from overload protection state
#define CB_TMR3_OPR_RTPWM_Enable		0x0001			//Return from PWM sync enable bit
#define CB_TMR3_OPR_RTTMB_Enable		0x0001			//Return from P_Timer0/1_GeneralB register compare match interrupt enable bit
#define CB_TMR3_OPR_OLST_UP				0x0001			//Under protection

#define CB_TMR3_OPR_OLMD_NoDis			0x0000			//No phases disabled
#define CB_TMR3_OPR_OLMD_AllDis			0x0001			//All phases disabled
#define CB_TMR3_OPR_OLMD_PWMDis			0x0002			//PWM phases disabled
#define CB_TMR3_OPR_OLMD_Dis			0x0003			//All upper/all lower phases disabled

#define CB_TMR3_OPR_CNTSP				0x0001			//Stop the counter
#define CB_TMR3_OPR_OLEN				0x0001			//Overload protection enable
/* word set */
#define CW_TMR3_OPR_RTOL				(0x0001 << 8)
#define CW_TMR3_OPR_RTPWM_Enable		(0x0001 << 9)
#define CW_TMR3_OPR_RTTMB_Enable		(0x0001 << 10)
#define CW_TMR3_OPR_OLST_UP				(0x0001 << 11)

#define CW_TMR3_OPR_OLMD_NoDis			(0x0000 << 12)
#define CW_TMR3_OPR_OLMD_AllDis			(0x0001 << 12)
#define CW_TMR3_OPR_OLMD_PWMDis			(0x0002 << 12)
#define CW_TMR3_OPR_OLMD_Dis			(0x0003 << 12)

#define CW_TMR3_OPR_CNTSP				(0x0001 << 14)
#define CW_TMR3_OPR_OLEN				(0x0001 << 15)


/* P_OL2_Ctrl register */							//Timer 4 Overload Protecttion Control/Status Register
/* bit set */
#define CB_TMR4_OPR_RTOL				0x0001			//Return from overload protection state
#define CB_TMR4_OPR_RTPWM_Enable		0x0001			//Return from PWM sync enable bit
#define CB_TMR4_OPR_RTTMB_Enable		0x0001			//Return from P_Timer0/1_GeneralB register compare match interrupt enable bit
#define CB_TMR4_OPR_OLST_UP				0x0001			//Under protection

#define CB_TMR4_OPR_OLMD_NoDis			0x0000			//No phases disabled
#define CB_TMR4_OPR_OLMD_AllDis			0x0001			//All phases disabled
#define CB_TMR4_OPR_OLMD_PWMDis			0x0002			//PWM phases disabled
#define CB_TMR4_OPR_OLMD_Dis			0x0003			//All upper/all lower phases disabled

#define CB_TMR4_OPR_CNTSP				0x0001			//Stop the counter
#define CB_TMR4_OPR_OLEN				0x0001			//Overload protection enable
/* word set */
#define CW_TMR4_OPR_RTOL				(0x0001 << 8)
#define CW_TMR4_OPR_RTPWM_Enable		(0x0001 << 9)
#define CW_TMR4_OPR_RTTMB_Enable		(0x0001 << 10)
#define CW_TMR4_OPR_OLST_UP				(0x0001 << 11)

#define CW_TMR4_OPR_OLMD_NoDis			(0x0000 << 12)
#define CW_TMR4_OPR_OLMD_AllDis			(0x0001 << 12)
#define CW_TMR4_OPR_OLMD_PWMDis			(0x0002 << 12)
#define CW_TMR4_OPR_OLMD_Dis			(0x0003 << 12)

#define CW_TMR4_OPR_CNTSP				(0x0001 << 14)
#define CW_TMR4_OPR_OLEN				(0x0001 << 15)


/* P_TMR_LDOK register */								//Timer Load Ok Control Register
/* word set */
#define CW_TMR_LDOK0					0x00A9  		//P_TMR3_TGRA-C ok to load bit
#define CW_TMR_LDOK1					0x00AA          //P_TMR4_TGRA-C ok to load bit


/*=================================*/
/* C. 10-bit A/D Converter register*/
/*=================================*/
/* P_ADC_Setup register */
/* bit set */
#define CB_ADC_ASPEN					0x0001			//Auto Sampling mode enable

#define CB_ADC_ADCEXTRG_Disable			0x0000			//external ADC conversion request trigger from PB8 pad. disable
#define CB_ADC_ADCEXTRG_Enable			0x0001			//external ADC conversion request trigger from PB8 pad.	enable

#define CB_ADC_ADCFS_CPUCLKdiv8			0x0000			//A/D converter clock selection. CPUCLK /8
#define CB_ADC_ADCFS_CPUCLKdiv16		0x0001			//CPUCLK /16
#define CB_ADC_ADCFS_CPUCLKdiv32		0x0002			//CPUCLK /32
#define CB_ADC_ADCFS_CPUCLKdiv64		0x0003			//CPUCLK /64


#define CB_ADC_VRXEN_Internal			0x0000			//AD Top voltage Source Selection.  Internal
#define CB_ADC_VRXEN_External			0x0001			//External

#define CB_ADC_ADCEN					0x0001			//ADC converter enable

#define CB_ADC_ADCCS_Select 			0x0001			//ADC converter chip select(ADC Power on).
#define CB_ADC_ADCCS_UnSelect 			0x0000			//un-select ADC block
/* word set */
#define CW_ADC_ASPEN					(0x0001 << 7)

#define CW_ADC_ADCEXTRG_Disable			(0x0000 << 8)
#define CW_ADC_ADCEXTRG_Enable			(0x0001 << 8)

#define CW_ADC_ADCFS_CPUCLKdiv8			(0x0000 << 9)
#define CW_ADC_ADCFS_CPUCLKdiv16		(0x0001 << 9)
#define CW_ADC_ADCFS_CPUCLKdiv32		(0x0002 << 9)
#define CW_ADC_ADCFS_CPUCLKdiv64		(0x0003 << 9)

#define CW_ADC_VRXEN_Internal			(0x0000 << 12)
#define CW_ADC_VRXEN_External			(0x0001 << 12)

#define CW_ADC_ADCEN					(0x0001 << 14)

#define CW_ADC_ADCCS_Select 			(0x0001 << 15)
#define CW_ADC_ADCCS_UnSelect 			(0x0000 << 15)


/* P_ADC_Ctrl register */
/* bit set */
#define CB_ADC_ADCCHS_Ch0				0x0000			//Select ADC converter channel input. ADC Channel0 (PA0)
#define CB_ADC_ADCCHS_Ch1				0x0001			//ADC Channel1 (PA1)
#define CB_ADC_ADCCHS_Ch2				0x0002			//ADC Channel2 (PA2)
#define CB_ADC_ADCCHS_Ch3				0x0003			//ADC Channel3 (PA3)
#define CB_ADC_ADCCHS_Ch4				0x0004			//ADC Channel4 (PA4)
#define CB_ADC_ADCCHS_Ch5				0x0005			//ADC Channel5 (PA5)
#define CB_ADC_ADCCHS_Ch6				0x0006			//ADC Channel6 (PA6)
#define CB_ADC_ADCCHS_Ch7				0x0007			//ADC Channel7 (PA7)

#define CB_ADC_ADCSTR					0x0001			//Manual Start ADC Conversion. Write this bit to "1" will start the operation of ADC conversion
#define CB_ADC_ADCRDY					0x0001			//conversion ready, AD data ist effect
#define CB_ADC_ADCIE					0x0001			//ADC interrupt enable
#define CB_ADC_ADCIF					0x0001			//ADC interrupt flag
/* word set */
#define CW_ADC_ADCCHS_Ch0				0x0000
#define CW_ADC_ADCCHS_Ch1				0x0001
#define CW_ADC_ADCCHS_Ch2				0x0002
#define CW_ADC_ADCCHS_Ch3				0x0003
#define CW_ADC_ADCCHS_Ch4				0x0004
#define CW_ADC_ADCCHS_Ch5				0x0005
#define CW_ADC_ADCCHS_Ch6				0x0006
#define CW_ADC_ADCCHS_Ch7				0x0007

#define CW_ADC_ADCSTR					(0x0001 << 6)
#define CW_ADC_ADCRDY					(0x0001 << 7)
#define CW_ADC_ADCIE					(0x0001 << 14)
#define CW_ADC_ADCIF					(0x0001 << 15)


/* P_ADC_Channel register */
/* bit set */
#define CB_ADC_ADCCH0_Enable			0x0001			//ADC Input Channel0 Enable
#define CB_ADC_ADCCH1_Enable			0x0001			//ADC Input Channel1 Enable
#define CB_ADC_ADCCH2_Enable			0x0001			//ADC Input Channel2 Enable
#define CB_ADC_ADCCH3_Enable			0x0001			//ADC Input Channel3 Enable
#define CB_ADC_ADCCH4_Enable			0x0001			//ADC Input Channel4 Enable
#define CB_ADC_ADCCH5_Enable			0x0001			//ADC Input Channel5 Enable
#define CB_ADC_ADCCH6_Enable			0x0001			//ADC Input Channel6 Enable
#define CB_ADC_ADCCH7_Enable			0x0001			//ADC Input Channel7 Enable
/* word set */
#define CW_ADC_ADCCH0_Enable			0x0001
#define CW_ADC_ADCCH1_Enable			(0x0001 << 1)
#define CW_ADC_ADCCH2_Enable			(0x0001 << 2)
#define CW_ADC_ADCCH3_Enable			(0x0001 << 3)
#define CW_ADC_ADCCH4_Enable			(0x0001 << 4)
#define CW_ADC_ADCCH5_Enable			(0x0001 << 5)
#define CW_ADC_ADCCH6_Enable			(0x0001 << 6)
#define CW_ADC_ADCCH7_Enable			(0x0001 << 7)



/*=================================*/
/* D. SPI register	 		       */
/*=================================*/
/* P_SPI_Ctrl register */
/* bit set */
#define CB_SPI_SPIFS_CPUCLKdiv4			0x0000			//Master mode clock frequency selection.	CPU clock / 4
#define CB_SPI_SPIFS_CPUCLKdiv8			0x0001			//CPU clock / 8
#define CB_SPI_SPIFS_CPUCLKdiv16		0x0002			//CPU clock / 16
#define CB_SPI_SPIFS_CPUCLKdiv32		0x0003			//CPU clock / 32
#define CB_SPI_SPIFS_CPUCLKdiv64		0x0004			//CPU clock / 64
#define CB_SPI_SPIFS_CPUCLKdiv128		0x0005			//CPU clock / 128

#define CB_SPI_SPISMPS_Middle			0x0000			//input data bit sampled at the middle of data output time
#define CB_SPI_SPISMPS_End				0x0001			//input data bit sampled at the end of data output time

#define CB_SPI_SPIPOL					0x0001			//SPI clock polarity
#define CB_SPI_SPIPHA					0x0001			//SPI clock phase

#define CB_SPI_SPIMS_Master 			0x0000			//Master mode
#define CB_SPI_SPIMS_Slave  			0x0001			//Slave  mode

#define CB_SPI_SPISPCLK_NO	 			0x0000			//no sampling
#define CB_SPI_SPISPCLK_FCK	 			0x0001			//Fck
#define CB_SPI_SPISPCLK_FCKdiv2			0x0002			//Fck/2
#define CB_SPI_SPISPCLK_FCKdiv4			0x0003			//Fck/4

#define CB_SPI_SPIRST					0x0001			//Write 1 to reset

#define CB_SPI_SPIE						0x0001			//Enable
/* word set */
#define CW_SPI_SPIFS_CPUCLKdiv4			0x0000
#define CW_SPI_SPIFS_CPUCLKdiv8			0x0001
#define CW_SPI_SPIFS_CPUCLKdiv16		0x0002
#define CW_SPI_SPIFS_CPUCLKdiv32		0x0003
#define CW_SPI_SPIFS_CPUCLKdiv64		0x0004
#define CW_SPI_SPIFS_CPUCLKdiv128		0x0005

#define CW_SPI_SPISMPS_Middle			(0x0000 << 3)
#define CW_SPI_SPISMPS_End				(0x0001 << 3)

#define CW_SPI_SPIPOL					(0x0001 << 4)
#define CW_SPI_SPIPHA					(0x0001 << 5)

#define CW_SPI_SPIMS_Master 			(0x0000 << 8)
#define CW_SPI_SPIMS_Slave  			(0x0001 << 8)

#define CW_SPI_SPISPCLK_NO	 			(0x0000 << 9)
#define CW_SPI_SPISPCLK_FCK	 			(0x0001 << 9)
#define CW_SPI_SPISPCLK_FCKdiv2			(0x0002 << 9)
#define CW_SPI_SPISPCLK_FCKdiv4			(0x0003 << 9)

#define CW_SPI_SPIRST					(0x0001 << 11)

#define CW_SPI_SPIE						(0x0001 << 15)


/* P_SPI_TxStatus register */
/* bit set */
#define CB_SPI_SPITXBF					0x0001			//Master mode: start transmission.Slave mode:start waiting Master CLOCK
#define CB_SPI_SPITXIE					0x0001			//SPI Transmit interrupt enable
#define CB_SPI_SPITXIF					0x0001			//SPI Transmit interrupt flag
/* word set */
#define CW_SPI_SPITXBF					(0x0001 << 13)
#define CW_SPI_SPITXIE					(0x0001 << 14)
#define CW_SPI_SPITXIF					(0x0001 << 15)


/* P_SPI_RxStatus register */
/* bit set */
#define CB_SPI_FERR						0x0001			//Buffer full and overwrite
#define CB_SPI_SPIRXIE					0x0001			//SPI receive interrupt enable
#define CB_SPI_SPIRXIF					0x0001			//SPI receive interrupt flag
/* word set */
#define CW_SPI_FERR						(0x0001 << 10)
#define CW_SPI_SPIRXIE					(0x0001 << 14)
#define CW_SPI_SPIRXIF					(0x0001 << 15)



/* P_UART_Data register */
/* bit set */
#define CB_UARTData_FE				0x0001				//Frame Error (Ready-only)
#define CB_UARTData_PE				0x0001				//Parity Error (Ready-only)
#define CB_UARTData_OE				0x0001				//Overrun Error (Ready-only)
/* word set */
#define CW_UARTData_FE				(0x0001 << 8)
#define CW_UARTData_PE				(0x0001 << 9)
#define CW_UARTData_OE				(0x0001 << 11)



/* P_UART_RXStatus register */
/* bit set */
#define CB_UARTRx_FE				0x0001				//Frame  Error Occurred
#define CB_UARTRx_PE				0x0001				//Parity Error Occurred
#define CB_UARTRx_OE				0x0001				//Overrun Error Occurred

#define CB_UART_Clear_FE			0x0001				//Clear Frame  Error Flag
#define CB_UART_Clear_PE			0x0001				//Clear Parity Error Flag
#define CB_UART_Clear_OE			0x0001				//Clear Overrun Error Flag
/* word set */
#define CW_UARTRx_FE				0x0001		
#define CW_UARTRx_PE				(0x0001 << 1)
#define CW_UARTRx_OE				(0x0001 << 3)

#define CW_UART_Clear_FE			0x0001
#define CW_UART_Clear_PE			(0x0001 << 1)
#define CW_UART_Clear_OE			(0x0001 << 3)



/* P_UART_Ctrl register */
/* bit set */
#define CB_UART_PEN					0x0001				//Parity Enable

#define CB_UART_PSEL_Odd			0x0000				//Parity Selection. 0= Odd Parity (if PEN= 1)
#define CB_UART_PSEL_Even			0x0001				//Parity Selection. 1= Even Parity (if PEN= 1)

#define CB_UART_SBSEL_1Stop			0x0000				//Stop Bit Size Selection. 0= 1 Stop Bit
#define CB_UART_SBSEL_2Stop			0x0001				//Stop Bit Size Selection. 1= 2 Stop Bit

#define CB_UART_RXCHSEL_No1			0x0001				//0: UART reception from RXD1
#define CB_UART_RXCHSEL_No2			0x0000				//1: UART reception from RXD2

#define CB_UART_TXCHSEL_No1			0x0001				//0: UART transmission from TXD1
#define CB_UART_TXCHSEL_No2			0x0000				//1: UART transmission from TXD2

#define CB_UART_Reset				0x0001				//Software reset
#define CB_UART_TXEN				0x0001				//UART txd pin enable
#define CB_UART_RXEN				0x0001				//UART rxd pin enable 
#define CB_UART_TXIE				0x0001				//Transmit Interrupt Enable
#define CB_UART_RXIE				0x0001				//Receive Interrupt Enable
/* word set */
#define CW_UART_PEN					(0x0001 << 1)

#define CW_UART_PSEL_Odd			(0x0000 << 2)
#define CW_UART_PSEL_Even			(0x0001 << 2)

#define CW_UART_SBSEL_1Stop			(0x0000 << 3)
#define CW_UART_SBSEL_2Stop			(0x0001 << 3)

#define CW_UART_RXCHSEL_No1			(0x0001<<9)			
#define CW_UART_RXCHSEL_No2			(0x0000<<9)			

#define CW_UART_TXCHSEL_No1			(0x0001<<10)		
#define CW_UART_TXCHSEL_No2			(0x0000<<10)		

#define CW_UART_Reset				(0x0001 << 11)
#define CW_UART_TXEN				(0x0001 << 12)
#define CW_UART_RXEN				(0x0001 << 13)
#define CW_UART_TXIE				(0x0001 << 14)
#define CW_UART_RXIE				(0x0001 << 15)

/* P_UART_BaudRate register */
/* word set */
#define CW_UARTBUD_1200					0xFB1E			//1200 bps Set
#define CW_UARTBUD_2400					0xFD8F			//2400 bps Set
#define CW_UARTBUD_4800					0xFEC8			//4800 bps Set
#define CW_UARTBUD_9600					0xFF64			//9600 bps Set	
#define CW_UARTBUD_19200				0xFFB2			//19200 bps Set
#define CW_UARTBUD_57600				0xFFE6			//57600 bps Set
#define CW_UARTBUD_115200				0xFFF3			//115200 bps Set


/* P_UART_Status register */
/* bit set */
#define CB_UART_Ready					0x0000			//0= Ready
#define CB_UART_BY						0x0001			//1= Busy
#define CB_UART_RXBF					0x0001			//Receive Full Flag
#define CB_UART_TXIF					0x0001			//Transmit Interrupt Flag
#define CB_UART_RXIF					0x0001			//Receive Interrupt Flag
/* word set */
#define CW_UART_Ready					(0x0000 << 3)
#define CW_UART_BY						(0x0001 << 3)

#define CW_UART_RXBF					(0x0001 << 6)
#define CW_UART_TXIF					(0x0001 << 14)
#define CW_UART_RXIF					(0x0001 << 15)



/* P_INT_Status register */
/* bit set */
#define CB_INT_FTIF						0x0001			//Fault protection interrupt status flag
#define CB_INT_OSCSF					0x0001			//Oscillator status flag
#define CB_INT_OLIF						0x0001			//Overload interrupt status flag	
#define CB_INT_CMTIF					0x0001			//Compare match timer interrupt status flag
#define CB_INT_PDC0IF					0x0001			//Timer/PWM module channel 0 interrupt status flag
#define CB_INT_PDC1IF					0x0001			//Timer/PWM module channel 1 interrupt status flag
#define CB_INT_TPM2IF					0x0001			//Timer/PWM module channel 2 interrupt status flag
#define CB_INT_MCP3IF					0x0001			//Timer/PWM module channel 3 interrupt status flag
#define CB_INT_MCP4IF					0x0001			//Timer/PWM module channel 4 interrupt status flag
#define CB_INT_ADCIF					0x0001			//A/D converter interrupt status flag
#define CB_INT_EXT0IF					0x0001			//External interrupt 0 status flag
#define CB_INT_EXT1IF					0x0001			//External interrupt 1 status flag
#define CB_INT_SPIIF					0x0001			//SPI interrupt status flag
#define CB_INT_UARTIF					0x0001			//UART interrupt status flag
#define CB_INT_KEYIF					0x0001			//Key-change interrupt status flag
/* word set */
#define CW_INT_FTIF						0x0001
#define CW_INT_OSCSF					(0x0001 << 1)
#define CW_INT_OLIF						(0x0001	<< 2)
#define CW_INT_CMTIF					(0x0001 << 4)
#define CW_INT_PDC0IF					(0x0001 << 5)
#define CW_INT_PDC1IF					(0x0001 << 6)
#define CW_INT_TPM2IF					(0x0001 << 7)
#define CW_INT_MCP3IF					(0x0001 << 8)
#define CW_INT_MCP4IF					(0x0001 << 9)
#define CW_INT_ADCIF					(0x0001 << 10)
#define CW_INT_EXT0IF					(0x0001 << 11)
#define CW_INT_EXT1IF					(0x0001 << 12)
#define CW_INT_SPIIF					(0x0001 << 13)
#define CW_INT_UARTIF					(0x0001 << 14)
#define CW_INT_KEYIF					(0x0001 << 15)


/* P_INT_Priority register */
/* bit set */
#define CB_INT_FTIP						0x0001			//Fault protection interrupt priority select bit
#define CB_INT_OSCIP					0x0001			//Oscillator fail interrupt priority select bit
#define CB_INT_OLIP						0x0001			//Overload interrupt priority select bit
#define CB_INT_CMTIP					0x0001			//CMT interrupt priority select bit
#define CB_INT_PDC0IP					0x0001			//PDC ch. 0 interrupt priority select bit
#define CB_INT_PDC1IP					0x0001			//PDC ch. 1 interrupt priority select bit
#define CB_INT_TPM2IP					0x0001			//TPM ch. 2 interrupt priority select bit
#define CB_INT_MCP3IP					0x0001			//MCP ch. 3 interrupt priority select bit
#define CB_INT_MCP4IP					0x0001			//MCP ch. 4 interrupt priority select bit
#define CB_INT_ADCIP					0x0001			//ADC interrupt priority select bit
#define CB_INT_EXTIP					0x0001			//External interrupt priority select bit
#define CB_INT_SPIIP					0x0001			//SPI interrupt priority select bit
#define CB_INT_UARTIP					0x0001			//UART interrupt priority select bit
#define CB_INT_KEYIP					0x0001			//Key-change interrupt priority select bit
/* word set */
#define CW_INT_FTIP						0x0001
#define CW_INT_OSCIP					(0x0001 << 1)
#define CW_INT_OLIP						(0x0001	<< 2)
#define CW_INT_CMTIP					(0x0001 << 4)
#define CW_INT_PDC0IP					(0x0001 << 5)
#define CW_INT_PDC1IP					(0x0001 << 6)
#define CW_INT_TPM2IP					(0x0001 << 7)
#define CW_INT_MCP3IP					(0x0001 << 8)
#define CW_INT_MCP4IP					(0x0001 << 9)
#define CW_INT_ADCIP					(0x0001 << 10)
#define CW_INT_EXTIP					(0x0001 << 11)
#define CW_INT_SPIIP					(0x0001 << 13)
#define CW_INT_UARTIP					(0x0001 << 14)
#define CW_INT_KEYIP					(0x0001 << 15)

/* P_MisINT_Ctrl register */
/* bit set */
#define CB_INT_EXT0IE					0x0001			//External interrupt 0 enable bit
#define CB_INT_EXT1IE					0x0001			//External interrupt 1 enable bit
#define CB_INT_EXT0MS					0x0001			//External interrupt 0 trigger mode selection
#define CB_INT_EXT1MS					0x0001			//External interrupt 1 trigger mode selection
#define CB_INT_KEYIE					0x0001			//Key-change interrupt enable bit
/* word set */
#define CW_INT_EXT0IE					(0x0001 << 11)
#define CW_INT_EXT1IE					(0x0001 << 12)
#define CW_INT_EXT0MS					(0x0001 << 13)
#define CW_INT_EXT1MS					(0x0001 << 14)
#define CW_INT_KEYIE					(0x0001 << 15)

/*=================================*/
/* H. Compare Match Time Register  */
/*=================================*/
/* P_CMT_Start register */
/* word set */
#define CW_CMT0_Start					0x0001
#define CW_CMT1_Start					0x0002

/* P_CMT_Start register */
/* bit set */
#define CB_CMT0_Start					0x0001
#define CB_CMT1_Start					0x0001
#define CB_CMT0_Stop					0x0000
#define CB_CMT1_Stop					0x0000

/* P_CMT_Ctrl register */
/* word set */
#define CW_CKA_FCK_1					0x0000		//CKA = FCK / 1		
#define CW_CKA_FCK_2					0x0001		//CKA = FCK / 2		
#define CW_CKA_FCK_4					0x0002		//CKA = FCK / 4		
#define CW_CKA_FCK_8					0x0003		//CKA = FCK / 8		
#define CW_CKA_FCK_16					0x0004		//CKA = FCK / 16		
#define CW_CKA_FCK_64					0x0005		//CKA = FCK / 64		
#define CW_CKA_FCK_256					0x0006		//CKA = FCK / 256		
#define CW_CKA_FCK_1024					0x0007		//CKA = FCK / 1024
#define CW_CMT0_INT_EN					0x0040		//CMT0 compare match interrupt enable
#define CW_CLEAR_CM0IF					0x0080		

#define CW_CKB_FCK_1					0x0000		//CKA = FCK / 1		
#define CW_CKB_FCK_2					0x0100		//CKA = FCK / 2		
#define CW_CKB_FCK_4					0x0200		//CKA = FCK / 4		
#define CW_CKB_FCK_8					0x0300		//CKA = FCK / 8		
#define CW_CKB_FCK_16					0x0400		//CKA = FCK / 16		
#define CW_CKB_FCK_64					0x0500		//CKA = FCK / 64		
#define CW_CKB_FCK_256					0x0600		//CKA = FCK / 256		
#define CW_CKB_FCK_1024					0x0700		//CKA = FCK / 1024
#define CW_CMT1_INT_EN					0x4000		//CMT1 compare match interrupt enable
#define CW_CLEAR_CM1IF					0x8000		

/* P_CMT_Ctrl register */
/* bit set */
#define CB_CKA_FCK_1					0x0000
#define CB_CKA_FCK_2					0x0001
#define CB_CKA_FCK_4					0x0002
#define CB_CKA_FCK_8					0x0003
#define CB_CKA_FCK_16					0x0004
#define CB_CKA_FCK_64					0x0005
#define CB_CKA_FCK_256					0x0006
#define CB_CKA_FCK_1024					0x0007
#define CB_CMT0_INT_EN					0x0001
#define CB_CLEAR_CM0IF					0x0001

#define CB_CKB_FCK_1					0x0000
#define CB_CKB_FCK_2					0x0001
#define CB_CKB_FCK_4					0x0002
#define CB_CKB_FCK_8					0x0003
#define CB_CKB_FCK_16					0x0004
#define CB_CKB_FCK_64					0x0005
#define CB_CKB_FCK_256					0x0006
#define CB_CKB_FCK_1024					0x0007
#define CB_CMT1_INT_EN					0x0001
#define CB_CLEAR_CM1IF					0x0001

/*=================================*/
/* H. Time Base Register  		   */
/*=================================*/
/* P_BZO_Ctrl register */
/* word set */
#define CW_BZOCK_FCK_16384				0x0000
#define CW_BZOCK_FCK_8192				0x0001
#define CW_BZOCK_FCK_4096				0x0002
#define CW_BZOCK_FCK_2048				0x0003
#define CW_BZO_EN						0x8000

/* P_BZO_Ctrl register */
/* bit set */
#define CB_BZOCK_FCK_16384				0x0000
#define CB_BZOCK_FCK_8192				0x0001
#define CB_BZOCK_FCK_4096				0x0002
#define CB_BZOCK_FCK_2048				0x0003
#define CB_BZO_EN						0x0001

#endif /* #ifndef __SPMC75_REGS_H */
