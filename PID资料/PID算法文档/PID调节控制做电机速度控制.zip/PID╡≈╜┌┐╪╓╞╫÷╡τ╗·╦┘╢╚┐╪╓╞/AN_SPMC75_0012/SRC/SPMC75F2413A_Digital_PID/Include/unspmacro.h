/* ========================================================================= */
/* The information contained herein is the exclusive property of             */
/* Sunplus Technology Co. And shall not be distributed, reproduced,          */
/* or disclosed in whole in part without prior written permission.           */
/*             (C) COPYRIGHT 2001 SUNPLUS TECHNOLOGY CO.                     */
/*                    ALL RIGHTS RESERVED                                    */
/* The entire notice above must be reproduced on all authorized copies.      */
/* ========================================================================= */
/* File Name   : unspmacro.h											     */	
/* Description : inline assembly macro definition		 				     */
/* Processor   : SPMC75X series											     */	
/* Author      : Jacky Lin and Chih ming Huang							     */
/* Tools	   : u'nSP IDE tools v1.18.1A or later version				     */
/* Version     : 1.00 													     */	
/* Security    : Confidential Proprietary 							         */
/* E-Mail      : MaxHuang@sunplus.com.tw								     */
/* ========================================================================= */

//================================================================
//Function: Write a value to designated control register (I/O Port)
//Example:	outport(P_IOA_Data,0x8000);
// R1 = %1   ->  R1 = Value
// [%0] = R1 ->  [Addr] = R1 
//================================================================
#define         outport(Addr,Value)		\
				asm(					\
				"r1=%1;\n"				\
				"\t[%0]=r1;\n"			\
				:						\
				:"i"(Addr),"i"(Value)	\
				:"1"					\
				);

//================================================================
//Function: Read a value from designated control register (I/O Port)
//Example:	int	i;
//		inport(P_IOA_Data,i);
// %0 = [%1]  -> Data = [Port]
//================================================================
#define 	inport(Port, Data) 	asm("%0 = [%1]": "=r"(Data) : "i"(Port))


//================================================================
//Function:Get segment:offset of designated label
//Example:	int i,j;
//		long	label;
//		GetSegmentOffset(label,i,j);
// offset = SEG label
// segment = OFFSET label
//================================================================
#define         GetSegmentOffset(label,segment,offset)	\
                asm(                                    \
                "%1=seg %2\n"                           \
                "\t%0=offset %2\n"                      \
                :"=r"(segment),"=r"(offset)             \
                :"p"(&label)                            \
                );
                   
//================================================================
//Function: SETB Function
//Example:	SETB(_P_IOA_Data,0x8);
// R1 = Addr
// R2 = Num
// SETB [R1], R2
//================================================================
#define         SETB(Addr,Num)		\
				asm(				\
				"r1=%0;\n"			\
				"r2=%1;\n"			\
				"setb \t[r1],r2\n"	\
				:					\
				:"i"(Addr),"i"(Num)	\
				:"1","2"			\
				);

//================================================================
//Function: CLRB Function
//Example:	CLRB(_P_IOA_Data,0x8);
// R1 = Addr
// R2 = Num
// CLRB [R1], R2
//================================================================
#define         CLRB(Addr,Num)		\
				asm(				\
				"r1=%0;\n"			\
				"r2=%1;\n"			\
				"clrb \t[r1],r2\n"	\
				:					\
				:"i"(Addr),"i"(Num)	\
				:"1","2"			\
				);
				
//================================================================
//Function: INVB Function
//Example:	INVB(_P_IOA_Data,0x8);
// R1 = Addr
// R2 = Num
// INVB [R1], R2
//================================================================
#define         INVB(Addr,Num)		\
				asm(				\
				"r1=%0;\n"			\
				"r2=%1;\n"			\
				"invb \t[r1],r2\n"	\
				:					\
				:"i"(Addr),"i"(Num)	\
				:"1","2"			\
				);

//================================================================
//Function: TSTB Function
//int i
//Example:	TSTB(_P_IOA_Data,0x8,i);
// R1 = Addr
// R2 = Num
// TSTB [R1], R2
//================================================================
#define         TSTB(Addr,Num,Data)	\
				asm(				\
				"r1=%1;\n"			\
				"r2=%2;\n"			\
				"tstb \t[r1],r2\n"	\
				"jz	2\n"			\
				"\t%0=0x0001\n"		\
				"jmp	1\n"		\
				"\t%0=0x0000\n"		\
				:"=r"(Data)			\
				:"i"(Addr),"i"(Num)	\
				:"1","2"			\
				);	
    				//"r1=0x0000\n"		\               
//================================================================
//Function: INT of CPU
//Example:	INT_OFF();
//Example:	INT_IRQ();
//Example:	INT_FIQ();
//Example:	INT_FIQ_IRQ();
//Example:  Enable_FIQ_IRQ();
//================================================================
#define		INT_OFF()			asm("int off\n");
#define		INT_IRQ()			asm("int irq\n");
#define		INT_FIQ()			asm("int fiq\n");
#define		INT_FIQ_IRQ()		asm("int fiq,irq\n");
#define 	Enable_FIQ_IRQ()	asm("int fiq,irq\n");
#define 	Disable_FIQ_IRQ()	asm("int off\n");

//================================================================
//Function: Disable IRQ Flag of CPU
//Example:	Disable_IRQ();
//================================================================
#define		Disable_IRQ()	asm("irq off\n");
#define		IRQ_OFF()		asm("irq off\n");

//================================================================
//Function: Enable IRQ Flag of CPU
//Example:	Enable_IRQ();
//================================================================
#define		Enable_IRQ()	asm("irq on\n");
#define		IRQ_ON()		asm("irq on\n");

//================================================================
//Function: Disable FIQ Flag of CPU
//Example:	Disable_FIQ();
//================================================================
#define		Disable_FIQ()	asm("fiq off\n");
#define		FIQ_OFF()		asm("fiq off\n");

//================================================================
//Function: Enable FIQ Flag of CPU
//Example:	Enable_FIQ();
//================================================================
#define		Enable_FIQ()	asm("fiq on\n");
#define		FIQ_ON()		asm("fiq on\n");

//================================================================
//Function: Disable Movement Flag of FIR DSP Operation
//Example:	Disable_FIRMOV();
//================================================================
#define		Disable_FIRMOV()	asm("fir_mov off\n");

//================================================================
//Function: Enable Movement Flag of FIR DSP Operation
//Example:	Enable_FIRMOV();
//================================================================
#define		Enable_FIRMOV()		asm("fir_mov on\n");

//================================================================
//Function: Make CPU software interrupt (break)
//Example:	SoftwareInterrupt();
//================================================================
#define     SoftwareInterrupt()	asm("break\n");

//================================================================
//Function: Secondary Register Mode	 On/Off						
//SecBankOn();
//SecBankOff();
//================================================================
#define     SecBankOn()		asm("secbank on\n");
#define     SecBankOff()	asm("secbank off\n");

//================================================================
//Function: IRQ Nested Mode	 On/Off						
//IRQNestOn();
//IRQNestOff();
//================================================================
#define     IRQNestOn()		asm("irqnest on\n");
#define     IRQNestOff()	asm("irqnest off\n");

//================================================================
//Function: Make CPU no operation
//Example:	NOP();
//================================================================
#define     NOP()				asm("nop\n");





