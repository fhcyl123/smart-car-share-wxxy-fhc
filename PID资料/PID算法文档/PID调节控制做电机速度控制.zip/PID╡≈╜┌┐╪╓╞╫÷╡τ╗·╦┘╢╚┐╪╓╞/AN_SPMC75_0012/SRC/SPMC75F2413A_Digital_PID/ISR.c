
/* ========================================================================= */
/* The information contained herein is the exclusive property of             */
/* Sunplus Technology Co. And shall not be distributed, reproduced,          */
/* or disclosed in whole in part without prior written permission.           */
/*             (C) COPYRIGHT 2004 SUNPLUS TECHNOLOGY CO.                     */
/*                    ALL RIGHTS RESERVED                                    */
/* The entire notice above must be reproduced on all authorized copies.      */
/* ========================================================================= */
/* 																			 */
/* ========================================================================= */
/* Project Name  : SPMC75F2413A_Digital_PID	            					 */
/* File Name     : ISR.c													 */
/* Description   : �жϷ���													 */
/*                 				                                		     */
/* Processor     : SPMC75F2413A											     */
/* Tools	     : u'nSP IDE tools v1.18.1A or later version				 */
/* ========================================================================= */
/* Revision																	 */
/* ========================================================================= */
/* Version       :  1.00   													 */
/* Date			 :	2005.9.1												 */
/* Modified by   :	����������ļ�ͷ�����µ�ͷ�ļ�							 */
/* Description	 :												    		 */
/* ========================================================================= */

//=============================================//
//Include File For Interrupt
//=============================================//
#include	"Spmc75_BLDC.h"
//========================================================================
// Description: BREAK interrupt is used to XXX
// Notes:
//========================================================================
void BREAK(void) __attribute__ ((ISR));
void BREAK(void)
{
}

//========================================================================
// Description: FIQ interrupt source is XXX,used to XXX
// Notes:
//========================================================================
void FIQ(void) __attribute__ ((ISR));
void FIQ(void)
{
	NOP();
	NOP();
	NOP();
}

//========================================================================
// Description: IRQ0 interrupt source is XXX,used to XXX
// Notes:
//========================================================================
void IRQ0(void) __attribute__ ((ISR));
void IRQ0(void)
{
	IPM_Fault_Protect();			//��������
}

//========================================================================
// Description: IRQ1 interrupt source is XXX,used to XXX
// Notes:
//========================================================================
void IRQ1(void) __attribute__ ((ISR));
void IRQ1(void)
{
	/*=============================================================*/
	/*Position detection change interrupt
	/*=============================================================*/
	if(P_TMR0_Status->B.PDCIF && P_TMR0_INT->B.PDCIE)
	{
		BLDC_Motor_Normalrun();		//�������з���
	}
	
	/*=============================================================*/
	/*Timer Counter Overflow
	/*=============================================================*/
	if(P_TMR0_Status->B.TCVIF && P_TMR0_INT->B.TCVIE)
	{
		BLDC_Motor_Startup();		//������������
	}
	P_TMR0_Status->W = P_TMR0_Status->W;
}

//========================================================================
// Description: IRQ2 interrupt source is XXX,used to XXX
// Notes:
//========================================================================
void IRQ2(void) __attribute__ ((ISR));
void IRQ2(void)
{
}

//========================================================================
// Description: IRQ3 interrupt source is XXX,used to XXX
// Notes:
//========================================================================
void IRQ3(void) __attribute__ ((ISR));
void IRQ3(void)
{	
	/*=============================================================*/
	/*Timer Period Register output compare match
	/*=============================================================*/
	if(P_TMR3_Status->B.TPRIF && P_TMR3_INT->B.TPRIE)
	{
	}

	/*=============================================================*/
	/*
	/*=============================================================*/
	if(P_TMR3_Status->B.TGDIF && P_TMR3_INT->B.TGDIE)
	{
	}

	P_TMR3_Status->W = P_TMR3_Status->W;
}

//========================================================================
// Description: IRQ4 interrupt source is XXX,used to XXX
// Notes:
//========================================================================
void IRQ4(void) __attribute__ ((ISR));
void IRQ4(void)
{
}


//========================================================================
// Description: IRQ5 interrupt source is XXX,used to XXX
// Notes:
//========================================================================
void IRQ5(void) __attribute__ ((ISR));
void IRQ5(void)
{

}

//========================================================================
// Description: IRQ6 interrupt source is XXX,used to XXX
// Notes:
//========================================================================
void IRQ6(void) __attribute__ ((ISR));
void IRQ6(void)
{
	if(P_INT_Status->B.UARTIF)
	{								
		if(P_UART_Status->B.RXIF)	MC75_DMC_RcvStream();	//DMC Rxd����
		if(P_UART_Status->B.TXIF && P_UART_Ctrl->B.TXIE);
	}	
}

//========================================================================
// Description: IRQ7 interrupt source is XXX,used to XXX
// Notes:
//========================================================================
void IRQ7(void) __attribute__ ((ISR));
void IRQ7(void)
{
	if(P_INT_Status->B.CMTIF)
	{
		if(P_CMT_Ctrl->B.CM0IF && P_CMT_Ctrl->B.CM0IE)
		{
			BLDC_Motor_Actiyator();			//PID����
		}
		
		if(P_CMT_Ctrl->B.CM1IF && P_CMT_Ctrl->B.CM1IE)
		{
			NOP();
		}
		
		P_CMT_Ctrl->W = P_CMT_Ctrl->W;
	}

}
//========================================================================
// *END*
//========================================================================