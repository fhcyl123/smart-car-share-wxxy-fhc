/* ========================================================================= */
/* File Name   : spmc75_dmc_uart_ext.h									     */	
/* Description : DMC toolkit external callable function						 */    
/* Processor   : SPMC75F												     */	
/* Author      : Chih ming Huang										     */
/* Date        : June 2004												     */
/* Tools	   : u'nSP IDE tools v1.15.4 								     */
/* Version     : 1.00 													     */	
/* Security    : Confidential Proprietary 							         */
/* E-Mail      : MaxHuang@sunplus.com.tw								     */
/* ========================================================================= */
#ifndef __SPMC75_DMC_UART_EXT_H
#define __SPMC75_DMC_UART_EXT_H

/*****************************************************************************/
/* External function prototype declaration									 */
/*****************************************************************************/
extern void MC75_DMC_UART_Setup(UInt16);
extern void MC75_DMC_RcvStream(void);
extern void MC75_DMC_UART_Service(void);

#endif /* #ifndef __SPMC75_DMC_UART_EXT_H */