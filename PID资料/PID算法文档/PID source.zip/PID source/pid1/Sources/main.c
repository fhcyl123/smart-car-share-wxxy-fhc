/****************************************Copyright (c)****************************************************
**      
**--------------File Info---------------------------------------------------------------------------------
** File name:                  pid1.c
** Latest modified Date:       2009-9-19
** Latest Version:
** Descriptions:
**
**--------------------------------------------------------------------------------------------------------
** Created by:                 sunlijuan
** Created date:               2009-9-19
** Version:
** Descriptions:
**
**--------------------------------------------------------------------------------------------------------
** Modified by:
** Modified date:              2009-9-19
** Version:
** Descriptions:
**
*********************************************************************************************************/
#include <hidef.h>                                                      /* common defines and macros    */
#include <MC9S12XS128.h>                                                /* derivative information       */
#pragma LINK_INFO DERIVATIVE "mc9s12xs128"
/*********************************************************************************************************
* �궨��
*********************************************************************************************************/
#define  delay1us         {_asm nop;}
#define  LCD_ENSCLK         0x08
#define  LCD_RSCS           0x02
#define  LCD_RWSID          0x04
#define  LCD_ENSCLKPort     PORTA
#define  LCD_RWSIDPort      PORTA
#define  LCD_RSCSPort       PORTA

/*********************************************************************************************************
* ȫ�ֱ���
*********************************************************************************************************/
uchar    SYNCH = 0xfe;
char number[4];
char piancha[3];
int Get_pulse;
int num;
int data;
int sdata;
int ddata;
int error=0;
int pre_error=0;
int last_error=0;
int PWM_temp=0;

/*********************************************************************************************************
** Function name:           delaynus
** Descriptions:            Nus����ʱ
** input parameters:        cnt
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void delaynus(byte cnt)
{
    byte i;
    for(i = 0; i < cnt; i++)
    {
        delay1us;
    }
}

/*********************************************************************************************************
** Function name:           delay1ms
** Descriptions:            1ms����ʱ
** input parameters:        NONE
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void delay1ms(void)
{
    uint i;
    for(i=0;i<1140;i++);
}

/*********************************************************************************************************
** Function name:           delaynms
** Descriptions:            Nms����ʱ
** input parameters:        n
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void delaynms(uint n)
{   uint i;
    for(i=0;i<n;i++)
    delay1ms();
}

/*********************************************************************************************************
** Function name:           Write_com
** Descriptions:            ʵ��LCD��дָ��������
** input parameters:        com-�ж�λ,dat-����
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void Write_com(uchar com, uchar dat)                                    /* Synchronous  three byte! Ref */
                                                                        /* erence!!                     */
{
    uchar i,temp;
    DDRA|=0xf0;
    LCD_RSCSPort |= LCD_RSCS;
    temp = SYNCH;
    temp &= ~LCD_RWSID;
    if (com)
    temp |= LCD_RSCS;
    else
    temp &= ~LCD_RSCS;
    for(i = 0;i < 8;i ++)
    {
        if( (temp << i) & 0x80)
        LCD_RWSIDPort  |= LCD_RWSID;
        else
        LCD_RWSIDPort  &= ~LCD_RWSID;
        LCD_ENSCLKPort &= ~LCD_ENSCLK;
        delay1us;delay1us;                                              /* delay is very important!     */
        LCD_ENSCLKPort |= LCD_ENSCLK;
    }
    delaynms(7);

    temp = dat & 0xf0;
    for(i = 0;i < 8;i ++)
    {
        if( (temp << i) & 0x80)
        LCD_RWSIDPort |= LCD_RWSID;
        else
        LCD_RWSIDPort &= ~LCD_RWSID;
        LCD_ENSCLKPort &= ~LCD_ENSCLK;
        delay1us;delay1us;
        LCD_ENSCLKPort |= LCD_ENSCLK;
    }
    delaynms(7);
    temp = dat & 0x0f;
    temp = temp << 4;
    for(i = 0;i < 8;i ++)
    {
        if( (temp << i) & 0x80)
        LCD_RWSIDPort |= LCD_RWSID;
        else
        LCD_RWSIDPort &= ~LCD_RWSID;
        LCD_ENSCLKPort &= ~LCD_ENSCLK;
        delay1us;delay1us;
        LCD_ENSCLKPort|=LCD_ENSCLK;
    }
    delaynms(7);
    LCD_RSCSPort &= ~ LCD_RSCS ;
}

/*********************************************************************************************************
** Function name:           LCD_init
** Descriptions:            Һ����ʾ��ʼ��
** input parameters:        NONE
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void LCD_init(void)
{
    DDRA|=0x0e;
    Write_com(0,0x38);
    delaynms(5);                                                        /* ��ʾģʽ����                */
    Write_com(0,0x08);
    delaynms(5);                                                        /* ��ʾ�ر�                     */
    Write_com(0,0x06);
    delaynms(5);                                                        /* ��ʾ����                     */
    Write_com(0,0x01);
    delaynms(5);                                                        /* ��ʾ����ƶ�λ��             */
    Write_com(0,0x0c);
    delaynms(5);                                                        /* ��ʾ�����������             */
}

/*********************************************************************************************************
** Function name:           write_hanzi
** Descriptions:            ��д�ַ���
** input parameters:        *p-ָ��ָ����д����
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void write_hanzi(char *p)
{
    while(*p)
    {
        Write_com(0x01,*p);
        p++;
    }
}

/*********************************************************************************************************
** Function name:           setxy
** Descriptions:            ��дλ������ȷ��
** input parameters:        ypos-ҳ��ַ,xpos-�е�ַ
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void setxy(uchar ypos,uchar xpos)
{
    switch(ypos)
    {
        case 1:
        Write_com(0x00,(0x80+xpos-1));                                  /* first column pay attention 2 */
                                                                        /* da add of every row!         */
        break;
        case 2:
        Write_com(0x00,(0x90+xpos-1));                                  /* 2nd   column                 */
        break;
        case 3:
        Write_com(0x00,(0x88+xpos-1));                                  /* 3th   column                 */
        break;
        case 4:
        Write_com(0x00,(0x98+xpos-1));                                  /* 4th   column                 */
        break;
        default:break;
    }
}

/*********************************************************************************************************
** Function name:           PitInit
** Descriptions:            ��ʱ���жϳ�ʼ��
** input parameters:        NONE
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void PitInit(void)
{
    PITCFLMT_PITE=0;                                                    /* disable PIT                  */
    PITCE_PCE0=1;                                                       /* enable  channel 0            */
    PITMTLD0=200-1;                                                     /* time base  8M clock          */
    PITMUX=0X00;                                                        /* ch0 connected to micro timer */
    PITLD0=8000-1;
    PITINTE_PINTE0=1;                                                   /* enable interupt channel 0    */
    PITCFLMT_PITE=1;                                                    /* enable PIT                   */
}

/*********************************************************************************************************
** Function name:           Init_pll
** Descriptions:            ���໷��ʼ��
** input parameters:        NONE
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void Init_pll(void)
{
    CLKSEL = 0X00;                                                      /* disengage PLL to system      */
    PLLCTL_PLLON = 1;                                                   /* turn on PLL                  */
    SYNR = 4;
    REFDV=1 ;                                                           /* pllclock=2*osc*(1+SYNR)/(1+R */
    _asm(nop);                                                          /* BUS CLOCK=20M                */
    _asm(nop);
    while(!(CRGFLG_LOCK == 1));                                         /* when pll is steady ,then use */
    CLKSEL_PLLSEL = 1;                                                  /* engage PLL to system;        */
}

/*********************************************************************************************************
** Function name:           Init_ECT
** Descriptions:            ECTģ���ʼ��
** input parameters:        NONE
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void Init_ECT(void)
{
    PACTL = 0X70;
    TIOS_IOS0 = 0;                                                      /* ͨ��0���벶��                */
    TIOS_IOS1 = 0;                                                      /* ͨ��1���벶׽                */
    TSCR1 = 0X80;                                                       /* ����ʱ��ʹ�ܱ�־λ�������   */
    TCTL3 = 0X00;
    TCTL4 = 0X09;                                                       /* ͨ��0��׽���������أ�ͨ��1�� */
    TIE_C0I = 1;                                                        /* 0ͨ���жϿ�ͨ                */
    TIE_C1I = 0;                                                        /* 1ͨ���жϿ�ͨ                */
    TFLG1_C0F = 1;                                                      /* ���ͨ��0�жϱ�־            */
    TFLG1_C1F = 1;
    TIE = 0X01;                                                         /* ��ʼ����ʱ���ر�             */
}

/*********************************************************************************************************
** Function name:           Init_PWMout
** Descriptions:            PWMģ���ʼ��
** input parameters:        NONE
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void Init_PWMout(void)
{
    PWME     = 0x00;                                                    /* ��ֹPWM���                  */
    PWMCTL   = 0x70;                                                    /* 01��23��45ͨ������           */
    PWMPOL   = 0x0a;                                                    /* ͨ��01���������Ϊ�����ԣ�23 */
    PWMCAE   = 0x11;                                                    /* ȫ��ͨ�������Ķ���           */
    PWMCLK   = 0x00;                                                    /* ʱ��ԴΪ��CLOCKA��CLOCKB     */
    PWMPRCLK = 0x40;                                                    /* ʱ��CLOCKA����Ƶ40MHZ��CLOCK */
    PWMPER01 = 2000;                                                    /* ����ٶȿ��� ���� 250us F=4K */
    PWMDTY01 = 1000;                                                    /* Ĭ��ռ�ձ�                   */
    PWMPER23 = 50000;                                                   /* ���������� ����20ms F=50HZ */
    PWMDTY23 = 3790;                                                    /* ��������-��ռ�ձ�            */
    PWME     = 0x2A;                                                    /* ʹ��PWM���                  */
}

/*********************************************************************************************************
** Function name:           display
** Descriptions:            ��ʾ������ֵ
** input parameters:        NONE
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void display(void)
{
    setxy(1,1);
    write_hanzi("����ֵ8300r/min");
    setxy(2,1);
    write_hanzi("����ֵ");
    setxy(2,4);
    write_hanzi(number);
    setxy(2,6) ;
    write_hanzi("r/min");
    setxy(3,1);
    write_hanzi("�˴�ƫ��ֵΪ:");
    if(sdata>=0) {setxy(4,2);write_hanzi("+");}
    else  {setxy(4,2);write_hanzi("-");}
    setxy(4,3);
    write_hanzi(piancha);
    setxy(4,5) ;
    write_hanzi("r/min");
}
/*********************************************************************************************************
** Function name:           PIT1S
** Descriptions:            1S��ʱ
** input parameters:        NONE
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void PIT1S(void)
{
    if(num==5)
    {
        data=Get_pulse;
        Get_pulse=0;
        data=data*60;
        sdata=8300-data;
        if(sdata<0)ddata=-sdata;
        else ddata=sdata;
        piancha[0]=ddata/100+'0';
        piancha[1]=(ddata%100)/10+'0';
        piancha[2]=ddata%10+'0';
        number[0]=data/1000+'0';
        number[1]=(data%1000)/100+'0';
        number[2]=(data%100)/10+'0';
        number[3]=data%10+'0';
        display();
        data=0;
        num=0;
    }
}
/*********************************************************************************************************
** Function name:           Speed_PID
** Descriptions:            ����PID��ʽ
** input parameters:        std_speed-�����ٶ�,curr_speed-��ǰ�ٶ�
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

void Speed_PID(int std_speed,int curr_speed)
{
    char Kp=7,Ki=3,Kd=2;
    error=std_speed-curr_speed;
    if(error<150&&error>-150)error=0;
    PWM_temp= PWMDTY01+Kp*error+Ki*(error-last_error)+Kd*(error+pre_error-2*last_error);
    if(PWM_temp<3500)
    PWM_temp=3500;
    else if(PWM_temp>8000)
    PWM_temp=8000;
    PWMDTY01=PWM_temp;
    pre_error=error;
    last_error=pre_error;
}

/*********************************************************************************************************
                                                * ������
*********************************************************************************************************/

void main(void)
{
    LCD_init();
    PitInit();
    Init_ECT();
    Init_PWMout();
    Speed_PID(5500,data+data/2);
    for(;;)
    { 
        EnableInterrupts;
    }
}

/*********************************************************************************************************
** Function name:           interrupt 8 vIC1ISR
** Descriptions:            ������ٲ�׽�жϺ���
** input parameters:        NONE
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

#pragma CODE_SEG __NEAR_SEG NON_BANKED
void interrupt 8 vIC1ISR(void)
{
    Get_pulse++;
    TFLG1_C0F = 1;
}

/*********************************************************************************************************
** Function name:           interrupt 66 PIT0Interrupt
** Descriptions:            200ms��ʱ�жϺ���
** input parameters:        NONE
** Output parameters:       NONE
** Returned value:          NONE
*********************************************************************************************************/

#pragma CODE_SEG __NEAR_SEG NON_BANKED
void interrupt 66 PIT0Interrupt(void)
{   
    DisableInterrupts;
    num++;
    PIT1S();
    PITTF_PTF0=1;
}
#pragma CODE_SEG DEFAULT

/*********************************************************************************************************
  END FILE
*********************************************************************************************************/