clear all;
close all;
%load pid_ncd.mat;

kp=0.63;
ki=0.0504;
kd=1.9688;
a2=43;
a1=3;