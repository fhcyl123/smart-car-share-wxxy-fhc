x=1,y=2
m=x+y