close all;

plot(t,rin,'k',t,yout,'k');
xlabel('time(s)');
ylabel('r,y');
