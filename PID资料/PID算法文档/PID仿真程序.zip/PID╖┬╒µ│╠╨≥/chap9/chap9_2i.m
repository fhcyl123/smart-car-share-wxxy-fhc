clear all;
close all;
global J rou0 rou1 af

J=1.0;
rou0=260;
rou1=2.5;
af=0.02;